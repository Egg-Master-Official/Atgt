// ARTEX /api/scan — NDJSON streaming website scanner (11 modules, live per-module streaming)
import { NextRequest } from "next/server";
import { scanWebsite, MODULE_COUNT, assertValidTarget } from "@/lib/artex/site-scanner";
import type { StreamEvent, ScanModule } from "@/lib/artex/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export async function POST(req: NextRequest) {
  let target = "";
  try {
    const body = await req.json();
    target = typeof body?.target === "string" ? body.target : "";
  } catch {
    target = "";
  }

  const encoder = new TextEncoder();
  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      // abort-safe send: client disconnect pe enqueue throw na ho
      let open = true;
      const send = (ev: StreamEvent) => {
        if (!open) return;
        try {
          controller.enqueue(encoder.encode(JSON.stringify(ev) + "\n"));
        } catch {
          open = false;
        }
      };
      req.signal?.addEventListener("abort", () => { open = false; });

      try {
        if (!target.trim()) {
          send({ event: "error", data: { message: "Target URL missing — usage: scan <url>" } });
          return;
        }
        try {
          assertValidTarget(target);
        } catch {
          send({ event: "error", data: { message: "Invalid URL format — valid domain/IP do (jaise example.com ya https://site.com/path)" } });
          return;
        }

        // network check
        let online = true;
        try {
          const probe = await fetch("https://example.com", { signal: AbortSignal.timeout(3000) });
          online = probe.status < 500;
        } catch {
          online = false;
        }

        send({ event: "start", data: { target, modules: MODULE_COUNT, online, timestamp: new Date().toISOString() } });
        await sleep(100);
        if (!online) {
          send({ event: "log", data: { message: "[scan] Sandbox me outbound web access nahi mila — heuristic/offline mode chal raha hai.", level: "warn" } });
        } else {
          send({ event: "log", data: { message: `[scan] Target locked: ${target}`, level: "ok" } });
        }
        send({ event: "log", data: { message: `[scan] ${MODULE_COUNT} modules parallel queue hue: TLS, Headers, Cookies, Info-Disclosure, CORS, Sensitive-Files, Forms, XSS-Probe, Open-Redirect, DNS/Email-SEC, Mixed-Content` } });
        await sleep(150);

        const startedAt = Date.now();
        // onModule callback: module complete hote hi TURANT stream pe chala jata hai (live)
        const { score, verdict, durationMs } = await scanWebsite(target, online, (m: ScanModule) => {
          send({ event: "log", data: { message: `[scan] ${m.name}: ${m.status} (${m.score}/100) — ${m.summary}`, level: m.status === "PASS" ? "ok" : m.status === "FAIL" ? "error" : "warn" } });
          for (const fd of m.findings) {
            send({ event: "finding", data: { ...fd, module: m.name } });
          }
          send({ event: "module", data: m });
        });

        await sleep(150);
        send({ event: "score", data: { score, max: 100, verdict } });
        send({
          event: "done",
          data: {
            target,
            score,
            verdict,
            modules: MODULE_COUNT,
            online,
            durationMs,
            totalMs: Date.now() - startedAt,
            timestamp: new Date().toISOString(),
          },
        });
      } catch (e) {
        send({ event: "error", data: { message: e instanceof Error ? e.message : "scan failed" } });
      } finally {
        try { controller.close(); } catch { /* already closed */ }
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "application/x-ndjson; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
