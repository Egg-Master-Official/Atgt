// ARTEX /api/php-scan — NDJSON streaming PHP security scanner
// Protocol: one JSON object per line: {"event":"...","data":{...}}
import { NextRequest } from "next/server";
import { scanPhpCode, PHP_BUG_CLASSES } from "@/lib/artex/php-scanner";
import type { StreamEvent } from "@/lib/artex/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export async function POST(req: NextRequest) {
  let code = "";
  try {
    const body = await req.json();
    code = typeof body?.code === "string" ? body.code : "";
  } catch {
    code = "";
  }

  const encoder = new TextEncoder();
  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      // abort-safe send: client disconnect pe enqueue throw na ho
      let open = true;
      const send = (ev: StreamEvent) => {
        if (!open) return;
        try {
          controller.enqueue(encoder.encode(JSON.stringify(ev) + "\n"));
        } catch {
          open = false;
        }
      };
      req.signal?.addEventListener("abort", () => { open = false; });

      if (!code.trim()) {
        send({ event: "error", data: { message: "PHP code empty — phpscan ke baad code paste karo, 'END' line se finish karo." } });
        controller.close();
        return;
      }

      send({ event: "start", data: { file: "pasted-input.php", size: code.length, engines: PHP_BUG_CLASSES.length, timestamp: new Date().toISOString() } });
      await sleep(120);
      send({ event: "log", data: { message: `[phpscan] Loading ${PHP_BUG_CLASSES.length} detection engines: ${PHP_BUG_CLASSES.map((c) => c.code).join(", ")}` } });
      await sleep(150);
      send({ event: "log", data: { message: `[phpscan] Tokenizing input... ${code.split(/\r?\n/).length} lines` } });
      await sleep(180);
      send({ event: "log", data: { message: "[phpscan] Building taint graph (user-input sources -> sinks)..." } });
      await sleep(200);

      const { findings, summary } = scanPhpCode(code);

      if (findings.length === 0) {
        await sleep(150);
        send({ event: "log", data: { message: "[phpscan] Sinks scan complete — koi dangerous pattern nahi mila.", level: "ok" } });
      }

      for (let i = 0; i < findings.length; i++) {
        const fd = findings[i];
        await sleep(180);
        send({
          event: "log",
          data: {
            message: `[phpscan] [${i + 1}/${findings.length}] ${fd.severity} → ${fd.code} @ line ${fd.line} (${fd.bugClass}, ${fd.cwe})`,
            level: fd.severity === "CRITICAL" || fd.severity === "HIGH" ? "error" : "warn",
          },
        });
        await sleep(120);
        send({ event: "finding", data: fd });
      }

      await sleep(160);
      send({
        event: "score",
        data: {
          score: 100 - summary.riskScore,
          max: 100,
          verdict: summary.verdict,
        },
      });
      send({
        event: "done",
        data: {
          summary,
          defenceNote: "Har bug card me ATTACK scenario + ATTACK CODE + DEFENCE + DEFENCE CODE (copy-able fix) attached hai. Same bug-class ke repeats merged cards me hai (lines listed).",
        },
      });
      controller.close();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "application/x-ndjson; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
