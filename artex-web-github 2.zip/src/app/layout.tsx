import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "ARTEX Security Suite — Website Scanner · Token Auditor · Live Terminal",
  description:
    "ARTEX Security Suite: 7-module website scanner with attack/defence reports, on-chain token auditor with ATTACKABLE verdict, live terminal with scan/audit/phpscan commands and NDJSON streaming.",
  keywords: ["ARTEX", "security scanner", "token auditor", "phpscan", "solidity audit", "penetration testing", "web security"],
  authors: [{ name: "ARTEX" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "ARTEX Security Suite",
    description: "Website scanner, token auditor and live security terminal — attack + defence in one place.",
    siteName: "ARTEX",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
