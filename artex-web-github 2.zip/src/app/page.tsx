"use client";
// ARTEX Security Suite — main page (All-in-One landing + tool tabs)
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AllInOne } from "@/components/artex/all-in-one";
import { WebsiteScanner } from "@/components/artex/website-scanner";
import { TokenAuditor } from "@/components/artex/token-auditor";
import { LiveTerminal } from "@/components/artex/live-terminal";
import { Radar, Coins, TerminalSquare, ShieldHalf, Zap } from "lucide-react";

export default function Home() {
  const [tab, setTab] = useState("ai");
  return (
    <div className="min-h-screen flex flex-col bg-zinc-950 text-zinc-100">
      <header className="border-b border-emerald-900/40 bg-black/60 backdrop-blur">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-emerald-600 flex items-center justify-center">
              <ShieldHalf className="h-6 w-6 text-black" />
            </div>
            <div>
              <h1 className="text-xl font-bold font-mono tracking-widest text-emerald-400">ARTEX</h1>
              <p className="text-[11px] font-mono text-zinc-500">SECURITY SUITE v2.4 — ek box, sab engines, real attack + defence code, live data</p>
            </div>
          </div>
          <div className="hidden sm:flex items-center gap-2 font-mono text-[10px] text-emerald-700">
            <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" /> ONLINE
          </div>
        </div>
      </header>

      <main className="flex-1 w-full max-w-6xl mx-auto px-4 py-6">
        <Tabs value={tab} onValueChange={setTab} className="w-full">
          <TabsList className="grid grid-cols-4 w-full bg-zinc-900 border border-emerald-900/40 mb-6">
            <TabsTrigger value="ai" className="font-mono text-[11px] sm:text-xs data-[state=active]:bg-red-600 data-[state=active]:text-white">
              <Zap className="h-4 w-4 mr-1" /> All-in-One
            </TabsTrigger>
            <TabsTrigger value="scanner" className="font-mono text-[11px] sm:text-xs data-[state=active]:bg-emerald-600 data-[state=active]:text-black">
              <Radar className="h-4 w-4 mr-1" /> Scanner
            </TabsTrigger>
            <TabsTrigger value="auditor" className="font-mono text-[11px] sm:text-xs data-[state=active]:bg-emerald-600 data-[state=active]:text-black">
              <Coins className="h-4 w-4 mr-1" /> Auditor
            </TabsTrigger>
            <TabsTrigger value="terminal" className="font-mono text-[11px] sm:text-xs data-[state=active]:bg-emerald-600 data-[state=active]:text-black">
              <TerminalSquare className="h-4 w-4 mr-1" /> Terminal
            </TabsTrigger>
          </TabsList>

          <TabsContent value="ai">
            <AllInOne />
          </TabsContent>
          <TabsContent value="scanner">
            <WebsiteScanner />
          </TabsContent>
          <TabsContent value="auditor">
            <TokenAuditor />
          </TabsContent>
          <TabsContent value="terminal">
            <LiveTerminal />
          </TabsContent>
        </Tabs>
      </main>

      <footer className="mt-auto border-t border-emerald-900/40 bg-black/60">
        <div className="max-w-6xl mx-auto px-4 py-3 flex flex-col sm:flex-row items-center justify-between gap-1">
          <p className="font-mono text-[11px] text-zinc-600">ARTEX Security Suite — ethical security testing only</p>
          <p className="font-mono text-[11px] text-emerald-800">11 modules · 17 solidity detectors · 18 php bug classes · live chain telemetry · attack+defence code har finding pe</p>
        </div>
      </footer>
    </div>
  );
}
