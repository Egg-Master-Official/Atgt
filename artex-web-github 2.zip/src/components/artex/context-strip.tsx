"use client";
// ARTEX — STRICT PRAGMA CONTEXT STRIP (dashboard badges)
// CRITICAL AUDIT RULES ka visible proof: jo version context declared spec se mila,
// wahi badges me dikhta hai — koi assumed era / assumed SafeMath claim nahi.
import { Badge } from "@/components/ui/badge";
import { FileCode2 } from "lucide-react";
import type { PragmaContext } from "@/lib/artex/types";

export function ContextStrip({ ctx }: { ctx: PragmaContext }) {
  const eraCls =
    ctx.era === "MODERN"
      ? "bg-emerald-700 text-black"
      : ctx.era === "LEGACY"
        ? "bg-amber-600 text-black"
        : ctx.era === "AMBIGUOUS"
          ? "bg-red-600 text-white animate-pulse"
          : "bg-zinc-700 text-zinc-200";

  return (
    <div className="rounded-lg border border-zinc-800 bg-black px-3 py-2 flex flex-wrap items-center gap-1.5">
      <span className="flex items-center gap-1 font-mono text-[10px] font-bold text-zinc-400 tracking-wider mr-1">
        <FileCode2 className="h-3 w-3" /> PRAGMA CONTEXT
      </span>
      <Badge className="font-mono text-[9px] bg-zinc-800 text-zinc-200" title="EXACT declared compiler spec — rule #1">
        {ctx.hasPragma ? ctx.pragmaRaw : "UNDECLARED"}
      </Badge>
      <Badge className={`font-mono text-[9px] px-1.5 py-0 ${eraCls}`} title={ctx.era === "MODERN" ? "checked arithmetic guaranteed (>=0.8)" : ctx.era === "LEGACY" ? "<0.8 — arithmetic wrap possible" : ctx.era === "AMBIGUOUS" ? "range 0.8 cross karta hai — conditional findings" : "version unknown — assumption-free mode"}>
        {ctx.era}
      </Badge>
      {ctx.contractType !== "NONE" && (
        <Badge className="font-mono text-[9px] bg-zinc-800 text-emerald-300" title="rule #3 classification">
          {ctx.contractType}{ctx.contractName ? `: ${ctx.contractName}` : ""}
        </Badge>
      )}
      {(ctx.era === "LEGACY" || ctx.safeMath) && (
        <Badge className={`font-mono text-[9px] px-1.5 py-0 ${ctx.safeMath ? "bg-emerald-900 text-emerald-300" : "bg-amber-900 text-amber-300"}`} title="rule #1: SafeMath sirf EXPLICIT presence pe claim hota hai">
          SafeMath: {ctx.safeMath ? "verified" : "absent"}
        </Badge>
      )}
      {ctx.ozModules.length > 0 && (
        <Badge className="font-mono text-[9px] bg-indigo-950 text-indigo-300 border border-indigo-900" title={`OpenZeppelin audited base classes: ${ctx.ozModules.join(", ")}`}>
          OZ ×{ctx.ozModules.length}
        </Badge>
      )}
      {ctx.uncheckedBlocks.length > 0 && (
        <Badge className="font-mono text-[9px] bg-red-950 text-red-300 border border-red-900" title={`unchecked{} blocks @ line ${ctx.uncheckedBlocks.join(", ")} — checked arithmetic bypass points`}>
          unchecked ×{ctx.uncheckedBlocks.length}
        </Badge>
      )}
    </div>
  );
}
