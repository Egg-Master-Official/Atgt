"use client";
// ARTEX BLACK HAT PERSPECTIVE dashboard panel — attacker-view report (ethical simulation)
// Sections: exploit paths (kill-chains) · privilege escalation · hidden backdoors ·
// fund-drain scenario · false-positive cross-checks (green)
import { Badge } from "@/components/ui/badge";
import { Skull, GitBranch, KeyRound, DoorOpen, Droplets, ShieldCheck, UserCog } from "lucide-react";
import type { BlackHatReport, ExploitPath } from "@/lib/artex/types";

const diffColor = (d: ExploitPath["difficulty"]) =>
  d === "TRIVIAL" ? "bg-red-600 text-white" : d === "EASY" ? "bg-orange-600 text-white" : d === "MEDIUM" ? "bg-amber-600 text-black" : "bg-zinc-600 text-white";

export function BlackHatPanel({ r }: { r: BlackHatReport }) {
  const empty = r.exploitPaths.length === 0 && r.privEsc.length === 0 && r.backdoors.length === 0;
  return (
    <div className="rounded-xl border border-red-900/70 bg-black overflow-hidden">
      {/* HEADER */}
      <div className="flex items-center justify-between flex-wrap gap-2 border-b border-red-900/50 bg-red-950/30 px-4 py-2.5">
        <div className="flex items-center gap-2">
          <Skull className="h-4 w-4 text-red-400" />
          <span className="font-mono text-sm font-bold text-red-400 tracking-wider">BLACK HAT PERSPECTIVE — ATTACKER VIEW</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="font-mono text-[10px] text-zinc-500">{r.sourceMode === "SOURCE" ? "source-verified" : "bytecode-assumed"}</span>
          <Badge className="font-mono text-[9px] bg-red-950 text-red-300 border border-red-900">ETHICAL SIMULATION — defence planning ke liye</Badge>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {empty && (
          <div className="rounded-lg border border-emerald-900/50 bg-emerald-950/20 p-4">
            <p className="font-mono text-xs text-emerald-400">✓ Koi direct exploit path, privilege-escalation vector ya backdoor Nahi mila.</p>
            <p className="font-mono text-[11px] text-zinc-500 mt-1">{r.attackerProfile}</p>
          </div>
        )}

        {/* EXPLOIT PATHS */}
        {r.exploitPaths.length > 0 && (
          <div>
            <div className="flex items-center gap-2 mb-2">
              <GitBranch className="h-3.5 w-3.5 text-red-400" />
              <span className="font-mono text-[11px] font-bold text-red-300 tracking-wide">EXPLOIT PATHS — KILL CHAINS ({r.exploitPaths.length})</span>
            </div>
            <div className="grid gap-2.5 md:grid-cols-2">
              {r.exploitPaths.map((p) => (
                <div key={p.id} className="rounded-lg border border-red-950 bg-red-950/10 p-3 space-y-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono text-[10px] font-bold text-red-500">{p.id}</span>
                    <Badge className={`${diffColor(p.difficulty)} font-mono text-[9px] px-1.5 py-0`}>{p.difficulty}</Badge>
                    <span className="font-mono text-[11px] font-bold text-red-200">{p.title}</span>
                  </div>
                  <ol className="font-mono text-[10px] leading-relaxed text-red-200/70 space-y-0.5">
                    {p.steps.map((s, i) => (
                      <li key={i} className="whitespace-pre-wrap">{s}</li>
                    ))}
                  </ol>
                  <div className="font-mono text-[10px] text-zinc-500">impact: {p.impact}</div>
                  <div className="font-mono text-[10px] text-red-400 font-bold">MAX DAMAGE: {p.maxDamage}</div>
                  {p.derivedFrom.length > 0 && <div className="font-mono text-[9px] text-zinc-600">derived from: {p.derivedFrom.join(" + ")}</div>}
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="grid gap-4 lg:grid-cols-2">
          {/* PRIVILEGE ESCALATION */}
          <div className="rounded-lg border border-red-950 bg-red-950/10 p-3 space-y-2">
            <div className="flex items-center gap-2">
              <KeyRound className="h-3.5 w-3.5 text-red-400" />
              <span className="font-mono text-[11px] font-bold text-red-300 tracking-wide">PRIVILEGE ESCALATION ({r.privEsc.length})</span>
            </div>
            {r.privEsc.length === 0 ? (
              <p className="font-mono text-[10px] text-emerald-400/80">✓ koi escalation vector nahi — ownership paths gated hain</p>
            ) : (
              r.privEsc.map((v, i) => (
                <div key={i} className="space-y-0.5 border-l-2 border-red-900/60 pl-2.5">
                  <div className="font-mono text-[11px] font-bold text-red-200">{v.vector}{v.line ? <span className="text-red-500/70 font-normal"> · L{v.line}</span> : null}</div>
                  <p className="font-mono text-[10px] text-red-200/70 leading-relaxed">{v.detail}</p>
                  <p className="font-mono text-[10px] text-zinc-500">prerequisite: {v.prerequisite}</p>
                </div>
              ))
            )}
          </div>

          {/* FUND DRAIN SCENARIO */}
          <div className={`rounded-lg border p-3 space-y-2 ${r.fundDrain.feasible ? "border-red-950 bg-red-950/10" : "border-emerald-950 bg-emerald-950/10"}`}>
            <div className="flex items-center gap-2">
              <Droplets className={`h-3.5 w-3.5 ${r.fundDrain.feasible ? "text-red-400" : "text-emerald-400"}`} />
              <span className={`font-mono text-[11px] font-bold tracking-wide ${r.fundDrain.feasible ? "text-red-300" : "text-emerald-300"}`}>FUND DRAIN SIMULATION</span>
              <Badge className={`ml-auto font-mono text-[9px] px-1.5 py-0 ${r.fundDrain.feasible ? "bg-red-600 text-white animate-pulse" : "bg-emerald-700 text-black"}`}>
                {r.fundDrain.feasible ? "FEASIBLE" : "BLOCKED"}
              </Badge>
            </div>
            {r.fundDrain.feasible ? (
              <>
                <ol className="font-mono text-[10px] leading-relaxed text-red-200/70 space-y-0.5">
                  {r.fundDrain.steps.map((s, i) => (
                    <li key={i} className="whitespace-pre-wrap">{s}</li>
                  ))}
                </ol>
                <div className="font-mono text-[10px] text-red-400 font-bold">MAX DAMAGE: {r.fundDrain.maxDamage}</div>
              </>
            ) : (
              <ul className="font-mono text-[10px] leading-relaxed text-emerald-300/80 space-y-0.5">
                {r.fundDrain.blockers.map((b, i) => (
                  <li key={i}>✓ {b}</li>
                ))}
              </ul>
            )}
          </div>
        </div>

        {/* HIDDEN BACKDOORS */}
        {r.backdoors.length > 0 && (
          <div>
            <div className="flex items-center gap-2 mb-2">
              <DoorOpen className="h-3.5 w-3.5 text-red-400" />
              <span className="font-mono text-[11px] font-bold text-red-300 tracking-wide">HIDDEN BACKDOORS ({r.backdoors.length}) — HACK/DEFENCE boxes me full detail</span>
            </div>
            <div className="grid gap-2 md:grid-cols-2">
              {r.backdoors.map((b) => (
                <div key={b.id} className="rounded-lg border border-red-950 bg-black p-2.5">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge className="bg-red-600 text-white font-mono text-[9px] px-1.5 py-0">{b.severity}</Badge>
                    <span className="font-mono text-[10px] font-bold text-red-200">{b.title}</span>
                    <span className="font-mono text-[9px] text-zinc-600">L{b.line}</span>
                  </div>
                  <p className="font-mono text-[10px] text-red-200/70 leading-relaxed mt-1">{b.detail}</p>
                  <pre className="mt-1 rounded border border-red-950 bg-red-950/20 p-1.5 font-mono text-[9px] text-red-300/80 overflow-x-auto whitespace-pre-wrap">{b.snippet}</pre>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ATTACKER PROFILE */}
        <div className="flex items-start gap-2 rounded-lg border border-zinc-800 bg-zinc-950 p-2.5">
          <UserCog className="h-3.5 w-3.5 text-zinc-400 mt-0.5" />
          <p className="font-mono text-[10px] text-zinc-400 leading-relaxed">ATTACKER PROFILE: {r.attackerProfile}</p>
        </div>

        {/* FALSE-POSITIVE CROSS-CHECKS (green strip) */}
        <div className="rounded-lg border border-emerald-950 bg-emerald-950/10 p-3">
          <div className="flex items-center gap-2 mb-1.5">
            <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
            <span className="font-mono text-[11px] font-bold text-emerald-300 tracking-wide">FALSE-POSITIVE MITIGATION — CROSS-VERIFICATION LOG</span>
          </div>
          <ul className="font-mono text-[10px] leading-relaxed space-y-0.5">
            {r.crossChecks.map((c, i) => (
              <li key={i} className={c.startsWith("✓") ? "text-emerald-400/90" : c.startsWith("⚠") ? "text-amber-400/90" : "text-zinc-400"}>{c}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
