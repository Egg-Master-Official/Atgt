"use client";
// ARTEX - Website Scanner Tab (11 modules, parallel scan, score, attack/defence)
import { useCallback, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Radar, Loader2, Swords, ShieldCheck, AlertTriangle } from "lucide-react";
import { streamNdjson } from "@/lib/artex/stream-client";
import type { ScanModule, StreamEvent, ScanFinding } from "@/lib/artex/types";

const sevColor = (s: string) =>
  s === "CRITICAL" ? "bg-red-600" : s === "HIGH" ? "bg-orange-600" : s === "MEDIUM" ? "bg-amber-600" : s === "LOW" ? "bg-yellow-700" : "bg-emerald-700";

export function WebsiteScanner() {
  const [target, setTarget] = useState("");
  const [busy, setBusy] = useState(false);
  const [modules, setModules] = useState<ScanModule[]>([]);
  const [logs, setLogs] = useState<string[]>([]);
  const [score, setScore] = useState<number | null>(null);
  const [verdict, setVerdict] = useState("");
  const [openModule, setOpenModule] = useState<string | null>(null);

  const run = useCallback(async () => {
    if (!target.trim() || busy) return;
    setBusy(true);
    setModules([]);
    setLogs([]);
    setScore(null);
    setVerdict("");
    try {
      await streamNdjson("/api/scan", { target }, (ev: StreamEvent) => {
        if (ev.event === "log") setLogs((l) => [...l, ev.data.message]);
        if (ev.event === "module") setModules((m) => [...m, ev.data as ScanModule]);
        if (ev.event === "score") {
          setScore(ev.data.score);
          setVerdict(ev.data.verdict);
        }
      });
    } catch (e) {
      setLogs((l) => [...l, "ERROR: " + (e instanceof Error ? e.message : "scan failed")]);
    } finally {
      setBusy(false);
    }
  }, [target, busy]);

  return (
    <div className="space-y-4">
      <Card className="border-emerald-900/60 bg-zinc-950">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-emerald-400 font-mono text-base">
            <Radar className="h-5 w-5" /> Website Scanner — 11 Security Modules (parallel)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-2">
            <Input
              value={target}
              onChange={(e) => setTarget(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && run()}
              placeholder="https://example.com"
              className="font-mono bg-black border-emerald-900/60 text-emerald-100 placeholder:text-zinc-600"
              disabled={busy}
            />
            <Button onClick={run} disabled={busy || !target.trim()} className="bg-emerald-600 hover:bg-emerald-500 text-black font-bold sm:w-40">
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Radar className="h-4 w-4" />}
              {busy ? "SCANNING..." : "RUN SCAN"}
            </Button>
          </div>
          {logs.length > 0 && (
            <ScrollArea className="mt-3 h-24 rounded-md border border-emerald-900/40 bg-black p-2">
              <div className="font-mono text-xs text-emerald-500/80 space-y-0.5">
                {logs.map((l, i) => (
                  <div key={i}>{l}</div>
                ))}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>

      {score !== null && (
        <Card className="border-emerald-900/60 bg-zinc-950">
          <CardContent className="pt-4">
            <div className="flex items-center justify-between mb-2">
              <span className="font-mono text-sm text-zinc-300">Overall Security Score</span>
              <Badge variant="destructive" className="font-mono">{verdict}</Badge>
            </div>
            <div className="flex items-center gap-3">
              <span className="font-mono text-3xl font-bold text-emerald-400">{score}</span>
              <span className="font-mono text-zinc-600">/100</span>
              <Progress value={score} className="flex-1 h-2" />
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-3 md:grid-cols-2">
        {modules.map((m) => (
          <Card key={m.id} className={`border bg-zinc-950 cursor-pointer transition-colors ${openModule === m.id ? "border-emerald-600" : "border-zinc-800 hover:border-emerald-800"}`} onClick={() => setOpenModule(openModule === m.id ? null : m.id)}>
            <CardHeader className="pb-1">
              <CardTitle className="flex items-center justify-between text-sm">
                <span className="font-mono text-zinc-200">
                  {m.icon === "lock" ? "🔒" : m.icon === "shield" ? "🛡️" : m.icon === "cookie" ? "🍪" : m.icon === "eye" ? "👁️" : m.icon === "globe" ? "🌐" : m.icon === "folder-search" ? "📁" : m.icon === "crosshair" ? "🎯" : m.icon === "external-link" ? "🔀" : m.icon === "mail" ? "📧" : m.icon === "image" ? "🖼️" : m.icon === "alert-triangle" ? "⚠️" : "📝"} {m.name}
                </span>
                <span className={`font-mono px-2 py-0.5 rounded text-xs ${
                  m.status === "PASS" ? "text-emerald-400 bg-emerald-950" : m.status === "WARN" ? "text-amber-400 bg-amber-950" : "text-red-400 bg-red-950"
                }`}>{m.status} {m.score}</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="font-mono text-xs text-zinc-500">{m.summary}</div>
              {openModule === m.id && (
                <div className="mt-3 space-y-3">
                  {m.findings.length === 0 && <div className="font-mono text-xs text-zinc-600">No findings.</div>}
                  {m.findings.map((fd: ScanFinding, i: number) => (
                    <div key={i} className="rounded-md border border-zinc-800 bg-black p-3 space-y-2">
                      <div className="flex items-center gap-2">
                        <Badge className={`${sevColor(fd.severity)} text-white font-mono text-[10px]`}>{fd.severity}</Badge>
                        <span className="font-mono text-xs text-zinc-200">{fd.title}</span>
                      </div>
                      {fd.detail && <div className="font-mono text-[11px] text-zinc-500">{fd.detail}</div>}
                      {fd.attack && (
                        <div className="flex gap-2 text-[11px]">
                          <Swords className="h-3.5 w-3.5 text-red-500 shrink-0 mt-0.5" />
                          <p className="text-red-300/90 leading-relaxed">{fd.attack}</p>
                        </div>
                      )}
                      {fd.attackCode && (
                        <pre className="ml-5 rounded-md border border-red-950 bg-red-950/20 p-2.5 font-mono text-[10px] leading-relaxed text-red-300/90 overflow-x-auto whitespace-pre-wrap">{fd.attackCode}</pre>
                      )}
                      {fd.defence && (
                        <div className="flex gap-2 text-[11px]">
                          <ShieldCheck className="h-3.5 w-3.5 text-emerald-500 shrink-0 mt-0.5" />
                          <p className="text-emerald-300/90 leading-relaxed whitespace-pre-wrap font-mono">{fd.defence}</p>
                        </div>
                      )}
                      {fd.defenceCode && (
                        <pre className="ml-5 rounded-md border border-emerald-950 bg-emerald-950/20 p-2.5 font-mono text-[10px] leading-relaxed text-emerald-300/90 overflow-x-auto whitespace-pre-wrap">{fd.defenceCode}</pre>
                      )}
                    </div>
                  ))}
                </div>
              )}
              {openModule !== m.id && m.findings.some((fd) => fd.severity === "CRITICAL" || fd.severity === "HIGH") && (
                <div className="mt-2 flex items-center gap-1 text-amber-500 font-mono text-[11px]">
                  <AlertTriangle className="h-3 w-3" /> {m.findings.length} issue(s) — click to expand attack/defence
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
