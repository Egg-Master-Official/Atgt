"use client";
// ARTEX - Live Terminal (scan / audit / phpscan / history commands, NDJSON streaming)
import { useCallback, useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { TerminalSquare, Trash2 } from "lucide-react";
import { streamNdjson } from "@/lib/artex/stream-client";
import type { StreamEvent, PhpFinding, SolidityFinding, ScanFinding, BlackHatReport, PragmaContext } from "@/lib/artex/types";

type Line = { id: number; kind: string; text: string };

const KIND_CLASS: Record<string, string> = {
  input: "text-emerald-400 font-bold",
  output: "text-zinc-300",
  error: "text-red-400",
  success: "text-emerald-400",
  warn: "text-amber-400",
  muted: "text-zinc-500",
  attack: "text-red-300",
  defence: "text-emerald-300",
  heading: "text-cyan-400 font-bold",
};

const HELP = [
  { cmd: "scan <url>", desc: "Website security scan — 11 parallel modules, score + ATTACK/DEFENCE report" },
  { cmd: "audit 0x... | audit --paste", desc: "Token audit — live telemetry + 17 detectors + BLACK HAT perspective (exploit paths/backdoors)" },
  { cmd: "phpscan", desc: "PHP code paste mode kholo — END likh ke submit: har bug ke saath ATTACK method + DEFENCE PHP fix" },
  { cmd: "phpscan --demo", desc: "Vulnerable demo PHP code auto-load karke phpscan chalao (18 bug classes)" },
  { cmd: "history", desc: "Pichle commands dikhao (persistent)" },
  { cmd: "clear", desc: "Terminal saaf karo" },
  { cmd: "help", desc: "Ye help dikhao" },
];

const DEMO_PHP = `<?php
// vulnerable.php - demo (18 bug classes ka live sample)
$conn = mysqli_connect("localhost", "root", "", "shop");
$id = $_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM products WHERE id = " . $id);
$user = $_POST['username'];
echo "Welcome " . $user;
$cmd = $_GET['cmd'];
system("ping " . $cmd);
$page = $_GET['page'];
include($page);
eval($_POST['action']);
$data = unserialize($_COOKIE['cart']);
$xml = simplexml_load_string($_POST['xml']);
$url = $_GET['url'];
file_get_contents($url);
if ($_POST) { $conn->query("UPDATE users SET last=NOW()"); }
mysqli_query($conn, "UPDATE users SET name='" . $_POST['name'] . "'");
$target = $_FILES['avatar'];
move_uploaded_file($target['tmp_name'], "uploads/" . $target['name']);
define('API_KEY', 'sk_live_51H8xYq2eKvZ9T3wReal');
$password = "Admin@123";
$hash = md5($password);
$reset_token = uniqid();
setcookie("session_id", $reset_token);
ini_set('display_errors', 1);
phpinfo();
header("Location: " . $_GET['next']);
unlink($_GET['file']);
var_dump($_GET);
?>`;

export function LiveTerminal() {
  const [lines, setLines] = useState<Line[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [pasteMode, setPasteMode] = useState(false);
  const [pasteBuffer, setPasteBuffer] = useState<string[]>([]);
  // paste mode kis command ke liye khula tha — END pe sahi engine route ho (audit vs phpscan)
  const pasteTargetRef = useRef<"phpscan" | "audit">("phpscan");
  const [history, setHistory] = useState<string[]>([]);
  const idRef = useRef(0);
  const boxRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const push = useCallback((kind: string, text: string) => {
    setLines((ls) => [...ls.slice(-400), { id: ++idRef.current, kind, text }]);
  }, []);

  // load history
  useEffect(() => {
    try {
      const h = JSON.parse(localStorage.getItem("artex-history") ?? "[]");
      if (Array.isArray(h)) setHistory(h);
    } catch { /* noop */ }
    push("heading", "ARTEX Security Suite v2.4 — Live Terminal");
    push("muted", "Commands: help · scan <url> · audit 0x... · phpscan · phpscan --demo · history · clear");
  }, []);

  useEffect(() => {
    boxRef.current?.scrollTo({ top: boxRef.current.scrollHeight });
  }, [lines]);

  const printFindingGeneric = useCallback((fd: Record<string, unknown>) => {
    const sev = String(fd.severity ?? "INFO");
    const also = Array.isArray(fd.alsoLines) && fd.alsoLines.length > 0 ? ` (+${fd.alsoLines.length} more: ${fd.alsoLines.join(", ")})` : "";
    push("error", `  [${sev}] ${fd.title ?? fd.bugClass ?? "finding"}${fd.line ? ` @ line ${fd.line}` : ""}${also}${fd.code ? ` (${fd.code})` : ""}`);
    if (fd.snippet) push("muted", `  > ${String(fd.snippet).slice(0, 200)}`);
    if (fd.attack) push("attack", `  ${fd.attack}`);
    if (fd.attackCode) push("attack", `  ATTACK CODE:\n${String(fd.attackCode).split("\n").map((l) => "    " + l).join("\n")}`);
    if (fd.defence) push("defence", `  ${fd.defence}`);
    if (fd.defenceCode) push("defence", `  DEFENCE CODE:\n${String(fd.defenceCode).split("\n").map((l) => "    " + l).join("\n")}`);
    push("muted", "");
  }, [push]);

  const runPhpScan = useCallback(async (code: string) => {
    setBusy(true);
    try {
      await streamNdjson("/api/php-scan", { code }, (ev: StreamEvent) => {
        if (ev.event === "start") push("heading", `phpscan → ${String(ev.data.file ?? "input")} (${String(ev.data.size ?? 0)} bytes, ${String(ev.data.engines ?? 10)} engines)`);
        if (ev.event === "log") push(ev.data.level === "error" ? "error" : ev.data.level === "warn" ? "warn" : ev.data.level === "ok" ? "success" : "output", ev.data.message);
        if (ev.event === "finding") printFindingGeneric(ev.data as unknown as Record<string, unknown>);
        if (ev.event === "score") {
          const v = String(ev.data.verdict);
          push(v === "ATTACKABLE" ? "error" : v === "HARDENED" ? "success" : "warn", `SCORE: ${ev.data.score}/${ev.data.max} — VERDICT: ${v}`);
        }
        if (ev.event === "done") {
          const s = ev.data.summary as { critical: number; high: number; medium: number; low: number; totalFindings: number };
          if (s) push("heading", `SUMMARY: ${s.totalFindings} bug(s) — ${s.critical} CRITICAL, ${s.high} HIGH, ${s.medium} MEDIUM, ${s.low} LOW`);
          push("success", "phpscan complete ✓ har bug ke saath ATTACK method + DEFENCE PHP fix upar print hua hai");
        }
        if (ev.event === "error") push("error", ev.data.message);
      });
    } catch (e) {
      push("error", "phpscan failed: " + (e instanceof Error ? e.message : "unknown"));
    } finally {
      setBusy(false);
    }
  }, [push, printFindingGeneric]);

  const runScan = useCallback(async (target: string) => {
    setBusy(true);
    try {
      await streamNdjson("/api/scan", { target }, (ev: StreamEvent) => {
        if (ev.event === "log") push(ev.data.level === "error" ? "error" : ev.data.level === "warn" ? "warn" : ev.data.level === "ok" ? "success" : "output", ev.data.message);
        if (ev.event === "finding") printFindingGeneric(ev.data as unknown as Record<string, unknown>);
        if (ev.event === "score") push("heading", `SCORE: ${ev.data.score}/${ev.data.max} — VERDICT: ${ev.data.verdict}`);
        if (ev.event === "done") push("success", `scan complete ✓ ${ev.data.modules} modules, target: ${ev.data.target}`);
        if (ev.event === "error") push("error", ev.data.message);
      });
    } catch (e) {
      push("error", "scan failed: " + (e instanceof Error ? e.message : "unknown"));
    } finally {
      setBusy(false);
    }
  }, [push, printFindingGeneric]);

  const runAudit = useCallback(async (address: string, source?: string) => {
    setBusy(true);
    try {
      await streamNdjson("/api/audit", { address, source }, (ev: StreamEvent) => {
        if (ev.event === "log") push(ev.data.level === "error" ? "error" : ev.data.level === "warn" ? "warn" : ev.data.level === "ok" ? "success" : "output", ev.data.message);
        if (ev.event === "context") {
          const c = ev.data as PragmaContext;
          push("muted", `[pragma] ${c.hasPragma ? c.pragmaRaw : "UNDECLARED"} → ${c.era} era · ${c.contractType}${c.contractName ? ` ${c.contractName}` : ""}${c.safeMath ? " · SafeMath verified" : ""}${c.ozModules.length ? ` · OZ ×${c.ozModules.length}` : ""}`);
        }
        if (ev.event === "finding") printFindingGeneric(ev.data as unknown as Record<string, unknown>);
        if (ev.event === "blackhat") {
          const r = ev.data as BlackHatReport;
          push("heading", `🏴 BLACK HAT PERSPECTIVE — ${r.exploitPaths.length} path(s) · ${r.privEsc.length} priv-esc · ${r.backdoors.length} backdoor(s)`);
          for (const p of r.exploitPaths) {
            push("attack", `  ${p.id} [${p.difficulty}] ${p.title}`);
            p.steps.forEach((s) => push("muted", `    ${s}`));
            push("attack", `    → MAX DAMAGE: ${p.maxDamage}`);
          }
          for (const v of r.privEsc) push("warn", `  PRIV-ESC: ${v.vector} — ${v.prerequisite}`);
          if (r.fundDrain.feasible) {
            push("error", `  FUND DRAIN: FEASIBLE — ${r.fundDrain.maxDamage}`);
            r.fundDrain.steps.forEach((s) => push("muted", `    ${s}`));
          } else {
            r.fundDrain.blockers.forEach((b) => push("success", `  BLOCKED: ${b}`));
          }
          r.crossChecks.forEach((c) => push(c.startsWith("✓") ? "success" : c.startsWith("⚠") ? "warn" : "muted", `  ${c}`));
          push("muted", `  ATTACKER PROFILE: ${r.attackerProfile}`);
        }
        if (ev.event === "score") {
          const v = String(ev.data.verdict);
          push(v === "ATTACKABLE" ? "error" : "success", `SAFETY: ${ev.data.score}/${ev.data.max} — VERDICT: ${v}`);
        }
        if (ev.event === "done") push("success", `audit complete ✓ verdict: ${ev.data.verdict}`);
        if (ev.event === "error") push("error", ev.data.message);
      });
    } catch (e) {
      push("error", "audit failed: " + (e instanceof Error ? e.message : "unknown"));
    } finally {
      setBusy(false);
    }
  }, [push, printFindingGeneric]);

  const handleCommand = useCallback(async (raw: string) => {
    const cmd = raw.trim();
    if (!cmd) return;
    push("input", `artex@secure:~$ ${cmd}`);
    const nextHist = [...history, cmd].slice(-50);
    setHistory(nextHist);
    try { localStorage.setItem("artex-history", JSON.stringify(nextHist)); } catch { /* noop */ }

    const [name, ...args] = cmd.split(/\s+/);
    switch (name.toLowerCase()) {
      case "help":
        push("heading", "Available commands:");
        for (const h of HELP) push("output", `  ${h.cmd.padEnd(28)} ${h.desc}`);
        break;
      case "clear":
        setLines([]);
        break;
      case "history":
        if (history.length === 0) push("muted", "(empty)");
        history.slice(-20).forEach((h, i) => push("output", `  ${String(i + 1).padStart(3)}  ${h}`));
        break;
      case "scan":
        if (!args[0]) { push("error", "usage: scan <url>   jaise: scan example.com"); break; }
        await runScan(args[0]);
        break;
      case "audit": {
        if (args[0] === "--paste") {
          setPasteMode(true);
          setPasteBuffer([]);
          pasteTargetRef.current = "audit";
          push("heading", "Paste mode: Solidity source paste karo aur END line likh ke submit...");
          break;
        }
        if (!args[0] || !/^0x[a-fA-F0-9]{40}$/.test(args[0])) { push("error", "usage: audit 0x<40-hex-address>  |  audit --paste"); break; }
        await runAudit(args[0]);
        break;
      }
      case "phpscan":
        if (args[0] === "--demo") {
          push("muted", "demo vulnerable PHP code load ho gaya...");
          await runPhpScan(DEMO_PHP);
        } else {
          setPasteMode(true);
          setPasteBuffer([]);
          pasteTargetRef.current = "phpscan";
          push("heading", "PHP PASTE MODE — vulnerable PHP code paste karo, phir ek new line me sirf END likh ke submit karo. (cancel karne ke liye CANCEL likho)");
        }
        break;
      default:
        push("error", `command not found: ${name} — 'help' type karo`);
    }
  }, [history, push, runScan, runAudit, runPhpScan]);

  const onSubmit = useCallback(async () => {
    const val = input;
    setInput("");
    if (busy) return;
    if (pasteMode) {
      if (val.trim() === "END") {
        setPasteMode(false);
        const code = pasteBuffer.join("\n");
        if (!code.trim()) { push("warn", "(empty paste — cancel)"); return; }
        if (pasteTargetRef.current === "audit") {
          push("muted", `[paste received: ${code.length} bytes] audit start...`);
          await runAudit("", code);
        } else {
          push("muted", `[paste received: ${code.length} bytes] phpscan start...`);
          await runPhpScan(code);
        }
      } else if (val.trim() === "CANCEL") {
        setPasteMode(false);
        setPasteBuffer([]);
        push("warn", "paste mode cancelled");
      } else {
        setPasteBuffer((b) => [...b, val]);
      }
      return;
    }
    await handleCommand(val);
  }, [input, busy, pasteMode, pasteBuffer, handleCommand, runPhpScan, runAudit, push]);

  return (
    <div className="rounded-lg border border-emerald-900/60 bg-black overflow-hidden">
      <div className="flex items-center justify-between border-b border-emerald-900/40 px-3 py-2 bg-zinc-950">
        <div className="flex items-center gap-2 font-mono text-xs text-emerald-500">
          <TerminalSquare className="h-4 w-4" />
          ARTEX LIVE TERMINAL {pasteMode && <span className="text-amber-400 animate-pulse">— PASTE MODE ({pasteBuffer.length} lines)</span>}
          {busy && <span className="text-cyan-400 animate-pulse">— RUNNING...</span>}
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="h-7 text-zinc-500 hover:text-red-400 hover:bg-red-950"
          onClick={() => setLines([])}
          aria-label="Clear terminal"
        >
          <Trash2 className="h-3.5 w-3.5" />
        </Button>
      </div>
      <div
        ref={boxRef}
        className="h-[420px] overflow-y-auto p-3 font-mono text-xs leading-relaxed cursor-text"
        onClick={() => inputRef.current?.focus()}
        role="log"
        aria-live="polite"
      >
        {lines.map((l) => (
          <pre key={l.id} className={`whitespace-pre-wrap break-words ${KIND_CLASS[l.kind] ?? "text-zinc-300"}`}>{l.text}</pre>
        ))}
        <div className="flex items-center gap-2 mt-1">
          <span className={`font-bold ${pasteMode ? "text-amber-400" : "text-emerald-400"}`}>
            {pasteMode ? "paste>" : "artex@secure:~$"}
          </span>
          <input
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); onSubmit(); } }}
            className="flex-1 bg-transparent outline-none text-emerald-100 caret-emerald-400 font-mono text-xs"
            spellCheck={false}
            autoComplete="off"
            aria-label="Terminal input"
            disabled={busy && !pasteMode}
          />
        </div>
      </div>
      <div className="border-t border-emerald-900/40 px-3 py-1.5 bg-zinc-950 font-mono text-[10px] text-zinc-600">
        tip: <span className="text-emerald-700">phpscan --demo</span> se turant test karo · scan example.com · audit 0xdAC17F958D2ee523a2206206994597C13D831ec7
      </div>
    </div>
  );
}
