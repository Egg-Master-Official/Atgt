"use client";
// ARTEX - Token Auditor Tab (on-chain + Solidity audit, ATTACKABLE verdict)
import { useCallback, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import { Coins, Loader2, Swords, ShieldCheck, FileCode2 } from "lucide-react";
import { streamNdjson } from "@/lib/artex/stream-client";
import { BlackHatPanel } from "@/components/artex/blackhat-panel";
import { ContextStrip } from "@/components/artex/context-strip";
import type { StreamEvent, SolidityFinding, OnChainInfo, BlackHatReport, PragmaContext } from "@/lib/artex/types";

const sevColor = (s: string) =>
  s === "CRITICAL" ? "bg-red-600" : s === "HIGH" ? "bg-orange-600" : s === "MEDIUM" ? "bg-amber-600" : s === "LOW" ? "bg-yellow-700" : "bg-zinc-600";

export function TokenAuditor() {
  const [address, setAddress] = useState("");
  const [source, setSource] = useState("");
  const [busy, setBusy] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);
  const [findings, setFindings] = useState<SolidityFinding[]>([]);
  const [onChain, setOnChain] = useState<OnChainInfo | null>(null);
  const [score, setScore] = useState<number | null>(null);
  const [verdict, setVerdict] = useState("");
  const [reason, setReason] = useState("");
  const [chain, setChain] = useState("");
  const [blackhat, setBlackhat] = useState<BlackHatReport | null>(null);
  const [ctx, setCtx] = useState<PragmaContext | null>(null);
  const [showPaste, setShowPaste] = useState(false);

  const run = useCallback(async () => {
    if (busy || (!address.trim() && !source.trim())) return;
    setBusy(true);
    setLogs([]);
    setFindings([]);
    setOnChain(null);
    setScore(null);
    setVerdict("");
    setReason("");
    setChain("");
    setBlackhat(null);
    setCtx(null);
    try {
      await streamNdjson("/api/audit", { address, source }, (ev: StreamEvent) => {
        if (ev.event === "log") setLogs((l) => [...l, ev.data.message]);
        if (ev.event === "context") setCtx(ev.data as PragmaContext);
        if (ev.event === "finding") setFindings((fl) => [...fl, ev.data as SolidityFinding]);
        if (ev.event === "blackhat") setBlackhat(ev.data as BlackHatReport);
        if (ev.event === "done") {
          setOnChain(ev.data.onChain as OnChainInfo);
          setVerdict(String(ev.data.verdict));
          setScore(100 - Number(ev.data.riskScore ?? 0));
          setReason(String(ev.data.reason ?? ""));
          const ch = ev.data.chain as { live?: boolean; block?: number; gasGwei?: string; chainId?: number } | undefined;
          if (ch?.live) setChain(`LIVE ▸ block #${ch.block?.toLocaleString("en-US") ?? "?"} · gas ${ch.gasGwei ?? "?"} gwei · chain ${ch.chainId ?? 1}`);
        }
      });
    } catch (e) {
      setLogs((l) => [...l, "ERROR: " + (e instanceof Error ? e.message : "audit failed")]);
    } finally {
      setBusy(false);
    }
  }, [address, source, busy]);

  return (
    <div className="space-y-4">
      <Card className="border-emerald-900/60 bg-zinc-950">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-emerald-400 font-mono text-base">
            <Coins className="h-5 w-5" /> Token Auditor — On-chain + Solidity Static Audit
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex flex-col sm:flex-row gap-2">
            <Input
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="0x contract address (Ethereum mainnet)"
              className="font-mono bg-black border-emerald-900/60 text-emerald-100 placeholder:text-zinc-600"
              disabled={busy}
            />
            <Button onClick={() => setShowPaste(!showPaste)} variant="outline" className="border-emerald-800 text-emerald-400 hover:bg-emerald-950 sm:w-44 font-mono text-xs">
              <FileCode2 className="h-4 w-4" /> {showPaste ? "HIDE SOURCE" : "PASTE SOLIDITY"}
            </Button>
            <Button onClick={run} disabled={busy || (!address.trim() && !source.trim())} className="bg-emerald-600 hover:bg-emerald-500 text-black font-bold sm:w-36">
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Coins className="h-4 w-4" />}
              {busy ? "AUDITING..." : "RUN AUDIT"}
            </Button>
          </div>
          {showPaste && (
            <Textarea
              value={source}
              onChange={(e) => setSource(e.target.value)}
              placeholder="pragma solidity ^0.8.0;\ncontract MyToken { ... }  // Solidity source paste karo (verified source etherscan se copy karo)"
              className="font-mono text-xs bg-black border-emerald-900/60 text-emerald-100 min-h-40 placeholder:text-zinc-600"
              disabled={busy}
            />
          )}
          {logs.length > 0 && (
            <ScrollArea className="h-28 rounded-md border border-emerald-900/40 bg-black p-2">
              <div className="font-mono text-xs text-emerald-500/80 space-y-0.5">
                {logs.map((l, i) => (
                  <div key={i}>{l}</div>
                ))}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>

      {ctx && <ContextStrip ctx={ctx} />}

      {verdict && (
        <Card className={`bg-zinc-950 ${verdict === "ATTACKABLE" ? "border-red-700" : verdict === "SAFE" ? "border-emerald-700" : "border-amber-700"}`}>
          <CardContent className="pt-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-mono text-sm text-zinc-300">FINAL VERDICT</span>
              <Badge className={`font-mono text-sm px-3 py-1 ${verdict === "ATTACKABLE" ? "bg-red-600 text-white animate-pulse" : verdict === "SAFE" ? "bg-emerald-600 text-black" : "bg-amber-600 text-black"}`}>
                {verdict}
              </Badge>
            </div>
            <div className="flex items-center gap-3">
              <span className="font-mono text-3xl font-bold text-emerald-400">{score}</span>
              <span className="font-mono text-zinc-600">/100 safety</span>
              <Progress value={score ?? 0} className="flex-1 h-2" />
            </div>
            {reason && <p className="font-mono text-xs text-zinc-500">{reason}</p>}
            {chain && (
              <p className="font-mono text-xs text-emerald-500">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse inline-block mr-2" />
                {chain}
              </p>
            )}
            {onChain && (
              <p className="font-mono text-xs text-zinc-600">
                on-chain: {onChain.online ? `LIVE (chain ${onChain.chainId ?? 1})` : "OFFLINE"}{onChain.codeSize !== undefined ? ` · code ${onChain.codeSize}B` : ""}{onChain.name ? ` · ${onChain.name}${onChain.symbol ? ` (${onChain.symbol})` : ""}` : ""}
              </p>
            )}
          </CardContent>
        </Card>
      )}

      {blackhat && <BlackHatPanel r={blackhat} />}

      <div className="space-y-3">
        {findings.map((fd, i) => (
          <Card key={i} className="border-zinc-800 bg-zinc-950">
            <CardHeader className="pb-1">
              <CardTitle className="flex items-center gap-2 text-sm font-mono">
                <Badge className={`${sevColor(fd.severity)} text-white font-mono text-[10px]`}>{fd.severity}</Badge>
                <span className="text-zinc-200">{fd.title}</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {fd.snippet && (
                <pre className="rounded bg-black border border-zinc-800 p-2 text-[11px] font-mono text-zinc-400 overflow-x-auto whitespace-pre-wrap">{`line ${fd.line}: ${fd.snippet}`}</pre>
              )}
              <div className="flex gap-2 text-xs">
                <Swords className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />
                <div className="space-y-1.5 min-w-0 flex-1">
                  <p className="text-red-300/90 leading-relaxed">{fd.attack}</p>
                  {fd.attackCode && (
                    <pre className="rounded-md border border-red-950 bg-red-950/20 p-2.5 font-mono text-[10px] leading-relaxed text-red-300/90 overflow-x-auto whitespace-pre-wrap">{fd.attackCode}</pre>
                  )}
                </div>
              </div>
              <div className="flex gap-2 text-xs">
                <ShieldCheck className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                <div className="space-y-1.5 min-w-0 flex-1">
                  <p className="text-emerald-300/90 leading-relaxed whitespace-pre-wrap font-mono">{fd.defence}</p>
                  {fd.defenceCode && (
                    <pre className="rounded-md border border-emerald-950 bg-emerald-950/20 p-2.5 font-mono text-[10px] leading-relaxed text-emerald-300/90 overflow-x-auto whitespace-pre-wrap">{fd.defenceCode}</pre>
                  )}
                </div>
              </div>
              {fd.cwe && <div className="font-mono text-[10px] text-zinc-600">{fd.cwe}</div>}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
