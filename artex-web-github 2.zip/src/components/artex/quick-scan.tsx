"use client";
// ARTEX QuickScan — website paste karo → live scan → HACK METHOD box + DEFENCE METHOD box
// Dono boxes NDJSON stream se real-time me bharte hain.
import { useCallback, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Zap, Loader2, Swords, ShieldCheck, Copy, Check, Target } from "lucide-react";
import { streamNdjson } from "@/lib/artex/stream-client";
import type { StreamEvent } from "@/lib/artex/types";

interface Pair {
  id: string;
  module: string;
  title: string;
  severity: string;
  attack: string;
  defence: string;
}

const sevBg = (s: string) =>
  s === "CRITICAL" ? "bg-red-600" : s === "HIGH" ? "bg-orange-600" : s === "MEDIUM" ? "bg-amber-600" : s === "LOW" ? "bg-yellow-700" : "bg-emerald-700";

export function QuickScan() {
  const [target, setTarget] = useState("");
  const [busy, setBusy] = useState(false);
  const [pairs, setPairs] = useState<Pair[]>([]);
  const [status, setStatus] = useState("");
  const [modulesDone, setModulesDone] = useState(0);
  const [result, setResult] = useState<{ score: number; verdict: string } | null>(null);
  const [copied, setCopied] = useState<number | null>(null);
  const attackBoxRef = useRef<HTMLDivElement>(null);
  const defenceBoxRef = useRef<HTMLDivElement>(null);

  const autoScroll = useCallback(() => {
    requestAnimationFrame(() => {
      for (const ref of [attackBoxRef, defenceBoxRef]) {
        const el = ref.current;
        if (el) el.scrollTop = el.scrollHeight;
      }
    });
  }, []);

  const run = useCallback(async () => {
    const t = target.trim();
    if (!t || busy) return;
    setBusy(true);
    setPairs([]);
    setResult(null);
    setModulesDone(0);
    setStatus("[*] ARTEX engine warm-up ho raha hai...");
    try {
      await streamNdjson("/api/scan", { target: t }, (ev: StreamEvent) => {
        if (ev.event === "log") {
          setStatus(ev.data.message);
          if (ev.data.level === "error" || ev.data.level === "warn" || ev.data.level === "ok") autoScroll();
        }
        if (ev.event === "module") {
          setModulesDone((m) => m + 1);
          setStatus(`[*] Module complete: ${(ev.data as { name: string }).name} — agla module chal raha hai...`);
        }
        if (ev.event === "finding") {
          const fd = ev.data as { title: string; severity: string; attack: string; defence: string; module?: string };
          setPairs((ps) => [
            ...ps,
            {
              id: `${ps.length}-${fd.title.slice(0, 16)}`,
              module: fd.module ?? "Scanner",
              title: fd.title,
              severity: fd.severity,
              attack: fd.attack || "—",
              defence: fd.defence || "—",
            },
          ]);
          autoScroll();
        }
        if (ev.event === "score") setResult({ score: Number(ev.data.score), verdict: String(ev.data.verdict) });
      });
    } catch (e) {
      setStatus("ERROR: " + (e instanceof Error ? e.message : "scan failed"));
    } finally {
      setBusy(false);
    }
  }, [target, busy, autoScroll]);

  const copyDefence = useCallback(async (i: number, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(i);
      setTimeout(() => setCopied(null), 1500);
    } catch { /* clipboard unavailable */ }
  }, []);

  return (
    <div className="space-y-4">
      {/* ---------- PASTE BOX ---------- */}
      <div className="rounded-xl border border-emerald-900/60 bg-zinc-950 p-5 sm:p-6 shadow-lg shadow-emerald-950/20">
        <div className="flex items-center gap-2 mb-1">
          <Target className="h-4 w-4 text-emerald-400" />
          <h2 className="font-mono text-sm text-emerald-400 tracking-wide">TARGET WEBSITE — PASTE KARO</h2>
        </div>
        <p className="font-mono text-[11px] text-zinc-500 mb-4">URL paste karo aur SCAN dabao — hack + defence live stream hoga</p>
        <div className="flex flex-col sm:flex-row gap-2">
          <input
            value={target}
            onChange={(e) => setTarget(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && run()}
            placeholder="https://example.com  ya  example.com"
            disabled={busy}
            className="flex-1 h-12 rounded-md bg-black border border-emerald-800/60 px-4 font-mono text-sm sm:text-base text-emerald-100 placeholder:text-zinc-600 outline-none focus:border-emerald-500 transition-colors"
            aria-label="Website URL paste karo"
          />
          <Button
            onClick={run}
            disabled={busy || !target.trim()}
            className="h-12 px-6 bg-red-600 hover:bg-red-500 text-white font-bold tracking-wider text-sm sm:w-48"
          >
            {busy ? <Loader2 className="h-5 w-5 animate-spin" /> : <Zap className="h-5 w-5" />}
            {busy ? "SCANNING LIVE..." : "SCAN → HACK vs DEFENCE"}
          </Button>
        </div>
        {status && (
          <div className="mt-3 rounded-md bg-black border border-emerald-900/40 px-3 py-2 font-mono text-[11px] text-emerald-500/90 truncate" aria-live="polite">
            {status}
            {busy && <span className="animate-pulse"> ▌</span>}
          </div>
        )}
        {modulesDone > 0 && (
          <div className="mt-2 font-mono text-[10px] text-zinc-600">
            modules completed: {modulesDone}/7 · findings so far: {pairs.length}
          </div>
        )}
      </div>

      {/* ---------- VERDICT BANNER ---------- */}
      {result && (
        <div className={`rounded-xl border p-4 flex items-center justify-between ${result.verdict === "FORTIFIED" ? "border-emerald-600" : result.verdict === "RESILIENT" ? "border-emerald-700" : "border-red-700"} bg-zinc-950`}>
          <div>
            <div className="font-mono text-[11px] text-zinc-500">FINAL VERDICT — {target.trim()}</div>
            <div className="font-mono text-2xl font-bold text-emerald-400">{result.score}<span className="text-sm text-zinc-600">/100</span></div>
          </div>
          <Badge variant="destructive" className="font-mono text-sm px-4 py-1.5">{result.verdict}</Badge>
        </div>
      )}

      {/* ---------- HACK vs DEFENCE — LIVE BOXES ---------- */}
      <div className="grid gap-4 lg:grid-cols-2">
        {/* HACK BOX */}
        <div className="rounded-xl border border-red-800/70 bg-zinc-950 overflow-hidden flex flex-col">
          <div className="flex items-center justify-between border-b border-red-900/50 bg-red-950/30 px-4 py-2.5">
            <div className="flex items-center gap-2">
              <Swords className="h-4 w-4 text-red-400" />
              <span className="font-mono text-sm font-bold text-red-400 tracking-wider">HACK METHOD</span>
            </div>
            <span className="font-mono text-[10px] text-red-500/80">{busy ? "LIVE..." : "attack techniques"}</span>
          </div>
          <div ref={attackBoxRef} className="h-[420px] overflow-y-auto p-3 space-y-2.5" aria-live="polite">
            {pairs.length === 0 && !busy && (
              <div className="h-full flex items-center justify-center text-center">
                <p className="font-mono text-xs text-zinc-600">⚔️ Upar website paste karke SCAN karo —<br />attack techniques yahan live stream hongi</p>
              </div>
            )}
            {pairs.length === 0 && busy && (
              <div className="h-full flex items-center justify-center">
                <p className="font-mono text-xs text-red-500/70 animate-pulse">target probe ho raha hai...</p>
              </div>
            )}
            {pairs.map((p, i) => (
              <div key={p.id} className="rounded-lg border border-red-900/40 bg-black p-3 space-y-1.5 animate-in fade-in slide-in-from-bottom-1 duration-300">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-mono text-[10px] text-red-600 font-bold">#{String(i + 1).padStart(2, "0")}</span>
                  <Badge className={`${sevBg(p.severity)} text-white font-mono text-[9px] px-1.5 py-0`}>{p.severity}</Badge>
                  <span className="font-mono text-[10px] text-zinc-500">{p.module}</span>
                </div>
                <div className="font-mono text-xs font-bold text-red-300">{p.title}</div>
                <p className="font-mono text-[11px] leading-relaxed text-red-200/70 whitespace-pre-wrap">{p.attack}</p>
              </div>
            ))}
          </div>
        </div>

        {/* DEFENCE BOX */}
        <div className="rounded-xl border border-emerald-800/70 bg-zinc-950 overflow-hidden flex flex-col">
          <div className="flex items-center justify-between border-b border-emerald-900/50 bg-emerald-950/30 px-4 py-2.5">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-emerald-400" />
              <span className="font-mono text-sm font-bold text-emerald-400 tracking-wider">DEFENCE METHOD</span>
            </div>
            <span className="font-mono text-[10px] text-emerald-500/80">{busy ? "LIVE..." : "fix + hardening"}</span>
          </div>
          <div ref={defenceBoxRef} className="h-[420px] overflow-y-auto p-3 space-y-2.5" aria-live="polite">
            {pairs.length === 0 && !busy && (
              <div className="h-full flex items-center justify-center text-center">
                <p className="font-mono text-xs text-zinc-600">🛡️ Har attack ke saamne fix yahan aayega —<br />copy button ke saath</p>
              </div>
            )}
            {pairs.length === 0 && busy && (
              <div className="h-full flex items-center justify-center">
                <p className="font-mono text-xs text-emerald-500/70 animate-pulse">defence engine ready...</p>
              </div>
            )}
            {pairs.map((p, i) => (
              <div key={p.id} className="rounded-lg border border-emerald-900/40 bg-black p-3 space-y-1.5 animate-in fade-in slide-in-from-bottom-1 duration-300">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[10px] text-emerald-600 font-bold">#{String(i + 1).padStart(2, "0")} FIX</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 px-2 text-[10px] font-mono text-zinc-500 hover:text-emerald-400 hover:bg-emerald-950"
                    onClick={() => copyDefence(i, p.defence)}
                    aria-label={`Defence fix #${i + 1} copy karo`}
                  >
                    {copied === i ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                    {copied === i ? "COPIED" : "COPY"}
                  </Button>
                </div>
                <p className="font-mono text-[11px] leading-relaxed text-emerald-200/80 whitespace-pre-wrap">{p.defence}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
