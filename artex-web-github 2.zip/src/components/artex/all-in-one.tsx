"use client";
// ARTEX All-in-One — EK box me sab paste karo: URL / 0x token / PHP code / Solidity
// Engine AUTO-detect hota hai + manual switch bhi hai. Output: live HACK vs DEFENCE boxes
// + real-time elapsed timer + live chain telemetry (block/gas).
import { useCallback, useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Zap, Loader2, Swords, ShieldCheck, Copy, Check, Trash2 } from "lucide-react";
import { streamNdjson } from "@/lib/artex/stream-client";
import { BlackHatPanel } from "@/components/artex/blackhat-panel";
import { ContextStrip } from "@/components/artex/context-strip";
import type { StreamEvent, BlackHatReport, PragmaContext } from "@/lib/artex/types";

type Engine = "AUTO" | "WEBSITE" | "TOKEN" | "PHP" | "SOLIDITY";
type Resolved = Exclude<Engine, "AUTO">;

interface Pair {
  id: string;
  source: string;
  title: string;
  severity: string;
  attack: string;
  attackCode?: string;
  defence: string;
  defenceCode?: string;
  line?: number;
  alsoLines?: number[];
}

const ENGINES: Array<{ id: Engine; label: string; icon: string }> = [
  { id: "AUTO", label: "AUTO", icon: "⚡" },
  { id: "WEBSITE", label: "WEBSITE", icon: "🌐" },
  { id: "TOKEN", label: "TOKEN 0x", icon: "🪙" },
  { id: "PHP", label: "PHP CODE", icon: "🐘" },
  { id: "SOLIDITY", label: "SOLIDITY", icon: "📜" },
];

const ENGINE_LABEL: Record<Resolved, string> = {
  WEBSITE: "WEBSITE SCAN — 11 modules (parallel)",
  TOKEN: "TOKEN AUDIT — live chain telemetry + 17 detectors",
  PHP: "PHP SCAN — 18 bug-class engines",
  SOLIDITY: "SOLIDITY AUDIT — 17 detectors",
};

export function detectEngine(input: string): Resolved | "NONE" | "UNKNOWN" {
  const t = input.trim();
  if (!t) return "NONE";
  if (
    t.includes("<?php") ||
    /\$_(GET|POST|REQUEST|COOKIE|SERVER)\s*\[/.test(t) ||
    /\b(mysqli_query|mysql_query|htmlspecialchars|move_uploaded_file|simplexml_load_string|escapeshellarg|shell_exec|create_function|unserialize\s*\()\b/.test(t) ||
    /\beval\s*\(\s*\$/.test(t)
  ) {
    return "PHP";
  }
  if (/pragma\s+solidity/i.test(t) || (/\bcontract\s+\w+\s*\{/.test(t) && /\b(function|mapping|uint\d+|require|address)\b/.test(t))) {
    return "SOLIDITY";
  }
  if (/^0x[a-fA-F0-9]{40}$/.test(t)) return "TOKEN";
  if (/^https?:\/\/\S+$/i.test(t) || /^[\w-]+(\.[\w-]+)+(\/\S*)?$/.test(t)) return "WEBSITE";
  return "UNKNOWN";
}

const sevBg = (s: string) =>
  s === "CRITICAL" ? "bg-red-600" : s === "HIGH" ? "bg-orange-600" : s === "MEDIUM" ? "bg-amber-600" : s === "LOW" ? "bg-yellow-700" : "bg-emerald-700";

export function AllInOne() {
  const [value, setValue] = useState("");
  const [mode, setMode] = useState<Engine>("AUTO");
  const [busy, setBusy] = useState(false);
  const [pairs, setPairs] = useState<Pair[]>([]);
  const [status, setStatus] = useState("");
  const [engineRan, setEngineRan] = useState<Resolved | null>(null);
  const [chainInfo, setChainInfo] = useState("");
  const [liveChain, setLiveChain] = useState("");
  const [elapsed, setElapsed] = useState(0);
  const [result, setResult] = useState<{ score: number; verdict: string } | null>(null);
  const [blackhat, setBlackhat] = useState<BlackHatReport | null>(null);
  const [pragmaCtx, setPragmaCtx] = useState<PragmaContext | null>(null);
  const [copied, setCopied] = useState<number | null>(null);
  const engineRef = useRef<Resolved>("WEBSITE");
  const attackBoxRef = useRef<HTMLDivElement>(null);
  const defenceBoxRef = useRef<HTMLDivElement>(null);

  // REAL-TIME elapsed timer — scan chalte waqt 100ms tick
  useEffect(() => {
    if (!busy) return;
    const started = Date.now();
    setElapsed(0);
    const iv = setInterval(() => setElapsed((Date.now() - started) / 1000), 100);
    return () => clearInterval(iv);
  }, [busy]);

  const detected = detectEngine(value);

  const autoScroll = useCallback(() => {
    requestAnimationFrame(() => {
      for (const ref of [attackBoxRef, defenceBoxRef]) {
        const el = ref.current;
        if (el) el.scrollTop = el.scrollHeight;
      }
    });
  }, []);

  const handleEvent = useCallback(
    (ev: StreamEvent) => {
      if (ev.event === "log") setStatus(ev.data.message);
      if (ev.event === "finding") {
        const fd = ev.data as {
          title?: string; bugClass?: string; code?: string; severity: string; attack?: string; attackCode?: string;
          defence?: string; defenceCode?: string; module?: string; line?: number; alsoLines?: number[];
        };
        const title = fd.title ?? (fd.bugClass ? `${fd.bugClass}${fd.code ? ` (${fd.code})` : ""}${fd.line ? ` @ L${fd.line}` : ""}` : "Finding");
        const source = fd.module ?? (fd.bugClass ? "phpscan" : "audit");
        // DEDUP: identical title+attack repeat ho to skip (double-render bug fix)
        setPairs((ps) => {
          if (ps.some((x) => x.title === title && x.attack === (fd.attack || ""))) return ps;
          return [
            ...ps,
            {
              id: `${ps.length}-${title.slice(0, 14)}-${Date.now() % 100000}`,
              source,
              title,
              severity: fd.severity,
              attack: fd.attack || "—",
              attackCode: fd.attackCode,
              defence: fd.defence || "—",
              defenceCode: fd.defenceCode,
              line: fd.line,
              alsoLines: fd.alsoLines,
            },
          ];
        });
        autoScroll();
      }
      if (ev.event === "context") setPragmaCtx(ev.data as PragmaContext);
      if (ev.event === "blackhat") setBlackhat(ev.data as BlackHatReport);
      if (ev.event === "score") setResult({ score: Number(ev.data.score), verdict: String(ev.data.verdict) });
      if (ev.event === "done") {
        const oc = ev.data.onChain as { online?: boolean; name?: string; symbol?: string; codeSize?: number; note?: string } | undefined;
        const ch = ev.data.chain as { live?: boolean; block?: number; gasGwei?: string; chainId?: number } | undefined;
        if (oc) {
          setChainInfo(`on-chain: ${oc.online ? "LIVE" : "OFFLINE"}${oc.codeSize !== undefined ? ` · code ${oc.codeSize}B` : ""}${oc.name ? ` · ${oc.name}${oc.symbol ? ` (${oc.symbol})` : ""}` : ""}${oc.note ? ` · ${oc.note.slice(0, 60)}` : ""}`);
        } else {
          setChainInfo("");
        }
        if (ch?.live) {
          setLiveChain(`LIVE ▸ block #${ch.block?.toLocaleString("en-US") ?? "?"} · gas ${ch.gasGwei ?? "?"} gwei · chain ${ch.chainId ?? 1}`);
        } else {
          setLiveChain("");
        }
        const dur = typeof ev.data.totalMs === "number" ? ` (${(ev.data.totalMs / 1000).toFixed(1)}s)` : "";
        setStatus(`[✓] ${ENGINE_LABEL[engineRef.current]} complete${dur} — report ready`);
      }
      if (ev.event === "error") setStatus("[!] ERROR: " + ev.data.message);
    },
    [autoScroll]
  );

  const run = useCallback(async () => {
    const raw = value.trim();
    if (!raw || busy) return;

    let engine: Resolved;
    if (mode === "AUTO") {
      const det = detectEngine(raw);
      if (det === "NONE") return;
      if (det === "UNKNOWN") {
        setStatus("[!] Samajh nahi aaya — URL, 0x address, PHP code ya Solidity paste karo (ya upar switch se engine manual chuno)");
        return;
      }
      engine = det;
    } else {
      engine = mode;
      if (engine === "TOKEN" && !/^0x[a-fA-F0-9]{40}$/i.test(raw)) {
        setStatus("[!] TOKEN mode: 0x + 40 hex chars wala contract address chahiye");
        return;
      }
    }

    setBusy(true);
    setPairs([]);
    setResult(null);
    setBlackhat(null);
    setPragmaCtx(null);
    setChainInfo("");
    setLiveChain("");
    setEngineRan(engine);
    engineRef.current = engine;
    setStatus(`[*] Engine route: ${ENGINE_LABEL[engine]} — chal raha hai...`);
    try {
      if (engine === "WEBSITE") await streamNdjson("/api/scan", { target: raw }, handleEvent);
      else if (engine === "TOKEN") await streamNdjson("/api/audit", { address: raw }, handleEvent);
      else if (engine === "SOLIDITY") await streamNdjson("/api/audit", { source: raw }, handleEvent);
      else await streamNdjson("/api/php-scan", { code: raw }, handleEvent);
    } catch (e) {
      setStatus("[!] ERROR: " + (e instanceof Error ? e.message : "engine failed"));
    } finally {
      setBusy(false);
    }
  }, [value, mode, busy, handleEvent]);

  const onKeyDown = useCallback(
    (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
      // single-line input pe Enter = run; multi-line code pe Ctrl/Cmd+Enter = run
      if (e.key === "Enter" && !e.shiftKey && !value.includes("\n")) {
        e.preventDefault();
        run();
      } else if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        run();
      }
    },
    [value, run]
  );

  const copyDefence = useCallback(async (i: number, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(i);
      setTimeout(() => setCopied(null), 1500);
    } catch { /* clipboard unavailable */ }
  }, []);

  const detectHint = (() => {
    if (mode !== "AUTO") return `Switch: ${mode} engine FORCED (auto-detect bypass)`;
    if (detected === "NONE") return "Supported: 🌐 website URL · 🪙 0x token address · 🐘 PHP code · 📜 Solidity source";
    if (detected === "UNKNOWN") return "⚠️ Type detect nahi hua — engine switch se manually chuno";
    return `⚡ AUTO-DETECTED: ${detected} → ${ENGINE_LABEL[detected]}`;
  })();

  return (
    <div className="space-y-4">
      {/* ---------- UNIFIED PASTE BOX ---------- */}
      <div className="rounded-xl border border-emerald-900/60 bg-zinc-950 p-5 sm:p-6 shadow-lg shadow-emerald-950/20">
        <div className="flex items-center justify-between flex-wrap gap-2 mb-1">
          <div className="flex items-center gap-2">
            <Zap className="h-4 w-4 text-red-400" />
            <h2 className="font-mono text-sm text-emerald-400 tracking-wide">ALL-IN-ONE — SAB KUCH PASTE KARO</h2>
          </div>
          <span className="font-mono text-[10px] text-zinc-600">URL · 0x token · PHP · Solidity — ek hi box</span>
        </div>

        {/* ENGINE SWITCHES */}
        <div className="flex flex-wrap gap-1.5 my-3" role="tablist" aria-label="Engine switch">
          {ENGINES.map((en) => (
            <button
              key={en.id}
              onClick={() => setMode(en.id)}
              disabled={busy}
              className={`px-3 py-1.5 rounded-full font-mono text-[11px] border transition-colors ${
                mode === en.id
                  ? en.id === "AUTO"
                    ? "bg-emerald-600 text-black border-emerald-500 font-bold"
                    : "bg-red-600 text-white border-red-500 font-bold"
                  : "bg-black text-zinc-400 border-zinc-700 hover:border-emerald-700 hover:text-emerald-400"
              }`}
              aria-pressed={mode === en.id}
            >
              {en.icon} {en.label}
            </button>
          ))}
        </div>

        <textarea
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={onKeyDown}
          placeholder={"Kuch bhi paste karo:\n  https://example.com        ← website scan\n  0xdAC17F958D...31ec7       ← token audit\n  <?php ... ?>               ← php code scan\n  pragma solidity ^0.8.0;    ← solidity audit"}
          disabled={busy}
          spellCheck={false}
          className="w-full h-28 rounded-md bg-black border border-emerald-800/60 px-4 py-3 font-mono text-xs sm:text-sm text-emerald-100 placeholder:text-zinc-600 outline-none focus:border-emerald-500 transition-colors resize-y"
          aria-label="All-in-one input — URL, token, PHP ya Solidity paste karo"
        />

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 mt-3">
          <Button
            onClick={run}
            disabled={busy || !value.trim()}
            className="h-11 px-6 bg-red-600 hover:bg-red-500 text-white font-bold tracking-wider text-sm sm:flex-1"
          >
            {busy ? <Loader2 className="h-5 w-5 animate-spin" /> : <Zap className="h-5 w-5" />}
            {busy ? "LIVE SCAN CHAL RAHA HAI..." : `SCAN ${mode === "AUTO" ? "(AUTO-DETECT)" : `(${mode})`}`}
          </Button>
          <Button
            variant="outline"
            onClick={() => { setValue(""); setPairs([]); setResult(null); setStatus(""); setEngineRan(null); setChainInfo(""); setLiveChain(""); setBlackhat(null); }}
            disabled={busy || (!value && pairs.length === 0)}
            className="h-11 border-zinc-700 text-zinc-400 hover:bg-zinc-800 hover:text-red-400"
          >
            <Trash2 className="h-4 w-4" /> CLEAR
          </Button>
        </div>

        <div className={`mt-3 rounded-md bg-black border px-3 py-2 font-mono text-[11px] ${detected === "UNKNOWN" && mode === "AUTO" ? "border-amber-900/50 text-amber-500/90" : "border-emerald-900/40 text-emerald-500/90"}`} aria-live="polite">
          {busy ? (
            <span className="inline-flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-red-500 animate-pulse" />
              <span>LIVE {elapsed.toFixed(1)}s</span>
              <span>{status || "processing..."}</span>
              <span className="animate-pulse">▌</span>
            </span>
          ) : (
            detectHint
          )}
        </div>
        {liveChain && (
          <div className="mt-2 rounded-md border border-emerald-900/40 bg-black px-3 py-2 font-mono text-[11px] text-emerald-400">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse inline-block mr-2" />
            {liveChain}
          </div>
        )}
      </div>

      {/* ---------- VERDICT BANNER ---------- */}
      {result && engineRan && (
        <div className={`rounded-xl border p-4 flex items-center justify-between ${result.verdict === "ATTACKABLE" || result.verdict === "VULNERABLE" || result.verdict === "CRITICALLY EXPOSED" ? "border-red-700" : "border-emerald-700"} bg-zinc-950`}>
          <div>
            <div className="font-mono text-[11px] text-zinc-500">{ENGINE_LABEL[engineRan]}{chainInfo ? ` — ${chainInfo}` : ""}</div>
            <div className="font-mono text-2xl font-bold text-emerald-400">
              {result.score}
              <span className="text-sm text-zinc-600">/100</span>
            </div>
          </div>
          <Badge variant="destructive" className="font-mono text-sm px-4 py-1.5">{result.verdict}</Badge>
        </div>
      )}

      {/* ---------- PRAGMA CONTEXT (audit runs pe hi aata hai) ---------- */}
      {pragmaCtx && <ContextStrip ctx={pragmaCtx} />}

      {/* ---------- BLACK HAT PERSPECTIVE DASHBOARD ---------- */}
      {blackhat && <BlackHatPanel r={blackhat} />}

      {/* ---------- HACK vs DEFENCE LIVE BOXES ---------- */}
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-xl border border-red-800/70 bg-zinc-950 overflow-hidden flex flex-col">
          <div className="flex items-center justify-between border-b border-red-900/50 bg-red-950/30 px-4 py-2.5">
            <div className="flex items-center gap-2">
              <Swords className="h-4 w-4 text-red-400" />
              <span className="font-mono text-sm font-bold text-red-400 tracking-wider">HACK METHOD</span>
            </div>
            <span className="font-mono text-[10px] text-red-500/80">{busy ? `LIVE ${elapsed.toFixed(1)}s ▌` : `${pairs.length} finding(s)`}</span>
          </div>
          <div ref={attackBoxRef} className="h-[400px] overflow-y-auto p-3 space-y-2.5" aria-live="polite">
            {pairs.length === 0 && !busy && (
              <div className="h-full flex items-center justify-center text-center">
                <p className="font-mono text-xs text-zinc-600">⚔️ Kuch bhi paste karo — URL, token, PHP ya Solidity.<br />Attack techniques yahan live aayengi</p>
              </div>
            )}
            {pairs.length === 0 && busy && (
              <div className="h-full flex items-center justify-center">
                <p className="font-mono text-xs text-red-500/70 animate-pulse">{engineRan === "PHP" ? "taint graph build ho raha hai..." : "target probe ho raha hai..."}</p>
              </div>
            )}
            {pairs.map((p, i) => (
              <div key={p.id} className="rounded-lg border border-red-900/40 bg-black p-3 space-y-1.5 animate-in fade-in slide-in-from-bottom-1 duration-300">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-mono text-[10px] text-red-600 font-bold">#{String(i + 1).padStart(2, "0")}</span>
                  <Badge className={`${sevBg(p.severity)} text-white font-mono text-[9px] px-1.5 py-0`}>{p.severity}</Badge>
                  {p.line !== undefined && (
                    <span className="font-mono text-[10px] text-red-500/70">L{p.line}{p.alsoLines?.length ? ` +${p.alsoLines.length} more` : ""}</span>
                  )}
                  <span className="font-mono text-[10px] text-zinc-500">{p.source}</span>
                </div>
                <div className="font-mono text-xs font-bold text-red-300">{p.title}</div>
                <p className="font-mono text-[11px] leading-relaxed text-red-200/70 whitespace-pre-wrap">{p.attack}</p>
                {p.attackCode && (
                  <pre className="rounded-md border border-red-950 bg-red-950/20 p-2.5 font-mono text-[10px] leading-relaxed text-red-300/90 overflow-x-auto whitespace-pre-wrap">{p.attackCode}</pre>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-xl border border-emerald-800/70 bg-zinc-950 overflow-hidden flex flex-col">
          <div className="flex items-center justify-between border-b border-emerald-900/50 bg-emerald-950/30 px-4 py-2.5">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-emerald-400" />
              <span className="font-mono text-sm font-bold text-emerald-400 tracking-wider">DEFENCE METHOD</span>
            </div>
            <span className="font-mono text-[10px] text-emerald-500/80">{busy ? "LIVE..." : "fix + hardening"}</span>
          </div>
          <div ref={defenceBoxRef} className="h-[400px] overflow-y-auto p-3 space-y-2.5" aria-live="polite">
            {pairs.length === 0 && !busy && (
              <div className="h-full flex items-center justify-center text-center">
                <p className="font-mono text-xs text-zinc-600">🛡️ Har finding ka fix yahan aayega —<br />COPY button ke saath</p>
              </div>
            )}
            {pairs.length === 0 && busy && (
              <div className="h-full flex items-center justify-center">
                <p className="font-mono text-xs text-emerald-500/70 animate-pulse">defence engine ready...</p>
              </div>
            )}
            {pairs.map((p, i) => (
              <div key={p.id} className="rounded-lg border border-emerald-900/40 bg-black p-3 space-y-1.5 animate-in fade-in slide-in-from-bottom-1 duration-300">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[10px] text-emerald-600 font-bold">#{String(i + 1).padStart(2, "0")} FIX</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 px-2 text-[10px] font-mono text-zinc-500 hover:text-emerald-400 hover:bg-emerald-950"
                    onClick={() => copyDefence(i, p.defenceCode ?? p.defence)}
                    aria-label={`Defence fix #${i + 1} copy karo`}
                  >
                    {copied === i ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                    {copied === i ? "COPIED" : "COPY"}
                  </Button>
                </div>
                <p className="font-mono text-[11px] leading-relaxed text-emerald-200/80 whitespace-pre-wrap">{p.defence}</p>
                {p.defenceCode && (
                  <pre className="rounded-md border border-emerald-950 bg-emerald-950/20 p-2.5 font-mono text-[10px] leading-relaxed text-emerald-300/90 overflow-x-auto whitespace-pre-wrap">{p.defenceCode}</pre>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
