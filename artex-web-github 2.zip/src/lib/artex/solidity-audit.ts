// ARTEX Solidity Smart Contract Static Audit Engine — 17 detectors (teacher-style)
// Har finding: attack scenario + REAL EXPLOIT CODE + defence + HARDENED FIX CODE
// + false-positive guards: nonReentrant / SafeMath / return-capture / CEI-order checks
// CRITICAL AUDIT RULES (har run pe enforce):
//  #1 STRICT PRAGMA MATCHING — detectors declared compiler spec se gate hote hain (koi assumption nahi)
//  #2 CONTEXTUAL ACCURACY — >=0.8 me overflow hallucinate NAHI hota; sirf unchecked{} bypass points flag
//  #3 REAL-TIME INSPECTION — interface/abstract/library classification + per-function modifier cross-verify
//  #4 EVIDENCE-BASED — har finding pe exact line + source line quote; clean code pe pragma-aware SECURE verdict
import type { SolidityFinding, PragmaContext } from "./types";
import { parsePragmaContext } from "./pragma-context";
import { ceiOrderVerified } from "./blackhat";

interface Pattern {
  id: string;
  title: string;
  severity: SolidityFinding["severity"];
  regex: RegExp;
  cwe: string;
  attack: string;
  attackCode?: string;
  defence: string;
  defenceCode?: string;
  // source-level guard: pattern match ignore karo jab guard cross-verify ho.
  // fnScope = isi function ka signature+body (agle declaration tak) — modifier cross-verification isi pe
  skipIf?: (source: string, matched: string, fnScope: string) => boolean;
}

// matched index jis function me hai uska FULL scope (function-declaration se agle declaration tak).
// rule #3: modifier/require/CEI cross-verification isi containing-function scope pe hoti hai —
// sibling functions ke guards cross-function bleed NAHI karte.
function fnScopeAround(source: string, index: number): string {
  // FULL source pe function-starts dhoondo, phir match-index se PEHLE/AT wala LAST start lo.
  // (upto-slice approach match ke beech token cut kar deta tha — khud ke "function mint(" ko hi miss karta)
  const starts = [...source.matchAll(/\b(?:function\s+[\w$]+|constructor)\s*\(/g)];
  let startIdx = -1;
  for (const s of starts) {
    if ((s.index ?? 0) <= index) startIdx = s.index ?? 0;
    else break;
  }
  if (startIdx < 0) startIdx = index;
  const rest = source.slice(startIdx, startIdx + 1200);
  const next = /\n\s*(function\s+\w|contract\s+\w|interface\s+\w|library\s+\w|abstract\s+contract)/.exec(rest);
  return next ? rest.slice(0, next.index) : rest;
}

const PATTERNS: Pattern[] = [
  {
    id: "SELFDESTRUCT",
    title: "selfdestruct() present — kill switch risk",
    severity: "CRITICAL",
    regex: /selfdestruct\s*\(/,
    cwe: "CWE-1053",
    attack: "TEACHER NOTE: Owner function compromise (phishing key, unprotected fn) → selfdestruct call → contract code permanently delete, ETH force-send, treasury burn. One transaction, irreversible.",
    attackCode: `// Attack tx (owner key milne ke baad ya unprotected fn se):
victimContract.destroy(payable(attacker));   // funds attacker ko, code GONE
// Force-ETH trick: selfdestruct wale contract se eth bhejo — receive() bypass`,
    defence: "selfdestruct hatao (EIP-6780 ne bhi deprecate kiya). Emergency stop chahiye to Pausable pattern + multisig + timelock.",
    defenceCode: `// FIX: Pausable kill-switch (no selfdestruct)
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";
contract Vault is Pausable {
    function pause() external onlyRole(GUARDIAN) { _pause(); }
    function unpause() external onlyRole(GUARDIAN) { _unpause(); }
    function withdraw(uint256 amt) external whenNotPaused { /* ... */ }
}`,
  },
  {
    id: "DELEGATECALL",
    title: "delegatecall to non-constant address",
    severity: "CRITICAL",
    regex: /delegatecall\s*\(/,
    cwe: "CWE-829",
    attack: "TEACHER NOTE: delegatecall TARGET contract ka code AAPKE storage pe chalata hai. Implementation address variable hai to attacker malicious contract point karke pura storage hijack karta hai — Parity multisig bug: $150M+ permanently locked.",
    attackCode: `// Attack: setImpl unprotected ho to
victim.setImpl(attackerImpl);           // malicious logic
victim.withdrawAll();                   // ab VICTIM ke storage pe attacker ka code
// attackerImpl me: balances[msg.sender] = 1e30; ya owner = attacker;`,
    defence: "Implementation address immutable rakho (constructor-set), upgradeable chahiye to OpenZeppelin Transparent proxy + TimelockController + multisig.",
    defenceCode: `// FIX: immutable implementation
address public immutable implementation;
constructor(address impl) { implementation = impl; }
function doWork() external { (bool ok, ) = implementation.delegatecall(abi.encodeCall(IV2.work, ())); require(ok, "fail"); }
// Upgradeable ho to: TimelockController(48h) + multisig admin mandatory`,
  },
  {
    id: "TXORIGIN",
    title: "tx.origin used for authentication",
    severity: "HIGH",
    regex: /tx\.origin\s*==|require\s*\(\s*tx\.origin/,
    cwe: "CWE-290",
    attack: "TEACHER NOTE: tx.origin = chain ka ORIGINAL signer — beech ke contracts nahi. Victim malicious contract se tx bhejta hai to msg.sender = attacker contract, par tx.origin = victim — auth bypass ho jata hai.",
    attackCode: `// Phishing contract — victim ko 'free airdrop claim' dikhao:
contract Phish {
    function claim() external {          // victim isse call karega
        require(tx.origin == victim);    // VICTIM contract ke liye TRUE!
        Victim(victim).withdrawAll();    // msg.sender = Phish, auth PASS
    }
}`,
    defence: "Authentication sirf msg.sender pe — tx.origin kabhi nahi.",
    defenceCode: `// FIX:
require(msg.sender == owner, "not owner");
// Meta-transactions chahiye to EIP-2771 trusted forwarder pattern use karo`,
  },
  {
    id: "REENTRANCY",
    title: "External call before state update (reentrancy shape)",
    severity: "HIGH",
    regex: /\.call\s*\{?\s*(value|\()|\.transfer\s*\(|\.send\s*\(/,
    cwe: "CWE-841",
    // rule #3 per-function cross-verification:
    //  - IS function pe nonReentrant modifier ho → door band (skip)
    //  - IS function me CEI order verified ho → door band (skip) — SIBLING ka CEI cross-function bleed nahi karta
    //  - ReentrancyGuard imported ho par IS fn pe modifier MISSING → flag RAHEGA (GUARD GAP — real finding, FP nahi)
    skipIf: (source, _matched, fs) => /nonReentrant/.test(fs) || ceiOrderVerified(fs),
    attack: "TEACHER NOTE: ETH bhejo jabki balance abhi update nahi hua → attacker ka receive() hook phir se withdraw() call kar lega — balance abhi bhi pura dikh raha hai. The DAO hack ($60M) exactly yahi tha. Loop tab tak chalta hai jab tak contract khali.",
    attackCode: `// Attacker.sol — deploy + fund + pwn()
contract Attacker {
    Victim public victim = Victim(0x...);
    function pwn() external payable {
        victim.deposit{value: 1 ether}();
        victim.withdraw(1 ether);            // pehli withdrawal
    }
    receive() external payable {
        if (address(victim).balance >= 1 ether)
            victim.withdraw(1 ether);        // RE-ENTRY LOOP — state abhi update nahi hua
    }
}`,
    defence: "Checks-Effects-Interactions order + ReentrancyGuard. State pehle, external call LAST me.",
    defenceCode: `// FIX: checks → effects → interactions
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
function withdraw(uint256 amt) external nonReentrant {
    uint256 bal = balances[msg.sender];
    require(bal >= amt, "insufficient");
    balances[msg.sender] = bal - amt;        // EFFECT FIRST
    (bool ok, ) = msg.sender.call{value: amt}("");  // INTERACTION LAST
    require(ok, "transfer failed");
}`,
  },
  {
    id: "OPENMINT",
    title: "Public mint without access control",
    severity: "CRITICAL",
    // Variant 1: mint()/_mint() call without access control
    // Variant 2: direct balances[...] += write in mint-like fn (scam-token classic, _mint() bypass)
    // [^;{]* boundary-safe: interface signature (\';\' pe khatam) ke paar cross NAHI karta (rule #3 FP fix)
    regex: /function\s+mint\s*\([^)]*\)\s*(public|external)[^;{]*\{[^}]*(mint|_mint)\s*\(|function\s+\w*mint\w*\s*\([^)]*address[^)]*\)\s*(public|external)[^;{]*\{[^}]*balances\s*\[[^\]]*\]\s*(\+=|=)/i,
    cwe: "CWE-862",
    skipIf: (_source, _matched, fs) => /only[A-Z]|require\s*\(|msg\.sender\s*==/.test(fs),
    attack: "TEACHER NOTE: Koi bhi unlimited tokens mint kar sakta hai — supply inflate karke LP drain: mint huge → pool me sell → holders ka value zero. Attack is ONE transaction ka hota hai. (Variant: kabhi-kabhi mint() me _mint() ki jagah direct balances[to] += likha hota hai — same rug, scanner se chhupne ke liye.)",
    attackCode: `// Attack (public mint ho to):
token.mint(attacker, 10**30);            // koi bhi, kabhi bhi
router.swapExactTokensForTokens(...);    // LP sweep — price 0
// Direct-balance variant me bhi SAME attack:
honey.mint(attacker, 10**30);            // andar balances[attacker] += 10**30 hota hai`,
    defence: "Mint pe onlyMinter/onlyOwner role + hard supply cap — dono.",
    defenceCode: `// FIX:
uint256 public constant MAX_SUPPLY = 1_000_000_000e18;
function mint(address to, uint256 amt) external onlyRole(MINTER_ROLE) {
    require(totalSupply() + amt <= MAX_SUPPLY, "cap exceeded");
    _mint(to, amt);
}`,
  },
  {
    id: "HIDDENMINT",
    title: "Owner-controlled mint without supply cap (hidden mint / rug vector)",
    severity: "HIGH",
    regex: /function\s+mint\w*\s*\([^)]*\)[^;{]*\{[^}]*(_?mint)\s*\(/i,
    cwe: "CWE-862",
    skipIf: (source, _matched, fs) =>
      !/only[A-Z]/.test(fs) ||
      /MAX_SUPPLY|maxSupply|supplyCap|cap\s*[=:]|_cap\b/.test(source) ||
      /require\s*\([^)]*(totalSupply|cap|MAX)/i.test(fs),
    attack: "TEACHER NOTE: Owner kabhi bhi unseen supply mint kar sakta hai — 'trusted team' bhi rug kar sakti hai. Sniffers isko flag karte hain; docs me cap na ho to ye classic rug vector hai.",
    attackCode: `// Rug sequence (owner ke paas ye power hai):
owner.mint(owner, 1_000_000e18);   // hidden inflation
router.sell(...);                   // LP dump — holders trapped`,
    defence: "Immutable hard cap + mint role time-bound; cap on-chain verify hona chahiye.",
    defenceCode: `// FIX:
uint256 public immutable MAX_SUPPLY;    // constructor me set, kabhi change nahi
function mint(address to, uint256 amt) external onlyRole(MINTER) {
    require(block.timestamp < MINT_END, "minting closed");
    require(totalSupply() + amt <= MAX_SUPPLY, "cap");
    _mint(to, amt);
}`,
  },
  {
    id: "BLACKLIST",
    title: "Blacklist/bot-filter mapping on transfers (freezable tokens)",
    severity: "HIGH",
    regex: /(isBlacklisted|isBlackListed|blacklisted|_isBot|isBot|bots\[)\s*\[?|mapping\s*\(\s*address\s*=>\s*bool\s*\)\s*(public|internal|private)?\s*\w*(black|bot)/i,
    cwe: "CWE-285",
    attack: "TEACHER NOTE: Blacklist = owner-controlled transfer freeze. Honeypot variant: sab buy karein, owner buyers ko blacklist kare — sell block, funds phasse. Aapka token bina wajah freeze ho sakta hai.",
    attackCode: `// Freeze attack:
owner.setBlacklist(victim, true);    // victim sell NAHI kar sakta
// Honeypot flow: buy open → victim buy → blacklist → sell revert`,
    defence: "Blacklist capability hatao (ERC-20 free transfers). Compliance zaroori ho to documented sanctions-integration + timelock, individual ban power nahi.",
    defenceCode: `// FIX: standard transfer — koi blacklist nahi
function transfer(address to, uint256 amt) public returns (bool) {
    _transfer(msg.sender, to, amt);
    return true;
}
// Compliance: Chainalysis-sanctions oracle global-list only, timelock ke saath`,
  },
  {
    id: "ARBSEND",
    title: "Withdraw/rescue with caller-controlled destination (potential arbitrary-send)",
    severity: "HIGH",
    regex: /function\s+\w*(withdraw|rescue|emergency|claim|transferToken|sendToken)\w*\s*\([^)]*address\s+\w+[^)]*\)\s*(public|external)\s*(?!only)[^;{]*\{/i,
    cwe: "CWE-284",
    skipIf: (_source, _matched, fs) => /only[A-Z]|onlyOwner|require\s*\(\s*msg\.sender|_msgSender\(\)\s*==|revert\s*\(/.test(fs),
    attack: "TEACHER NOTE: Destination address USER-controlled + access control absent = koi bhi contract ke saare tokens apne address pe rescue kar sakta hai. Treasury instantly empty — one tx.",
    attackCode: `// Attack (rescueToken public ho to):
victim.rescueToken(USDT, attacker);       // koi bhi call kare
// → contract ka pura USDT attacker ko`,
    defence: "Rescue/withdraw pe onlyOwner/onlyRole; destination FIXED treasury ya event+timelock; users pull-payment se khud withdraw karein.",
    defenceCode: `// FIX:
address public immutable TREASURY = 0x...;
function rescueToken(IERC20 t) external onlyOwner {
    t.safeTransfer(TREASURY, t.balanceOf(address(this)));  // destination FIXED
    emit Rescued(address(t));
}
// User withdrawals: pull-pattern — apna balance khud withdraw karo`,
  },
  {
    id: "FEECAP",
    title: "Fee setter without upper bound (100% tax possible)",
    severity: "MEDIUM",
    regex: /function\s+set\w*(Fee|Tax)\w*\s*\([^)]*\)\s*(public|external)\s*(?!only)[^;{]*\{/i,
    cwe: "CWE-284",
    skipIf: (_source, _matched, fs) => /only[A-Z]|require\s*\([^)]*(<=|<_|MAX|1000|BPS|100)/.test(fs) || /MAX_|_BPS|BASIS_/.test(fs),
    attack: "TEACHER NOTE: Fee setter bina cap = owner 100% tax laga sakta hai — buy/sell pe pura amount kha jaye (soft-honeypot). Undisclosed fee raise = silent dump vector.",
    attackCode: `// Tax attack:
owner.setSellFee(10000);     // 100% (BPS) — har sell pe pura amount fee
// holders sell nahi kar pate, LP se value drain hoti rahegi`,
    defence: "Hard cap immutable/constant + fee change event + timelock; launch ke baad fee lock common best-practice hai.",
    defenceCode: `// FIX:
uint256 public constant MAX_FEE = 300;   // 3% — immutable
function setSellFee(uint256 bps) external onlyOwner {
    require(bps <= MAX_FEE, "fee cap exceeded");
    sellFeeBps = bps;
    emit FeeUpdated(bps);
}`,
  },
  {
    id: "PAUSABLE",
    title: "Pausable capability (centralized kill-switch note)",
    severity: "LOW",
    regex: /whenNotPaused|whenNotPaused\(|function\s+pause\s*\(|function\s+unpause\s*\(|_pause\s*\(/,
    cwe: "N/A",
    attack: "TEACHER NOTE: Pause authority (ya compromised key) sab transfers rok sakta hai — market freeze. Classic manipulation: pause → price info asymmetry → unfreeze pe dump.",
    attackCode: `// Freeze scenario:
owner.pause();                 // sab trading rok do
// price impact/news asymmetry →
owner.unpause();               // aligned holders pehle nikal gaye`,
    defence: "Pause sirf emergency me — multisig + timelock ke peeche, auto-unpause deadline, events transparent.",
    defenceCode: `// FIX: time-bounded pause
function pause() external onlyRole(GUARDIAN) {
    pausedUntil = block.timestamp + 24 hours;
    _pause();
}
// 24h baad auto-unpause logic trading me check karo`,
  },
  {
    id: "OWNERFIRST",
    title: "Owner-only transfer gate (honeypot shape)",
    severity: "HIGH",
    regex: /(onlyOwner[^{]*(transfer|sell|withdraw|claim))|require\s*\(\s*(msg\.sender\s*==\s*(owner|_owner)|isOwner\(\s*\))[^;]*(transfer|sell|withdraw)/i,
    cwe: "CWE-285",
    attack: "TEACHER NOTE: CLASSIC honeypot — buy koi bhi, sell sirf owner. Victim tokens kharidta hai, permanently stuck. Sniffers (honeypot.is, tokensniffer) instantly flag karte hain; par tab tak victims aa chuke hote hain.",
    attackCode: `// Honeypot flow:
1. victim.buy()   → OK (koi bhi buy kar sakta hai)
2. victim.sell()  → require(msg.sender == owner) → REVERT
3. victim ke tokens contract me phasse, owner LP drain karta hai`,
    defence: "Transfer restrictions hatao — ERC-20 standard. Trading lock sirf public deadline tak: block.timestamp vs FIXED open time.",
    defenceCode: `// FIX: public deadline, koi owner flag nahi
uint256 public immutable TRADING_OPEN;   // constructor me set
function transfer(address to, uint256 amt) public returns (bool) {
    if (!tradingOpen()) require(to == address(this), "trading not open");
    _transfer(msg.sender, to, amt);
    return true;
}
function tradingOpen() public view returns (bool) { return block.timestamp >= TRADING_OPEN; }`,
  },
  {
    id: "UNCHECKEDCALL",
    title: "Unchecked external call return value",
    severity: "MEDIUM",
    regex: /(?:[\w\d_]+)\.call\s*\(\s*[^{]*?\)\s*;/,
    cwe: "CWE-252",
    skipIf: (_source, matched) => /bool\s+\w+|\(bool,\s*\)\s*=|success\s*=/.test(matched),
    attack: "TEACHER NOTE: .call() fail hua par return value ignore → internal accounting 'success' mark kar dega jabki transfer hua hi nahi. Funds kabhi nahi pahunche, state keh raha hai pahunch gaye — accounting corruption.",
    attackCode: `// Bug shape:
token.call(abi.encodeWithSelector(token.transfer.selector, to, amt));
users[onBehalf].released += amt;    // release ho gaya, transfer fail hua!`,
    defence: "Return capture + require, ya SafeERC20 safeTransfer.",
    defenceCode: `// FIX:
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
using SafeERC20 for IERC20;
token.safeTransfer(to, amt);   // revert on failure — accounting consistent`,
  },
  {
    id: "OVERFLOW",
    title: "Solidity <0.8 without SafeMath (overflow)",
    severity: "HIGH",
    // sirf DECLARED legacy pragma pe — rule #1: >=0.8 me ye detector chalta hi nahi (auditSolidity gate).
    // [^;]* = spec ke ANDAR kahin bhi 0.[0-7]. ho (jaise ">=0.6.0 <0.9.0") to match — range-crossing specs conditional report hote hain
    regex: /pragma\s+solidity\s*[^;]*0\.[0-7]\./,
    cwe: "CWE-681",
    skipIf: (source) => /using\s+SafeMath\s+for|SafeMath\.mul|SafeMath\.add|PRBMath/.test(source),
    attack: "TEACHER NOTE: 0.8 se pehle arithmetic wrap karta hai — balances[a] - hugeAmount UNDERFLOW ho ke 2^256 ke paas jump karta hai. Beco/BeautyChain (SMT) bug: overflow se infinite tokens, exchange drain.",
    attackCode: `// Underflow attack (0.7.x):
balances[attacker] = balances[attacker] - 1e30;   // wraps to ~2^256
attacker.transfer(victim, 1e24);                  // ab infinite balance
// Deposit = 0, withdrawal = infinite`,
    defence: "Solidity 0.8+ (built-in checked arithmetic) ya SafeMath. unchecked{} blocks ko manual audit karo.",
    defenceCode: `// FIX:
pragma solidity ^0.8.24;   // checked arithmetic built-in
// intentional wrap ho to: unchecked { ... } — sirf proven-safe logic me`,
  },
  {
    id: "UNCHECKED_MATH",
    title: "unchecked{} block — checked arithmetic BYPASSED (overflow/underflow possible)",
    severity: "HIGH",
    // rule #2: >=0.8 me arithmetic by-default checked — SIRF unchecked{} blocks me wrap possible.
    // Ye detector MODERN era pe hi chalta hai (legacy me sab unchecked — OVERFLOW hi sahi finding).
    regex: /unchecked\s*\{[\s\S]{0,300}?(--|\+\+|-=|\+=|\*=|[+\-*/]=)/,
    cwe: "CWE-681",
    // FP mitigation: sirf STATE-LIKE arithmetic flag karo — local loop counters/gas-optimisation skips nahi
    skipIf: (_source, matched) => !/(balances?|shares?|stakes?|credits?|allowance|supply|amount|total|reserve|deposit|vote|checkpoint)/i.test(matched),
    attack: "TEACHER NOTE: 0.8+ me compiler arithmetic wrap rokta hai — PAR developer unchecked{} likhta hai to compiler check BYPASS ho jata hai. Ye intentional hota hai (gas saving) par state-affecting math pe wrap = underflow → balance corruption. Attack: subtract jyada amount → wrap to ~2^256.",
    attackCode: `// unchecked underflow attack (0.8.x contract):
vault.withdraw(type(uint256).max);
// andar: unchecked { balances[msg.sender] -= amt; }   // WRAP!
// balances ab ~2^256 — attacker poora supply 'own' karta hai
// dex.sell(...) — LP drain`,
    defence: "unchecked{} sirf PROVEN-safe math pe (jaise loop counters, already-checked paths). State-affecting arithmetic hamesha checked rakho — ya input validation pehle karo.",
    defenceCode: `// FIX: validate BEFORE unchecked, ya unchecked hatao
function withdraw(uint256 amt) external {
    require(balances[msg.sender] >= amt, "insufficient");  // CHECK pehle
    unchecked { balances[msg.sender] -= amt; }             // ab PROVEN safe
    (bool ok, ) = msg.sender.call{value: amt}("");
    require(ok);
}`,
  },
  {
    id: "TIMESTAMP",
    title: "block.timestamp dependence",
    severity: "LOW",
    regex: /block\.timestamp|now\s*[<>=]/,
    cwe: "CWE-829",
    attack: "TEACHER NOTE: block.timestamp validator 15s tak SHIFT kar sakta hai — lottery/auction me tiny edge, high-value outcome pe profit. YE alone rarely critical, par price-affecting logic me accumulate hota hai.",
    attackCode: `// Validator edge:
require(block.timestamp < deadline);   // validator apne block me -15s shift
// → expired bid bhi accept / victim ka tx fail`,
    defence: "Time-sensitive logic me block.number use karo ya ±15s tolerance assume. Precise time ke liye Chainlink oracle.",
    defenceCode: `// FIX:
uint256 public immutable startBlock;   // block.number — deterministic
require(block.number >= startBlock + 100, "too early");
// Ya oracle time: Chainlink Clock feed`,
  },
  {
    id: "ASSEMBLY",
    title: "Inline assembly usage",
    severity: "INFO",
    regex: /assembly\s*\{/,
    cwe: "N/A",
    attack: "TEACHER NOTE: Assembly Solidity ke safety checks BYPASS karta hai — galat storage slot write se poora contract corrupt ho sakta hai. Manual review zaroori: har slot, har mload/mstore.",
    attackCode: `// Slot collision example:
assembly { sstore(0, newVal) }   // slot 0 me kya hai? first state var!
// Solidity compiler ki packing/slot calc ko bypass = silent corruption`,
    defence: "Assembly minimal rakho; har slot Solidity variable ke against verify; slither/sempahor chalao; docs me slot map.",
    defenceCode: `// FIX: storage slots ko contract layout ke saath explicitly map karo
/// @custom:storage-location erc7201:my.namespace
struct Storage { uint256 value; }
// keccak256(abi.encode(uint256(keccak256("my.namespace")) - 1)) slot math
// + test: forge test --gas-report se state layout verify`,
  },
  {
    id: "PROXY",
    title: "Upgradeable proxy pattern",
    severity: "MEDIUM",
    regex: /ERC1967|Initializable|_upgradeTo|upgradeTo\s*\(/,
    cwe: "CWE-284",
    attack: "TEACHER NOTE: upgradeTo() agar timelock/multisig ke bina hai to compromised admin key = ONE TX me malicious implementation + full fund drain. Storage collision (proxy vs impl) bhi classic bug hai.",
    attackCode: `// One-tx takeover:
proxy.upgradeToAndCall(maliciousImpl, abi.encodeCall(Mal.drain, ()));
// Mal.drain(): balances sab attacker ko, ya selfdestruct-style sweep`,
    defence: "Transparent/Beacon proxy + TimelockController (48h) + multisig admin. Storage layout never-modify rule document karo.",
    defenceCode: `// FIX:
import {TimelockController} from "@openzeppelin/contracts/governance/TimelockController.sol";
// admin = TimelockController(48h delay, multisig proposers/executors)
// upgrade proposal → 48h wait → execute — community ko react ka time milta hai`,
  },
  {
    id: "UNPROTECTEDFN",
    title: "State-changing public function without access modifier",
    severity: "HIGH",
    regex: /function\s+(setOwner|setAdmin|setPrice|setFee|withdrawAll|setImplementation|transferOwnership)\s*\([^)]*\)[^;{]*\{/i,
    cwe: "CWE-862",
    // FP guard: fnScope (signature+body) me guard-modifier/require ho to cross-verified-safe
    // (interface signature ke paar \';\' se cross nahi hota — rule #3)
    skipIf: (_source, _matched, fs) => /only[A-Z]|require\s*\(|msg\.sender\s*==|_msgSender/.test(fs),
    attack: "TEACHER NOTE: setOwner()/withdrawAll() bina access control = KAHI BHI anyone call karke ownership le sakta hai ya funds nikaal sakta hai. Ye highest-frequency bug hai static scanners me.",
    attackCode: `// Instant takeover:
victim.setOwner(attacker);      // ab owner = attacker
victim.withdrawAll();           // funds out`,
    defence: "Har config/state fn pe onlyOwner/onlyRole; ownership transfer two-step (propose → accept).",
    defenceCode: `// FIX: two-step ownable
function transferOwnership(address next) external onlyOwner {
    pendingOwner = next;                    // STEP 1: propose
}
function acceptOwnership() external {
    require(msg.sender == pendingOwner);
    owner = msg.sender;                     // STEP 2: accept — galti se wrong address impossible
    pendingOwner = address(0);
}`,
  },
];

// classification INFO finding — rule #3: interface/abstract/library ko CORRECTLY classify karo,
// generic HIGH warnings throw mat karo (executable attack surface yahan exist hi nahi karta)
function classificationFinding(ctx: PragmaContext, lines: string[]): SolidityFinding {
  const declLine = lines.findIndex((l) => /^\s*(abstract\s+)?(contract|interface|library)\s+\w/.test(l));
  const decl = lines[declLine >= 0 ? declLine : 0]?.trim() ?? "";
  const kind = ctx.contractType;
  return {
    id: "CLASSIFICATION",
    title: `${kind} definition — signature-level audit (rule #3 classification)`,
    severity: "INFO",
    line: declLine >= 0 ? declLine + 1 : 1,
    snippet: decl.slice(0, 200),
    attack:
      `TEACHER NOTE: Ye source ek ${kind} hai — ${kind === "INTERFACE" ? "sirf function SIGNATURES hote hain, koi executable body nahi" : kind === "LIBRARY" ? "stateless helper functions hote hain, khud koi fund/state custody nahi rakhta" : " kuch functions implemented ho sakte hain par deploy-direct attack surface limited hai"}. Runtime vulnerabilities (reentrancy, fund-drain, privilege escalation) YAHAN possible NAHI — wo IMPLEMENTING contract me hote hain. Isliye generic HIGH-severity findings suppress kiye gaye (false-positive mitigation).` +
      (ctx.ozModules.length ? `\n\nOpenZeppelin base classes detected: ${ctx.ozModules.join(", ")} — audited templates, deviation pe focus karo.` : ""),
    attackCode: kind === "INTERFACE"
      ? `// Interface pe attack NAHI hota — implementation pe hota hai:
interface IStaking { function withdrawAll() external; }   // <- sirf signature
// exploit yahan NAHI, implementing Vault contract ke body me hoga`
      : `// ${kind} ka attack surface limited — implementing/deployed contract audit karo`,
    defence: `IMPLEMENTING contract ka audit karo — ye ${kind} sirf contract-boundary define karta hai. Yahan jo bhi signature-level notes hain (visibility, events) wo compile-time best-practice level ke hain.`,
    defenceCode: `// Audit scope note:
// ${ctx.contractName ?? "<name>"} (${kind}) — PASS: signature-level clear
// → implementing contract source paste karo for full black-hat analysis`,
    cwe: "N/A",
  };
}

export function auditSolidityFull(source: string): { findings: SolidityFinding[]; ctx: PragmaContext } {
  const ctx = parsePragmaContext(source);
  const findings: SolidityFinding[] = [];
  const lines = source.split(/\r?\n/);
  const seen = new Set<string>();

  // ---- rule #3: pehle classify — interface/abstract/library pe executable-bug detectors sense nahi banate ----
  if (ctx.contractType === "INTERFACE" || ctx.contractType === "ABSTRACT" || ctx.contractType === "LIBRARY") {
    findings.push(classificationFinding(ctx, lines));
    if (ctx.contractType === "INTERFACE") {
      // interface me koi body hi nahi — body-requiring detectors false-positive dene ki jagah skip
      const bodyless = PATTERNS.filter((p) => !["TIMESTAMP", "ASSEMBLY"].includes(p.id));
      for (const p of bodyless) seen.add(p.id); // suppress via seen-set (evidence-based skip, chhupa nahi rahe)
      // note: TIMESTAMP/ASSEMBLY jaise presence-checks interface me irrelevant — unhe bhi chhod do
      seen.add("TIMESTAMP");
      seen.add("ASSEMBLY");
    }
  }

  for (const p of PATTERNS) {
    // ---- rule #1 STRICT PRAGMA GATING: declared spec ke against hi detector chalta hai ----
    if (p.id === "OVERFLOW" && ctx.era === "MODERN") continue; // >=0.8 guaranteed — overflow hallucination KABHI nahi
    if (p.id === "UNCHECKED_MATH" && ctx.era !== "MODERN") continue; // legacy me sab unchecked — OVERFLOW hi sahi finding

    // MULTIPLE matches: pehla non-skipped match hi finding banta hai — skip hua to AGLE match pe
    // cross-verify karo (per-fn guard gap: sibling guarded ho to bhi unguarded fn pakda jaye)
    let chosen: { m: RegExpMatchArray; fs: string } | null = null;
    const g = new RegExp(p.regex.source, p.regex.flags.includes("g") ? p.regex.flags : p.regex.flags + "g");
    for (const m of source.matchAll(g)) {
      const fs = fnScopeAround(source, m.index ?? 0);
      if (p.skipIf && p.skipIf(source, m[0], fs)) continue;
      chosen = { m, fs };
      break;
    }
    if (!chosen) continue;
    const { m, fs } = chosen;

    // ---- rule #4 EVIDENCE: exact line number + exact source line ----
    const before = source.slice(0, m.index ?? 0);
    const line = before.split(/\r?\n/).length;
    const snippet = lines[line - 1]?.trim() ?? m[0];
    if (seen.has(p.id)) continue;
    seen.add(p.id);
    const f: SolidityFinding = {
      id: p.id,
      title: p.title,
      severity: p.severity,
      line,
      snippet: snippet.slice(0, 200),
      attack: p.attack,
      attackCode: p.attackCode,
      defence: p.defence,
      defenceCode: p.defenceCode,
      cwe: p.cwe,
    };
    // GUARD GAP upgrade: ReentrancyGuard imported par is fn pe modifier nahi — real finding, context note ke saath
    if (p.id === "REENTRANCY" && /ReentrancyGuard/.test(source) && !/nonReentrant/.test(fs)) {
      f.title = "[GUARD GAP] " + f.title;
      f.attack += "\n\n⚠ GUARD GAP: ReentrancyGuard source me present hai par IS function pe nonReentrant modifier MISSING — guard imported hai, apply nahi hua. Half-fixed contract: yahi function attacker ka entry door hai.";
    }
    // AMBIGUOUS pragma: range <0.8 aur >=0.8 dono allow karta hai — assumption nahi, conditional report
    if (p.id === "OVERFLOW" && ctx.era === "AMBIGUOUS") {
      f.title = "[AMBIGUOUS PRAGMA] " + f.title;
      f.attack = `PRAGMA NOTE: declared spec "${ctx.pragmaRaw}" — range me <0.8 compilers BHI allowed hain. Legacy mode me arithmetic wrap possible, >=0.8 me nahi. Exact version pin karo, phir ye finding conditional ho jayegi.\n\n` + f.attack;
    }
    findings.push(f);
  }

  // ---- rule #1: pragma declared hi nahi — security-relevant informational (assumption-free mode) ----
  if (!ctx.hasPragma && ctx.contractType !== "NONE" && !seen.has("CLASSIFICATION")) {
    const pragmaLine = lines.findIndex((l) => /^\s*(abstract\s+)?(contract|interface|library)\s+\w/.test(l));
    findings.push({
      id: "NO_PRAGMA",
      title: "Compiler version NOT declared (pragma missing) — reproducible security guarantee nahi",
      severity: "LOW",
      line: pragmaLine >= 0 ? pragmaLine + 1 : 1,
      snippet: lines[pragmaLine >= 0 ? pragmaLine : 0]?.trim().slice(0, 200) ?? "",
      attack:
        "TEACHER NOTE: pragma ke bina code kisi bhi compiler version se compile ho sakta hai — behavior version ke saath BADAL sakta hai (0.8 se pehle arithmetic wrap, baad me revert). Rule #1 ke hisaab se hum ASSUME nahi karte: na legacy overflow flag kiya, na modern-checked maan liya. Ye audit sirf is exact snippet pe valid hai.",
      defence: "pragma solidity ^0.8.24; pin karo (ya >=0.8.0 <0.9.0). Deployment toolchain (solc, hardhat/foundry settings) ke saath EXACT same version verify karo.",
      defenceCode: `// FIX: exact pin
pragma solidity 0.8.24;   // ya ^0.8.24 — reproducible builds + verified behavior`,
      cwe: "CWE-1104",
    });
  }

  const order: Record<string, number> = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3, INFO: 4 };
  findings.sort((a, b) => order[a.severity] - order[b.severity] || a.line - b.line);
  return { findings, ctx };
}

// back-compat wrapper (live-terminal / purane callers)
export function auditSolidity(source: string): SolidityFinding[] {
  return auditSolidityFull(source).findings;
}

export function solidityVerdict(
  findings: SolidityFinding[],
  fromSource = false,
  ctx?: PragmaContext
): { verdict: "ATTACKABLE" | "SAFE" | "UNKNOWN"; riskScore: number; reason: string } {
  const c = findings.filter((f) => f.severity === "CRITICAL").length;
  const h = findings.filter((f) => f.severity === "HIGH").length;
  const m = findings.filter((f) => f.severity === "MEDIUM").length;
  const l = findings.filter((f) => f.severity === "LOW").length;
  const riskScore = Math.min(100, c * 30 + h * 15 + m * 7 + l * 3);
  if (findings.length === 0) {
    // source-mode me 0 findings = saare detectors + FP cross-checks clear = SAFE
    // bytecode-mode me source hi nahi tha = UNKNOWN (honest uncertainty)
    if (fromSource) {
      // rule #4: SECURE verdict DECLARED PRAGMA ko reference karta hai — generic nahi
      const pragmaBit = ctx?.hasPragma
        ? `declared pragma ${ctx.pragmaRaw} (${ctx.era} era${ctx.era === "LEGACY" ? (ctx.safeMath ? " + SafeMath verified" : " — SafeMath ABSENT") : " — checked arithmetic built-in"})`
        : ctx
          ? "code SECURE hai par compiler version declared nahi — pragma pin karo (reproducible guarantee ke liye)"
          : "static analysis clear";
      return {
        verdict: "SAFE",
        riskScore: 0,
        reason: `Code SECURE according to ${pragmaBit}. 17 detectors + 6 backdoor checks + false-positive cross-verification — sab CLEAR. (Logic-level bugs ke liye manual review + fuzz recommended.)`,
      };
    }
    return { verdict: "UNKNOWN", riskScore: 0, reason: "No Solidity source detected — bytecode-only contract hai. Verified source (etherscan/sourcify) chahiye deeper audit ke liye." };
  }
  // sirf INFO/LOW informational notes — rule #3/#4: classification ya missing-pragma note pe "ATTACKABLE" claim nahi
  const substantive = findings.filter((f) => f.severity !== "INFO" && f.id !== "NO_PRAGMA");
  if (substantive.length === 0) {
    const cls = findings.find((f) => f.id === "CLASSIFICATION");
    const noPragma = findings.some((f) => f.id === "NO_PRAGMA") || (ctx ? !ctx.hasPragma : false);
    const pragmaBit = ctx?.hasPragma
      ? `declared pragma ${ctx.pragmaRaw} (${ctx.era} era)`
      : "static analysis — compiler version UNDECLARED (pragma pin karo, reproducible guarantee ke liye)";
    return {
      verdict: "SAFE",
      riskScore: 0,
      reason: cls
        ? `${ctx?.contractType ?? "CLASSIFIED"} definition — signature-level audit CLEAR per ${pragmaBit}. Runtime attack surface implementing contract me hoga; is snippet me koi exploitable logic NAHI.`
        : noPragma
          ? "Code SECURE hai — koi exploitable pattern nahi. PAR compiler version declared nahi hai: ye guarantee sirf is exact snippet pe hai, kisi specific compiler behavior pe nahi."
          : `Code SECURE per ${pragmaBit} — sirf informational notes, koi exploitable pattern nahi.`,
    };
  }
  if (c > 0 || h >= 2) {
    return { verdict: "ATTACKABLE", riskScore, reason: `${c} critical + ${h} high severity pattern(s) mile — direct exploitation paths available hain.` };
  }
  if (h > 0) {
    return { verdict: "ATTACKABLE", riskScore, reason: `${h} high severity pattern mila — specific conditions me exploit ho sakta hai.` };
  }
  if (m > 0 || l > 0) {
    return { verdict: "SAFE", riskScore, reason: `Sirf ${m} medium / ${l} low severity notes — direct attack path nahi mila, par hardening recommended.` };
  }
  return { verdict: "SAFE", riskScore: 0, reason: "Koi known dangerous pattern detect nahi hua." };
}
