// ARTEX BLACK HAT PERSPECTIVE ENGINE — ethical adversarial simulation (white-hat tooling)
// Attacker ki nazar se: exploit paths, reentrancy doors, privilege escalation,
// hidden backdoors, fund-drain scenarios. Har path ke saath DEFENCE bhi attach hota hai
// (audit-report level content — student ko attacker AUR defender dono ki soch sikhane ke liye).
// FALSE-POSITIVE MITIGATION: har pattern modifier/state/logic cross-verify hota hai —
// sirf regex-match pe flag NAHI lagta (nonReentrant, CEI order, access modifiers check hote hain).
import type { BlackHatReport, BackdoorHit, ExploitPath, PrivEscVector, SolidityFinding, PragmaContext } from "./types";

// ---------- helpers ----------

// function ke scope tak ka text nikaalo (name ke index se, AGLE function tak cut)
function fnText(source: string, name: string): { text: string; line: number } | null {
  const re = new RegExp(`function\\s+${name}\\b`, "i");
  const m = re.exec(source);
  if (!m) return null;
  const line = source.slice(0, m.index).split(/\r?\n/).length;
  return { text: scopeFrom(source, m.index), line };
}

// index se shuru hokar AGLE top-level function declaration tak ka scope —
// taaki agle function ke guards/modifiers is function pe apply na ho (cross-function FP fix)
function scopeFrom(source: string, index: number, max = 700): string {
  const rest = source.slice(index, index + max);
  const nextFn = /\n\s*function\s+\w/.exec(rest);
  return nextFn ? rest.slice(0, nextFn.index) : rest;
}

function lineOf(source: string, index: number): number {
  return source.slice(0, index).split(/\r?\n/).length;
}

// ---------- FALSE-POSITIVE MITIGATION CORE ----------

// CEI (Checks-Effects-Interactions) order verify: kya external call se PEHLE
// balance/state update ho raha hai? Agar haan — reentrancy door effectively band hai.
export function ceiOrderVerified(source: string): boolean {
  const fns = source.match(/function\s+[\w$]+\s*\([^)]*\)[^{]*\{[\s\S]*?\n\s*\}/g) ?? [];
  for (const body of fns) {
    const callM = /\.call\s*\{?\s*(value|\()/i.exec(body);
    if (!callM) continue;
    const before = body.slice(0, callM.index);
    // external call se pehle balance zero/decrement — effects-before-interactions
    if (/(balances?|shares|stakes|deposits?|credits?|amounts?)\s*\[[^\]]*\]\s*(=\s*0\b|-=)/.test(before)) return true;
    if (/\b(mapping|ledger)\s*\[[^\]]*\]\s*=\s*0\b/.test(before)) return true;
  }
  return false;
}

// Cross-verification log — jo guards mile wo yahan report hote hain (UI me green ticks).
// ctx (pragma-context) optional — rule #1: compiler-era claim DECLARED spec se hi aata hai, assume nahi.
export function falsePositiveChecks(source: string, ctx?: PragmaContext, findings?: SolidityFinding[]): string[] {
  const out: string[] = [];

  // ---- PRAGMA / compiler-era cross-verification (STRICT — declared spec hi source of truth) ----
  if (ctx?.hasPragma) {
    if (ctx.era === "MODERN") {
      out.push(`✓ PRAGMA ${ctx.pragmaRaw} cross-verified — MODERN era (>=0.8): checked arithmetic built-in, OVERFLOW flag suppress (${ctx.uncheckedBlocks.length ? `sirf ${ctx.uncheckedBlocks.length} unchecked{} block(s) pe conditional` : "koi unchecked{} bypass nahi"})`);
    } else if (ctx.era === "LEGACY") {
      out.push(ctx.safeMath
        ? `✓ PRAGMA ${ctx.pragmaRaw} (LEGACY <0.8) + SafeMath usage VERIFIED — legacy math guarded, OVERFLOW suppressed`
        : `⚠ PRAGMA ${ctx.pragmaRaw} (LEGACY <0.8) bina SafeMath — OVERFLOW check ACTIVE rakha (state variables wrap ho sakte hain)`);
    } else if (ctx.era === "AMBIGUOUS") {
      out.push(`⚠ PRAGMA ${ctx.pragmaRaw} AMBIGUOUS — range <0.8 aur >=0.8 dono allow karta hai: OVERFLOW conditional flag hua (assume nahi kiya), exact version pin karo`);
    } else {
      out.push("⚠ pragma spec parse nahi hua — assumption-free mode: koi compiler-era claim nahi kiya");
    }
  } else {
    out.push("⚠ compiler version declared NAHI — assumption-free mode: na legacy overflow assume kiya, na modern-checked (rule #1)");
  }

  // ---- OpenZeppelin recognition (rule #3: modern libraries ko correctly classify karo) ----
  if (ctx?.ozModules.length) {
    out.push(`✓ OpenZeppelin audited base classes detected (${ctx.ozModules.slice(0, 6).join(", ")}${ctx.ozModules.length > 6 ? "…" : ""}) — template-backed code, generic HIGH findings template-deviation pe hi lagte hain`);
  }

  // ---- classification note (rule #3) ----
  if (ctx && (ctx.contractType === "INTERFACE" || ctx.contractType === "ABSTRACT" || ctx.contractType === "LIBRARY")) {
    out.push(`ℹ ${ctx.contractType} classification — signature-level audit; runtime attack surface (reentrancy/fund-drain) IMPLEMENTING contract me hoga, is snippet me nahi`);
  }

  const guardGap = Boolean(findings?.some((f) => f.id === "REENTRANCY"));
  if (/ReentrancyGuard/.test(source) && guardGap) {
    out.push("⚠ ReentrancyGuard source me present hai PAR kuch functions pe nonReentrant modifier missing — GUARD GAP findings generate hue (half-fixed contract, FP suppress NAHI kiya)");
  } else if (/nonReentrant|ReentrancyGuard/.test(source)) {
    out.push("✓ ReentrancyGuard/nonReentrant modifier cross-verified (per-function scope me) — guarded functions pe REENTRANCY suppressed");
  } else if (ceiOrderVerified(source)) {
    out.push("✓ CEI order verify hua — external call ke PEHLE state update mila (reentrancy FALSE-POSITIVE removed)");
  } else {
    out.push("⚠ na reentrancy modifier, na CEI order — REENTRANCY door LIVE mark kiya (cross-check fail)");
  }

  if (/onlyOwner|onlyRole|AccessControl|Ownable/.test(source)) {
    out.push("ℹ access-control modifiers detected — protected functions UNPROTECTEDFN/ARBSEND analysis se EXCLUDE hue (fn-scope cross-verified)");
  } else if (ctx?.contractType !== "INTERFACE") {
    out.push("⚠ koi access-control modifier nahi mila — har state-changing fn UNPROTECTED treat kiya");
  }

  if (/MAX_SUPPLY|maxSupply|supplyCap|_cap\b/.test(source)) {
    out.push("✓ supply-cap constant verified — mint analysis me cap context consider hua");
  }
  if (/\bimmutable\b/.test(source)) {
    out.push("ℹ immutable variables present — config values runtime pe hijack nahi ho sakte");
  }
  if (/TimelockController|timelock/i.test(source)) {
    out.push("✓ timelock detected — admin/upgrade actions pe delay hai (one-tx takeover blocked)");
  }
  if (/multisig|MultiSig/i.test(source)) {
    out.push("✓ multisig governance detected — single-key compromise se sirf partial risk");
  }
  return out;
}

// ---------- HIDDEN BACKDOOR DETECTORS (honeypot / rug toolkit) ----------

interface BdDef {
  id: string;
  title: string;
  severity: BackdoorHit["severity"];
  cwe: string;
  detect: (source: string) => { line: number; snippet: string; detail: string } | null;
  attack: string;
  attackCode: string;
  defence: string;
  defenceCode: string;
}

const BACKDOORS: BdDef[] = [
  {
    id: "BD-FAKETRANSFER",
    title: "Fake transfer — returns true, tokens move nahi hote (honeypot core)",
    severity: "CRITICAL",
    cwe: "CWE-20",
    detect: (s) => {
      const ft = fnText(s, "transfer");
      if (!ft) return null;
      const hasTrue = /return\s+true\s*;/.test(ft.text);
      const realMove = /_transfer\s*\(|balances?\s*\[[^\]]*\]\s*-=|\.transfer\(|\.call\{/.test(ft.text);
      if (hasTrue && !realMove) return { line: ft.line, snippet: ft.text.split("\n").slice(0, 4).join(" ").slice(0, 160), detail: "transfer() bool return karta hai par andar KOI token movement nahi — victim ko 'success' dikhata hai, balance wahin rehta hai." };
      return null;
    },
    attack: "TEACHER NOTE: Ye sabse common honeypot hai — buy side real (LP se tokens milte dikhte hain), sell side ye fake transfer chalata hai. Victim ko tx success dikhta hai par tokens stuck. DexScreener pe 'transfer succeeds but no balance change' = instant red flag.",
    attackCode: `// Victim experience:
victim.sell(honey, 10_000e18);      // tx SUCCESS (return true)
honey.balanceOf(victim);            // abhi bhi 10_000e18 — kuch nahi hua!
// Holder sell nahi kar sakta, owner LP drain karta rehta hai`,
    defence: "Standard ERC-20 _transfer() internal hook use karo + OpenZeppelin template. Custom transfer logic = audit mandatory.",
    defenceCode: `// FIX: OZ-standard transfer
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
contract SafeToken is ERC20 {
    // transfer() OZ base se aata hai — _transfer() internally balance move karta hai
    // koi custom 'return true' transfer nahi`,
  },
  {
    id: "BD-SETBALANCE",
    title: "setBalance()/direct balance-write backdoor",
    severity: "CRITICAL",
    cwe: "CWE-284",
    detect: (s) => {
      const m = /function\s+set(Balances?|Shares?|Credits?)\s*\([^)]*\)\s*(public|external)/i.exec(s);
      if (!m) return null;
      if (/only[A-Z]|require\s*\(/.test(scopeFrom(s, m.index))) return null;
      const line = lineOf(s, m.index);
      return { line, snippet: s.split(/\r?\n/)[line - 1]?.trim().slice(0, 160) ?? "", detail: "Koi bhi (ya owner) kisi ka bhi balance set kar sakta hai — infinite mint + arbitrary theft dono isse possible. Ye backdoor commonly 'admin()','fixBalance()','sync()' naam me chhupa hota hai." };
    },
    attack: "TEACHER NOTE: setBalance(attacker, 1e30) — bas. Na mint event, na supply cap, na transfer restriction. Sniffers bhi miss kar dete hain agar naam innocent ho (jaise _syncAccount()).",
    attackCode: `// One-tx theft:
token.setBalance(attacker, token.totalSupply() * 10);
router.swap(attacker → WETH);        // poora LP drain
// ya kisi bhi user ka balance 0 kar do`,
    defence: "Balance writes sirf _mint/_burn/_update ke through — koi direct setter nahi. Har state-write fn pe role-gate + event.",
    defenceCode: `// FIX: setter hatao, standard flow
function _update(address from, address to, uint256 amt) internal override {
    // single source of truth — supply/balance changes yahin audit hote hain
    super._update(from, to, amt);
}`,
  },
  {
    id: "BD-HIDDENMINT",
    title: "Hidden mint inside transfer/_transfer (silent supply inflation)",
    severity: "CRITICAL",
    cwe: "CWE-862",
    detect: (s) => {
      const ft = fnText(s, "_transfer") ?? fnText(s, "transfer");
      if (!ft) return null;
      const mint = /_mint\s*\(|balances?\s*\[[^\]]*\]\s*\+=\s*(?!msg)/.exec(ft.text);
      const isFeeMint = /fee|tax|reward/i.test(ft.text); // fee-mint legit ho sakta hai — sirf FLAG
      if (mint) return { line: ft.line, snippet: ft.text.split("\n").slice(0, 4).join(" ").slice(0, 160), detail: isFeeMint ? "Transfer ke andar mint/balance-add hai (fee/reward naam se justify ho sakta hai) — supply cap bypass + hidden inflation POSSIBLE. Mint-to address kaunsa hai, verify karo." : "Transfer path me bina event ke balance create ho raha hai — invisible inflation backdoor." };
      return null;
    },
    attack: "TEACHER NOTE: Har transfer pe thoda-thoda 'fee' owner ko mint hota hai — ya worse, kisi silent address ko. Supply cap ka promise docs me hota hai, on-chain reality alag. 24h me supply 2x ho sakta hai bina kisi Transfer(0x0,...) event ke.",
    attackCode: `// Silent inflation loop:
// har transfer pe: balances[owner] += amt * 5%   (event NAHI)
owner.transfer(1 wei, self);        // micro-transfers se inflation trigger
// supply check: totalSupply same dikhega, par owner ka balance badh raha hai`,
    defence: "Mint sirf _mint() helper me (event mandatory), supply cap immutable, transfer me koi balance-creation nahi. Supply aur aggregate balances invariant test (foundry invariant test) likho.",
    defenceCode: `// FIX: invariant test
// test/invariants/Supply.t.sol
function invariant_totalSupplyEqualsSum() public view {
    assertEq(token.totalSupply(), sumOfBalances);   // kabhi fail nahi hona chahiye
}`,
  },
  {
    id: "BD-FAKEBALANCE",
    title: "balanceOf() override — fake balance display",
    severity: "HIGH",
    cwe: "CWE-20",
    detect: (s) => {
      const m = /function\s+balanceOf\s*\([^)]*\)[^{]*\{[^}]{0,300}(return\s+\d{4,}|return\s+true\s*;)/i.exec(s);
      if (!m) return null;
      const line = lineOf(s, m.index);
      return { line, snippet: s.split(/\r?\n/)[line - 1]?.trim().slice(0, 160) ?? "", detail: "balanceOf() hardcoded/conditional value return kar raha hai — wallet UI me fake balance dikhega. Scan-tools ko confuse karne ke liye bhi use hota hai." };
    },
    attack: "TEACHER NOTE: Pre-sale scam pattern — dApp 'your balance: 10,000,000 tokens' dikhata hai (jo sirf UI me hai). Investor aur buy karta hai, actual transferable balance 0. On-chain read vs wallet display mismatch = confirm.",
    attackCode: `// Detection (on-chain, UI ke bina):
const real = await token.balanceOf(buyer);         // actual
const shown = await dappContract.shownBalance(buyer); // UI wala
// real !== shown → SCAM confirm`,
    defence: "balanceOf() standard mapping read hi rakho — koi conditional/logic nahi. OZ ERC-20 template use karo.",
    defenceCode: `// FIX:
function balanceOf(address a) public view override returns (uint256) {
    return _balances[a];        // bas. koi logic nahi.
}`,
  },
  {
    id: "BD-ALLOWSETTER",
    title: "Public allowance setter — kisi ke naam se spend approval",
    severity: "HIGH",
    cwe: "CWE-284",
    detect: (s) => {
      const m = /function\s+(set|force|increase|grant)\w*(Allowance|Approval|Approve)\w*\s*\([^)]*\)\s*(public|external)/i.exec(s);
      if (!m) return null;
      if (/only[A-Z]|msg\.sender\s*==/.test(scopeFrom(s, m.index))) return null;
      const line = lineOf(s, m.index);
      return { line, snippet: s.split(/\r?\n/)[line - 1]?.trim().slice(0, 160) ?? "", detail: "Allowance/approval directly set karne wala public function — attacker (ya owner) kisi bhi user ke naam se tokens spend kar sakta hai, ya fake allowance dikha ke fake-buy order bana sakta hai." };
    },
    attack: "TEACHER NOTE: allowance[victim][attacker] = unlimited → transferFrom(victim → attacker). Na approve tx, na victim ki galti. Pair-contract me fake allowance dikha ke market-making bot ko trap bhi karte hain.",
    attackCode: `// Attack:
token.grantAllowance(victim, attacker, type(uint256).max);   // koi guard nahi
token.transferFrom(victim, attacker, token.balanceOf(victim));  // victim drained`,
    defence: "Allowance sirf approve()/transferFrom() standard flow se change ho. Koi bhi direct allowance-setter nahi.",
    defenceCode: `// FIX: standard approve only
function approve(address spender, uint256 amt) public returns (bool) {
    _approve(msg.sender, spender, amt);   // owner = msg.sender ALWAYS
    return true;
}`,
  },
  {
    id: "BD-SELLSWITCH",
    title: "Owner-controlled trading switch — sell anytime ban (soft honeypot)",
    severity: "HIGH",
    cwe: "CWE-284",
    detect: (s) => {
      const m = /function\s+(setTrading|enableTrading|setSells?Enabled|setSellOpen)\s*\(/i.exec(s);
      if (!m) return null;
      const line = lineOf(s, m.index);
      return { line, snippet: s.split(/\r?\n/)[line - 1]?.trim().slice(0, 160) ?? "", detail: "Trading/sell switch OWNER ke haath me hai — launch ke baad owner sells disable kar sakta hai. Fixed deadline ki jagah dynamic switch = soft-honeypot shape." };
    },
    attack: "TEACHER NOTE: Sequence: (1) marketing chalao, buy volume banao. (2) price peak pe setTrading(false). (3) holders sell nahi kar sakte. (4) owner apna bag LP me dump karta hai. (5) 'we are fixing a bug' excuse + relaunch. Fixed immutable deadline hi defence hai.",
    attackCode: `// Rug timeline:
day 1:  setTrading(true);            // buy open
day 30: holders peak pe pahunche
day 31: setTrading(false);           // sab sell locked
day 31: LP.removeLiquidity();        // owner exit — holders trapped`,
    defence: "Trading open time IMMUTABLE constructor-set deadline — koi owner switch nahi. emergency pause ho to timelock + public event + auto-reopen.",
    defenceCode: `// FIX:
uint256 public immutable TRADING_OPEN;   // constructor: block.timestamp + 0 (fair launch)
function _update(address from, address to, uint256 amt) internal override {
    if (!tradingOpen()) revert("trading not open");   // sirf TIME pe depend, owner flag pe nahi
    super._update(from, to, amt);
}`,
  },
];

// ---------- EXPLOIT PATH BUILDER (findings → attacker chains) ----------

function buildExploitPaths(findings: SolidityFinding[], source: string): ExploitPath[] {
  const has = (id: string) => findings.some((f) => f.id === id);
  const paths: ExploitPath[] = [];

  // REENTRANCY finding khud per-fn cross-verified hai — isliye source-level guard check ki zaroorat nahi
  // (guard-gap case me bhi path chahiye: imported guard + missing modifier = exploitable door)
  if (has("REENTRANCY")) {
    paths.push({
      id: "EP-1",
      title: "Reentrancy door — full-balance drain loop",
      derivedFrom: ["REENTRANCY"],
      difficulty: "EASY",
      steps: [
        "1. Attacker deploy kare Attacker.sol with receive() hook",
        "2. victim.deposit{value: 1 ether}() — legit entry ban jao",
        "3. victim.withdraw(1 ether) — external .call attacker pe wapas aata hai",
        "4. receive() hook: balance abhi update NAHI hua → phir withdraw() call",
        "5. Loop repeat jab tak contract ka ETH khatam",
      ],
      impact: "Contract ka poora ETH balance ek tx-chain me nikaal jata hai (The DAO: $60M)",
      maxDamage: "100% contract ETH balance",
    });
  }

  if (has("DELEGATECALL")) {
    const proxyChain = has("PROXY") || /_upgradeTo|upgradeTo\s*\(/.test(source);
    paths.push({
      id: `EP-${paths.length + 1}`,
      title: proxyChain ? "Proxy/impl hijack — storage takeover se full drain" : "delegatecall storage hijack — full drain",
      derivedFrom: ["DELEGATECALL", ...(proxyChain ? ["PROXY"] : [])],
      difficulty: has("UNPROTECTEDFN") ? "TRIVIAL" : "MEDIUM",
      steps: [
        "1. Implementation address setter ka access level confirm karo (unprotected? owner-only?)",
        "2. Attacker apna MaliciousImpl deploy karta hai: owner=attacker / balances overwrite",
        has("UNPROTECTEDFN") ? "3. setImpl() koi bhi call kar sakta hai — seedha MaliciousImpl pe point karo" : "3. Owner key compromise (phishing) → setImpl(MaliciousImpl)",
        "4. Ab VICTIM ke storage pe attacker ka code chal raha hai",
        "5. withdrawAll() / selfdestruct / balance-overwrite — sab kuch drain",
      ],
      impact: "Poora storage hijack — owner, balances, sab attacker control me (Parity: $150M+ locked)",
      maxDamage: "100% — funds + contract control + code",
    });
  }

  if (has("UNPROTECTEDFN")) {
    paths.push({
      id: `EP-${paths.length + 1}`,
      title: "Instant takeover — unprotected admin function",
      derivedFrom: ["UNPROTECTEDFN"],
      difficulty: "TRIVIAL",
      steps: [
        "1. etherscan pe Write-Contract tab kholo (koi key chahiye hi nahi)",
        "2. setOwner(attacker) — ownership transfer ho gaya",
        "3. withdrawAll() / drain functions ab legit-owner ki tarah call karo",
      ],
      impact: "Script-kiddy level pe full compromise — scanners me highest-frequency bug",
      maxDamage: "100% — owner ke saare powers",
    });
  }

  if (has("ARBSEND")) {
    paths.push({
      id: `EP-${paths.length + 1}`,
      title: "Arbitrary-send sweep — treasury one-tx drain",
      derivedFrom: ["ARBSEND"],
      difficulty: "TRIVIAL",
      steps: [
        "1. rescueToken(USDT, attacker) — destination user-controlled hai",
        "2. Contract ka pura token balance attacker wallet me",
        "3. Repeat for har token jo contract hold karta hai",
      ],
      impact: "Har held token one-tx me out — treasury empty",
      maxDamage: "100% of all token balances held",
    });
  }

  if (has("OPENMINT") || has("HIDDENMINT")) {
    paths.push({
      id: `EP-${paths.length + 1}`,
      title: "Infinite mint → LP drain (value collapse)",
      derivedFrom: [has("OPENMINT") ? "OPENMINT" : "HIDDENMINT"],
      difficulty: "TRIVIAL",
      steps: [
        "1. mint(attacker, 10**30) — supply inflate (access control absent)",
        "2. DEX pe chhote amounts sell karo — price floor se neeche",
        "3. LP ki poori quote-side value attacker ke paas",
        "4. Original holders: paper value zero (soft-rug)",
      ],
      impact: "Supply infinite → token price → 0, LP swept",
      maxDamage: "100% LP value + holders ka paper wealth",
    });
  }

  if (has("SELFDESTRUCT")) {
    paths.push({
      id: `EP-${paths.length + 1}`,
      title: "Kill-switch abuse — contract burn + force-ETH",
      derivedFrom: ["SELFDESTRUCT"],
      difficulty: has("TXORIGIN") || has("UNPROTECTEDFN") ? "EASY" : "HARD",
      steps: [
        "1. destroy()/selfdestruct ka access path confirm karo (owner? unprotected?)",
        has("TXORIGIN") ? "2. tx.origin phishing se owner tx trigger karwao" : "2. Owner key compromise ya unprotected fn se trigger",
        "3. selfdestruct(payable(attacker)) — code delete, funds out",
        "4. Bonus: selfdestruct wale contracts receive() bypass karke ETH force-send kar sakte hain",
      ],
      impact: "Irreversible — code + treasury dono gone (EIP-6780 ke baad bhi legacy contracts pe valid)",
      maxDamage: "100% — non-recoverable",
    });
  }

  if (has("OVERFLOW")) {
    paths.push({
      id: `EP-${paths.length + 1}`,
      title: "Arithmetic underflow — infinite balance mint",
      derivedFrom: ["OVERFLOW"],
      difficulty: "EASY",
      steps: [
        "1. Compiler <0.8 confirm (wrap possible)",
        "2. balances[attacker] - 1e30 → wraps to ~2^256",
        "3. Ab attacker ke paas effectively infinite tokens",
        "4. Poore supply kisi bhi DEX pe dump karo",
      ],
      impact: "Beco/SMT-style: total supply infinite, sab exchanges drained",
      maxDamage: "100% + every market that lists the token",
    });
  }

  if (has("TXORIGIN")) {
    paths.push({
      id: `EP-${paths.length + 1}`,
      title: "tx.origin phishing relay — victim se victim ka hi funds",
      derivedFrom: ["TXORIGIN"],
      difficulty: "MEDIUM",
      steps: [
        "1. Victim ko airdrop-claim contract bhejo (social engineering)",
        "2. Victim claim() call karta hai — andar Phish contract",
        "3. Phish → VictimVault.withdrawAll(): msg.sender=Phish (fail expected) PAR tx.origin=victim (PASS!)",
        "4. Victim ka vault empty — victim ne khud sign kiya",
      ],
      impact: "Auth bypass via identity confusion — victim apna hi drain karwata hai",
      maxDamage: "Victim ke vault ka 100%",
    });
  }

  if (has("OWNERFIRST") || has("BLACKLIST")) {
    paths.push({
      id: `EP-${paths.length + 1}`,
      title: "Honeypot trap — holders freeze + LP exit",
      derivedFrom: [has("OWNERFIRST") ? "OWNERFIRST" : "BLACKLIST"],
      difficulty: "TRIVIAL",
      steps: [
        "1. Buy side open rakho — volume aur hype banao",
        "2. Peak pe: blacklist all buyers / sell-gate enforce",
        "3. Holders sell nahi kar sakte (revert)",
        "4. Owner LP remove — holders ke tokens worthless paper",
      ],
      impact: "Direct theft by design — ye bug nahi, FEATURE hai scam contract me",
      maxDamage: "100% of victims' invested value",
    });
  }

  return paths;
}

// ---------- PRIVILEGE ESCALATION ----------

function buildPrivEsc(findings: SolidityFinding[], source: string): PrivEscVector[] {
  const out: PrivEscVector[] = [];
  const has = (id: string) => findings.some((f) => f.id === id);

  // poora signature capture karo ({ tak) — phir modifier cross-verify karo
  // (lookahead-only approach backtracking se false-positive deta hai: "external onlyOwner" match ho jata tha)
  const setOwner = /function\s+(setOwner|setAdmin|transferOwnership)\s*\([^)]*\)[^{]*\{/i.exec(source);
  if (setOwner && !/only[A-Z]|require\s*\(|msg\.sender\s*==|_msgSender/.test(setOwner[0])) {
    const line = lineOf(source, setOwner.index);
    out.push({
      vector: "Unprotected ownership setter",
      detail: "setOwner()/transferOwnership() koi bhi call kar sakta hai — instant admin takeover. Uske baad har 'owner-only' function attacker ka.",
      prerequisite: "Ek bhi tx (gas ka kharcha bhi nahi) — zero skill",
      line,
    });
  }
  if (has("TXORIGIN")) {
    out.push({
      vector: "tx.origin phishing → privilege relay",
      detail: "Victim ke tx.origin se auth hone wale functions attacker ke phishing contract ke through call ho sakte hain — victim khud attacker ko apne privileges de deta hai.",
      prerequisite: "Social engineering (victim ko malicious contract pe tx karwana)",
    });
  }
  if (has("DELEGATECALL")) {
    out.push({
      vector: "delegatecall → slot-0 ownership overwrite",
      detail: "Malicious implementation me `owner = attacker` likho — victim ke storage slot-0 pe likh jayega (owner almost always slot 0 hota hai). Ab LEGIT ownership attacker ke paas.",
      prerequisite: "Implementation setter ka access (unprotected ya compromised key)",
    });
  }
  const init = /function\s+initialize\s*\(/i.exec(source);
  if (init) {
    const ctx = source.slice(Math.max(0, init.index - 60), init.index + 300);
    if (!/initializer|initialized\b/.test(ctx)) {
      const line = lineOf(source, init.index);
      out.push({
        vector: "Re-initialization takeover",
        detail: "initialize() bina initializer-guard ke — proxy deploy ke baad attacker khud initialize() call karke apna owner/admin set kar leta hai.",
        prerequisite: "Contract uninitialized state me ho (fresh deploy ya upgrade ke baad)",
        line,
      });
    }
  }
  if (has("PROXY") && !/TimelockController|timelock/i.test(source)) {
    out.push({
      vector: "Upgrade-path escalation (no timelock)",
      detail: "upgradeTo() timelock ke bina — admin key (ya compromised multisig) one-tx me malicious impl laga ke saare privileges le sakta hai. Community ko react ka time hi nahi milta.",
      prerequisite: "Proxy-admin key access (ya admin key compromise)",
    });
  }
  return out;
}

// ---------- FUND DRAIN SCENARIO ----------

function buildFundDrain(findings: SolidityFinding[], source: string, paths: ExploitPath[], ctx?: PragmaContext): { feasible: boolean; steps: string[]; maxDamage: string; blockers: string[] } {
  const has = (id: string) => findings.some((f) => f.id === id);
  const steps: string[] = [];
  let feasible = false;
  let maxDamage = "—";

  if (paths.some((p) => p.difficulty === "TRIVIAL" || p.difficulty === "EASY")) {
    feasible = true;
    steps.push("RECON: etherscan pe verified source + Write-Contract tab — exploit entry points list karo");
  }
  if (has("UNPROTECTEDFN") || has("ARBSEND")) {
    feasible = true;
    steps.push("DRAIN: unprotected withdrawAll()/rescueToken() — destination attacker, one tx, 100% out");
    maxDamage = "100% treasury (tokens + ETH) — single transaction";
  } else if (has("REENTRANCY")) {
    feasible = true;
    steps.push("DRAIN: reentrancy loop — deposit → withdraw → receive() hook → repeat; maxDamage = full contract balance");
    maxDamage = "100% contract ETH balance";
  } else if (has("DELEGATECALL")) {
    feasible = true;
    steps.push("DRAIN: impl hijack → storage overwrite → sweep — owner+balances attacker ke");
    maxDamage = "100% — total contract control";
  } else if (has("OPENMINT") || has("HIDDENMINT")) {
    feasible = true;
    steps.push("DRAIN: mint infinite → DEX sell → LP quote-side sweep");
    maxDamage = "100% LP value (holders ka paper value zero)";
  }

  // fallback: koi dedicated drain-branch nahi hit, par TRIVIAL/EASY path hai — uska maxDamage use karo
  if (feasible && maxDamage === "—") {
    const p0 = paths.find((p) => p.difficulty === "TRIVIAL") ?? paths.find((p) => p.difficulty === "EASY");
    if (p0) maxDamage = p0.maxDamage;
  }

  const blockers: string[] = [];
  if (!feasible) {
    if (/nonReentrant|ReentrancyGuard/.test(source)) blockers.push("ReentrancyGuard — reentrancy door band (fn-scope cross-verified)");
    if (ceiOrderVerified(source)) blockers.push("CEI order verified — external call pehle-safe state ke saath");
    if (/onlyOwner|onlyRole|AccessControl/.test(source)) blockers.push("Access control modifiers — admin fns gated");
    if (ctx?.era === "MODERN") blockers.push(`PRAGMA ${ctx.pragmaRaw} (MODERN >=0.8) — checked arithmetic, wrap attacks impossible${ctx.uncheckedBlocks.length ? ` (sirf ${ctx.uncheckedBlocks.length} unchecked{} block(s) manual-review)` : ""}`);
    else if (ctx?.era === "LEGACY" && ctx.safeMath) blockers.push("SafeMath verified — legacy arithmetic guarded");
    if (ctx && (ctx.contractType === "INTERFACE" || ctx.contractType === "LIBRARY")) blockers.push(`${ctx.contractType} classification — executable attack surface is snippet me exist hi nahi karta`);
    blockers.push("Koi direct fund-extraction path nahi mila — deeper logic bugs ke liye manual review + foundry fuzz recommended");
  }
  return { feasible, steps, maxDamage, blockers };
}

// ---------- MAIN ENTRY ----------

export function blackHatAnalysis(source: string, findings: SolidityFinding[], ctx?: PragmaContext): BlackHatReport {
  const crossChecks = falsePositiveChecks(source, ctx, findings);

  // backdoors detect (finding-independent — ye 17-detector set ke BEYOND hain)
  const backdoors: BackdoorHit[] = [];
  for (const bd of BACKDOORS) {
    const hit = bd.detect(source);
    if (hit) {
      backdoors.push({
        id: bd.id,
        title: bd.title,
        severity: bd.severity,
        line: hit.line,
        snippet: hit.snippet,
        detail: hit.detail,
        attack: bd.attack,
        attackCode: bd.attackCode,
        defence: bd.defence,
        defenceCode: bd.defenceCode,
        cwe: bd.cwe,
      });
    }
  }
  if (backdoors.length === 0) {
    crossChecks.push("✓ 6 hidden-backdoor detectors (fake-transfer / setBalance / hidden-mint / fake-balanceOf / allowance-setter / sell-switch) — sab CLEAR");
  } else {
    crossChecks.push(`⚠ ${backdoors.length} backdoor shape(s) matched — HAR EK ko manual verify karo (context matters)`);
  }

  const exploitPaths = buildExploitPaths(findings, source);
  const privEsc = buildPrivEsc(findings, source);
  const fundDrain = buildFundDrain(findings, source, exploitPaths, ctx);

  const trivial = exploitPaths.filter((p) => p.difficulty === "TRIVIAL").length;
  const attackerProfile =
    exploitPaths.length === 0
      ? "Direct attack path nahi — attacker ko logic-level bug dhoondhne padenge (manual review / fuzzing). Automated exploit nahi possible."
      : trivial > 0
        ? `${trivial} TRIVIAL path(s) — script-kiddy sufficient: etherscan Write-tab + Remix se one-tx exploit. Ye contract LIVE threat model me highest priority ka target hai.`
        : `Intermediate attacker sufficient — multi-step chain (deploy attacker contract + ${exploitPaths.length} phase sequence). MEV bots is shape ko automatically hunt karte hain.`;

  return {
    sourceMode: "SOURCE",
    exploitPaths,
    privEsc,
    backdoors,
    fundDrain,
    crossChecks,
    attackerProfile,
  };
}

// bytecode-only minimal report (source nahi hai to logic-level analysis impossible — honest output)
export function blackHatBytecodeOnly(note: string): BlackHatReport {
  return {
    sourceMode: "BYTECODE-ASSUMED",
    exploitPaths: [],
    privEsc: [],
    backdoors: [],
    fundDrain: {
      feasible: false,
      steps: [],
      maxDamage: "—",
      blockers: ["Source unavailable — logic-level exploit paths derive NAHI kar sakte (guessing = false positives)", note],
    },
    crossChecks: [
      "⚠ BYTECODE-ASSUMED mode — modifier/state/logic cross-verification source ke bina IMPOSSIBLE hai",
      "⚠ Sirf bytecode-heuristic flags active hain (compiler-era check) — inhe findings me [BYTECODE-ASSUMED] tag milta hai",
      "→ Verified source (etherscan 'Contract Source' button) paste karo — full black-hat analysis tab milegi",
    ],
    attackerProfile: "Unknown — bytecode se intent nahi padha jata. Verified source chahiye.",
  };
}
