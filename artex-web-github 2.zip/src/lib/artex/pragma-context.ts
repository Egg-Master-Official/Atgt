// ARTEX STRICT PRAGMA & VERSION CONTEXT — CRITICAL AUDIT RULE #1 & #2 engine
// "Always analyze the EXACT compiler version declared in the pragma statement.
//  Do NOT assume older versions (<0.8) or missing SafeMath unless explicitly present."
// Ye module paste kiye gaye source ka version-context banata hai — detectors isi se gate hote hain.
import type { PragmaContext } from "./types";

type Ver = [number, number, number];

// OpenZeppelin audited base classes — recognition list (FP mitigation: template-backed code
// pe generic HIGH findings nahi lagte, sirf template-deviation pe)
const OZ_KNOWN = new Set([
  "ReentrancyGuard", "Ownable", "AccessControl", "AccessControlDefaultAdminRules", "SafeERC20",
  "SafeMath", "Pausable", "ERC20", "ERC20Burnable", "ERC20Capped", "ERC20Pausable", "ERC20Permit",
  "ERC20Votes", "ERC20FlashMint", "ERC721", "ERC1155", "Initializable", "UUPSUpgradeable",
  "TransparentUpgradeableProxy", "TimelockController", "BeaconProxy", "ERC1967Proxy", "ERC1967Upgrade",
  "Address", "Context", "IERC20", "IERC20Permit", "Counters", "ECDSA", "SignatureChecker", "EIP712",
  "Multicall", "ERC165", "PullPayment", "Escrow", "PaymentSplitter", "VestingWallet", "ERC20Wrapper",
]);

function parseVer(v: string): Ver {
  const p = v.trim().split(".").map((n) => parseInt(n, 10) || 0);
  return [p[0] ?? 0, p[1] ?? 0, p[2] ?? 0];
}

function cmp(a: Ver, b: Ver): number {
  for (let i = 0; i < 3; i++) {
    if (a[i] !== b[i]) return a[i] < b[i] ? -1 : 1;
  }
  return 0;
}

const V08: Ver = [0, 8, 0];
const verStr = (v: Ver | null) => (v ? v.join(".") : null);

// caret semantics: ^0.8.24 → >=0.8.24 <0.9.0 (leftmost non-zero component lock)
function caretUpper(v: Ver): Ver {
  if (v[0] > 0) return [v[0] + 1, 0, 0];
  if (v[1] > 0) return [0, v[1] + 1, 0];
  return [0, 0, v[2] + 1];
}

export function parsePragmaContext(source: string): PragmaContext {
  const ctx: PragmaContext = {
    pragmaRaw: null,
    hasPragma: false,
    era: "UNKNOWN",
    minVersion: null,
    maxVersion: null,
    safeMath: false,
    contractType: "NONE",
    contractName: null,
    ozModules: [],
    uncheckedBlocks: [],
  };

  // ---- 1) pragma statement — EXACT declared spec ----
  const pm = /pragma\s+solidity\s+([^;]+);/.exec(source);
  if (pm) {
    ctx.hasPragma = true;
    ctx.pragmaRaw = pm[1].trim().replace(/\s+/g, " ");
    let min: Ver | null = null;
    let max: Ver | null = null; // EXCLUSIVE upper bound
    for (const tok of ctx.pragmaRaw.split(/\s+/)) {
      let m: RegExpExecArray | null;
      if ((m = /^\^(\d+\.\d+(?:\.\d+)?)/.exec(tok))) {
        const v = parseVer(m[1]);
        if (!min || cmp(v, min) < 0) min = v;
        const up = caretUpper(v);
        if (!max || cmp(up, max) < 0) max = up;
      } else if ((m = /^>=(\d+\.\d+(?:\.\d+)?)/.exec(tok))) {
        const v = parseVer(m[1]);
        if (!min || cmp(v, min) < 0) min = v;
      } else if ((m = /^>(\d+\.\d+(?:\.\d+)?)/.exec(tok))) {
        const v = parseVer(m[1]);
        const vNext: Ver = [v[0], v[1], v[2] + 1]; // exclusive-lower ko practical min banao
        if (!min || cmp(vNext, min) < 0) min = vNext;
      } else if ((m = /^<=(\d+\.\d+(?:\.\d+)?)/.exec(tok))) {
        const v = parseVer(m[1]);
        const up: Ver = [v[0], v[1], v[2] + 1];
        if (!max || cmp(up, max) < 0) max = up;
      } else if ((m = /^<(\d+\.\d+(?:\.\d+)?)/.exec(tok))) {
        const v = parseVer(m[1]);
        if (!max || cmp(v, max) < 0) max = v;
      } else if ((m = /^(\d+\.\d+(?:\.\d+)?)$/.exec(tok))) {
        // exact pin: 0.8.19
        const v = parseVer(m[1]);
        min = v;
        const up: Ver = [v[0], v[1], v[2] + 1];
        if (!max || cmp(up, max) < 0) max = up;
      }
    }
    ctx.minVersion = verStr(min);
    ctx.maxVersion = verStr(max);
    // era — STRICT: sirf declared spec se, koi assumption nahi
    if (min && cmp(min, V08) >= 0) ctx.era = "MODERN";
    else if (max && cmp(max, V08) <= 0) ctx.era = "LEGACY";
    else if (min || max) ctx.era = "AMBIGUOUS";
    else ctx.era = "UNKNOWN";
  }

  // ---- 2) SafeMath — EXPLICITLY present? (rule 1: assume nahi, verify karo) ----
  ctx.safeMath =
    /using\s+SafeMath\s+for/.test(source) ||
    /SafeMath\s*\.\s*(mul|add|sub|div|mod)\s*\(/.test(source) ||
    /import\s*\{[^}]*SafeMath[^}]*\}\s*from\s*"[^"]*SafeMath\.sol"/.test(source);

  // ---- 3) contract type classification (rule 3) ----
  // line-start ke saath-saath single-line form bhi: terminal pastes me newline collapse ho jata hai.
  // same-line match sirf Capitalized identifier pe (Solidity convention) — comments me 'contract has {' FP na ho
  const hasConcrete =
    /(^|\n)[ \t]*(?:abstract\s+)?contract\s+\w/.test(source) ||
    /\b(?:abstract\s+)?contract\s+[A-Z]\w*\s*(\{|is\b)/.test(source);
  const hasAbstract =
    /(^|\n)[ \t]*abstract\s+contract\s+\w/.test(source) ||
    /\babstract\s+contract\s+[A-Z]\w*\s*(\{|is\b)/.test(source);
  const hasInterface =
    /(^|\n)[ \t]*interface\s+\w/.test(source) ||
    /\binterface\s+[A-Z]\w*\s*\{/.test(source);
  const hasLibrary =
    /(^|\n)[ \t]*library\s+\w/.test(source) ||
    /\blibrary\s+[A-Z]\w*\s*\{/.test(source);
  if (hasAbstract) ctx.contractType = "ABSTRACT";
  else if (hasInterface && !hasConcrete) ctx.contractType = "INTERFACE";
  else if (hasLibrary && !hasConcrete) ctx.contractType = "LIBRARY";
  else if (hasConcrete) ctx.contractType = "CONTRACT";

  // contractName: DETECTED type ke matching declaration se — (interface+contract file me
  // pehla decl interface ho sakta hai, isliye type-specific regex pehle)
  const nameRes: Array<[PragmaContext["contractType"], RegExp]> = [
    ["ABSTRACT", /(?:^|\n|[ \t])abstract\s+contract\s+([A-Z]\w*)/],
    ["INTERFACE", /(?:^|\n|[ \t])interface\s+([A-Z]\w*)/],
    ["LIBRARY", /(?:^|\n|[ \t])library\s+([A-Z]\w*)/],
    ["CONTRACT", /(?:^|\n|[ \t])contract\s+([A-Z]\w*)/],
  ];
  for (const [t, re] of nameRes) {
    if (ctx.contractType !== t) continue;
    const dm = re.exec(source);
    if (dm) { ctx.contractName = dm[1]; break; }
  }
  if (!ctx.contractName) {
    const dm = /(?:^|\n|[ \t])(?:abstract\s+)?(?:contract|interface|library)\s+([A-Z]\w*)/.exec(source);
    if (dm) ctx.contractName = dm[1];
  }

  // ---- 4) OpenZeppelin modules — import/inheritance se EXPLICIT recognition ----
  const oz = new Set<string>();
  for (const m of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*"[^"]*@openzeppelin[^"]*"/g)) {
    for (const name of m[1].split(",")) {
      const n = name.trim().split(/\s+as\s+/)[0].trim();
      if (n) oz.add(n);
    }
  }
  for (const m of source.matchAll(/import\s*"([^"]*@openzeppelin[^"]*\/(\w+)\.sol)"/g)) {
    oz.add(m[2]);
  }
  const inherit = /(?:contract|abstract\s+contract)\s+\w+[^{]*\bis\b\s+([^{\n]+)\{/.exec(source);
  if (inherit) {
    for (const part of inherit[1].split(",")) {
      const n = part.trim().split(/\s*\(/)[0].trim();
      if (OZ_KNOWN.has(n)) oz.add(n);
    }
  }
  ctx.ozModules = [...oz].sort();

  // ---- 5) unchecked{} blocks — MODERN era me checked-math bypass points (evidence lines) ----
  for (const m of source.matchAll(/unchecked\s*\{/g)) {
    const line = source.slice(0, m.index ?? 0).split(/\r?\n/).length;
    if (!ctx.uncheckedBlocks.includes(line)) ctx.uncheckedBlocks.push(line);
  }

  return ctx;
}

// human-readable one-liner — logs/badges ke liye
export function pragmaSummary(ctx: PragmaContext): string {
  const pragma = ctx.hasPragma ? ctx.pragmaRaw : "UNDECLARED";
  const type = ctx.contractType === "NONE" ? "no contract" : `${ctx.contractType.toLowerCase()} ${ctx.contractName ?? ""}`.trim();
  const oz = ctx.ozModules.length ? ` · OZ: ${ctx.ozModules.slice(0, 4).join(", ")}${ctx.ozModules.length > 4 ? `+${ctx.ozModules.length - 4}` : ""}` : "";
  const sm = ctx.era === "LEGACY" || ctx.safeMath ? ` · SafeMath: ${ctx.safeMath ? "verified" : "absent"}` : "";
  const un = ctx.uncheckedBlocks.length ? ` · unchecked{}: ${ctx.uncheckedBlocks.length}` : "";
  return `pragma ${pragma} → ${ctx.era} era · ${type}${sm}${un}${oz}`;
}
