// ARTEX Security Suite - Shared Types

export type Severity = "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | "INFO";
export type ModuleStatus = "PASS" | "WARN" | "FAIL" | "ERROR" | "PENDING";

// ---------- NDJSON wire protocol ----------
export type StreamEvent =
  | { event: "start"; data: Record<string, unknown> }
  | { event: "log"; data: { message: string; level?: "info" | "warn" | "error" | "ok" } }
  | { event: "context"; data: PragmaContext }
  | { event: "module"; data: ScanModule }
  | { event: "finding"; data: (ScanFinding | PhpFinding | SolidityFinding) & { module?: string } }
  | { event: "blackhat"; data: BlackHatReport }
  | { event: "score"; data: { score: number; max: number; verdict: string } }
  | { event: "done"; data: Record<string, unknown> }
  | { event: "error"; data: { message: string } };

// ---------- Website Scanner ----------
export interface ScanFinding {
  title: string;
  severity: Severity;
  detail: string;
  attack: string;
  attackCode?: string; // real exploit/payload code (HACK box me code block)
  defence: string;
  defenceCode?: string; // real fix code (config/headers/server)
}

export interface ScanModule {
  id: string;
  name: string;
  icon: string;
  status: ModuleStatus;
  score: number; // 0-100
  findings: ScanFinding[];
  summary: string;
}

export interface ScanResult {
  target: string;
  timestamp: string;
  score: number;
  verdict: string;
  modules: ScanModule[];
  online: boolean;
}

// ---------- BLACK HAT PERSPECTIVE (ethical adversarial simulation) ----------
export interface ExploitPath {
  id: string; // EP-1, EP-2...
  title: string;
  derivedFrom: string[]; // kaunse finding ids se chain bana
  difficulty: "TRIVIAL" | "EASY" | "MEDIUM" | "HARD";
  steps: string[]; // attacker ka tx-sequence (teacher-style)
  impact: string;
  maxDamage: string;
}

export interface PrivEscVector {
  vector: string;
  detail: string;
  prerequisite: string;
  line?: number;
}

export interface BackdoorHit {
  id: string;
  title: string;
  severity: Severity;
  line: number;
  snippet: string;
  detail: string; // backdoor kaise chhupa hai
  attack: string;
  attackCode?: string;
  defence: string;
  defenceCode?: string;
  cwe: string;
}

export interface FundDrainScenario {
  feasible: boolean;
  steps: string[];
  maxDamage: string;
  blockers: string[];
}

export interface BlackHatReport {
  sourceMode: "SOURCE" | "BYTECODE-ASSUMED";
  exploitPaths: ExploitPath[];
  privEsc: PrivEscVector[];
  backdoors: BackdoorHit[];
  fundDrain: FundDrainScenario;
  crossChecks: string[]; // false-positive mitigation log (kya suppress/verify hua)
  attackerProfile: string;
}

// ---------- STRICT PRAGMA & VERSION CONTEXT (CRITICAL AUDIT RULE #1/#2/#3) ----------
// Source me DECLARED compiler spec se derive hota hai — kabhi assume nahi karte.
export interface PragmaContext {
  pragmaRaw: string | null; // "^0.8.24" jaisa likha hai waisa hi
  hasPragma: boolean; // pragma statement declared hai ya nahi
  era: "MODERN" | "LEGACY" | "AMBIGUOUS" | "UNKNOWN"; // MODERN = guaranteed >=0.8, LEGACY = guaranteed <0.8, AMBIGUOUS = range 0.8 cross karta hai
  minVersion: string | null; // "0.8.24" — declared range ka lower bound
  maxVersion: string | null; // exclusive upper bound ya null
  safeMath: boolean; // SafeMath EXPLICITLY source me hai (rule: assume nahi, verify)
  contractType: "CONTRACT" | "INTERFACE" | "ABSTRACT" | "LIBRARY" | "NONE"; // rule #3 classification
  contractName: string | null;
  ozModules: string[]; // OpenZeppelin audited base classes (import/inheritance se)
  uncheckedBlocks: number[]; // unchecked{} declaration lines (MODERN era me checked-math bypass points)
}

// ---------- Token Auditor ----------
export interface SolidityFinding {
  id: string;
  title: string;
  severity: Severity;
  line: number;
  snippet: string;
  attack: string;
  attackCode?: string; // exploit contract / attack tx sequence
  defence: string;
  defenceCode?: string; // hardened Solidity fix snippet
  cwe: string;
}

export interface OnChainInfo {
  online: boolean;
  chainId?: number;
  address: string;
  codeSize?: number;
  name?: string;
  symbol?: string;
  decimals?: string;
  totalSupply?: string;
  note?: string;
}

export interface AuditResult {
  address: string;
  timestamp: string;
  onChain: OnChainInfo;
  findings: SolidityFinding[];
  riskScore: number;
  verdict: "ATTACKABLE" | "SAFE" | "UNKNOWN";
  verdictReason: string;
}

// ---------- PHP Scanner ----------
export interface PhpFinding {
  id: string;
  bugClass: string; // e.g. "SQL Injection"
  code: string; // e.g. "SQLI"
  cwe: string;
  severity: Severity;
  line: number;
  snippet: string;
  alsoLines?: number[]; // same bug class ke baaki lines (merged card — duplicates avoid)
  attack: string; // teacher-style attack scenario prose
  attackCode?: string; // real payload/exploit code
  defence: string; // defence prose
  defenceCode?: string; // PHP fix code (multi-line)
}

export interface PhpScanSummary {
  totalLines: number;
  totalFindings: number; // merged unique bug cards
  totalInstances?: number; // raw pre-merge count (kitni lines pe bug hai)
  critical: number;
  high: number;
  medium: number;
  low: number;
  riskScore: number;
  verdict: "ATTACKABLE" | "HARDENED" | "NEEDS-REVIEW";
}

// ---------- Terminal ----------
export interface TerminalLine {
  id: string;
  kind: "input" | "output" | "error" | "success" | "warn" | "muted" | "attack" | "defence" | "heading";
  text: string;
}
