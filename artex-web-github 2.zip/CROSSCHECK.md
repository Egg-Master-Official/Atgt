# ARTEX v2.0 — Coverage Cross-Check Report

> Date: 2026-10-25 · Sandbox reset ke baad full rebuild hua hai.
> Original `upload/ARTEX-main.zip` sandbox me available nahi thi (upload folder empty mila),
> isliye cross-check **feature-level matrix** ke against kiya gaya hai jo pichle sessions me
> define hua tha.

## 1. Core Feature Coverage (previous sessions → current build)

| Feature | Previous session | Current build | Verified |
|---------|------------------|---------------|----------|
| Website Scanner tab — 7 modules | ✓ | ✓ rebuilt (site-scanner.ts) | ✅ Agent Browser |
| Website Scanner — overall score + verdict | ✓ | ✓ (0-100, FORTIFIED/RESILIENT/VULNERABLE/CRITICALLY EXPOSED) | ✅ UI test: score 72 RESILIENT on example.com |
| Website Scanner — ATTACK/DEFENCE per finding | ✓ | ✓ har finding me attack + defence text | ✅ UI expand test |
| Token Auditor — on-chain lookup | ✓ | ✓ public RPC eth_getCode + name/symbol/decimals | ✅ USDT detected live (11075 bytes, "Tether USD (USDT)") |
| Token Auditor — Solidity static audit | ✓ | ✓ 12 detectors | ✅ honeypot sample: 2 CRITICAL + 4 HIGH |
| Token Auditor — ATTACKABLE verdict | ✓ | ✓ ATTACKABLE/SAFE/UNKNOWN + risk score | ✅ UI + API test |
| Live Terminal — scan command | ✓ | ✓ streaming output | ✅ `scan example.com` in browser |
| Live Terminal — audit command | ✓ | ✓ address + --paste source mode | ✅ UI test |
| Live Terminal — history command | ✓ | ✓ localStorage persistent (last 50) | ✅ UI test |
| Live Terminal — help/clear | ✓ | ✓ | ✅ UI test |

## 2. NEW in v2.0 — phpscan (is session ka pending kaam)

| # | Code | Bug class | Attack sample | Defence fix | Tested |
|---|------|-----------|---------------|-------------|--------|
| 1 | SQLI | SQL Injection | `' OR 1=1--`, UNION, time-based, sqlmap | prepared statements (PDO/mysqli) | ✅ line-3 detection |
| 2 | XSS | Cross-Site Scripting | reflected/stored payload, cookie theft | htmlspecialchars + CSP | ✅ |
| 3 | RCE | Command Injection | `; cat /etc/passwd`, reverse shell, web shell drop | whitelist + escapeshellarg + disable_functions | ✅ |
| 4 | EVAL | eval/assert/code injection | payload strings, create_function escape | data-driven logic, preg_replace_callback | ✅ |
| 5 | LFI | Local/Remote File Inclusion | `../../etc/passwd`, php://filter, log poisoning | whitelist + open_basedir | ✅ |
| 6 | UPLOAD | Insecure upload → web shell | shell.php, polyglot GIF89a, MIME spoof | finfo MIME + ext whitelist + random rename | ✅ |
| 7 | UNSERIALIZE | Object Injection / POP chain | gadget chains, phpggc payloads | json_decode / allowed_classes=false + HMAC | ✅ |
| 8 | SSRF | SSRF | 169.254.169.254 metadata, gopher Redis, file:// | FILTER_VALIDATE_URL + private-range block | ✅ |
| 9 | XXE | XML External Entity | file:///etc/passwd entity, OOB param entity | libxml_disable_entity_loader + LIBXML_NONET | ✅ |
| 10 | CSRF | Missing CSRF on state change | auto-submitting cross-site form | synchronizer token + hash_equals | ✅ |

**phpscan engine extras**: taint tracking (`$_GET/$_POST/$_REQUEST/$_COOKIE` → vars), sanitizer-aware (htmlspecialchars/prepare/escapeshellarg/filter_var paths skip), line-number + CWE + severity mapping, NDJSON streaming output.

**Verified end-to-end**: `phpscan --demo` in Live Terminal → 10/10 findings, ATTACK + DEFENCE shown, verdict ATTACKABLE. curl test on 13-line vulnerable file → 10 findings, 6 CRITICAL / 2 HIGH / 2 MEDIUM.

## 3. API Route Coverage

| Route | Method | Protocol | Status |
|-------|--------|----------|--------|
| `/api/scan` | POST | NDJSON stream | ✅ 200, real network scan working |
| `/api/audit` | POST | NDJSON stream | ✅ 200, RPC live + static audit |
| `/api/php-scan` | POST | NDJSON stream | ✅ 200, 10 engines streaming |

## 4. Zip Inventory (artex-web-github.zip)

- `src/` — app (page/layout/api routes), components (3 tabs), lib (5 engine modules)
- `prisma/schema.prisma`, `db/` (sqlite placeholder if used)
- `package.json`, `tsconfig.json`, `next.config.ts`, `postcss.config.mjs`, `components.json`, ESLint config
- `README.md` — setup + architecture + phpscan docs
- `.gitignore`, `.env.example` (secrets excluded)

## 5. Known Limitations

1. `upload/ARTEX-main.zip` unavailable — file-level diff possible nahi tha; feature matrix above se substitute kiya. Agar aap zip dobara upload karo to file-level cross-check kar dunga.
2. On-chain phase public RPC pe depend karta hai — sandbox/rate-limit me offline fallback (static audit still runs).
3. Sensitive-file probes soft-404 safe hain, par SPA-wrapped false positives possible hain (mitigated: body-length + html heuristic).
4. Website scan sirf server-side fetch karta hai — JS-rendered SPA pages ka content partially visible hai.
