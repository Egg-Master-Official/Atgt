# ARTEX Security Suite v2.3

Dark-themed web security toolkit — **scan · audit · phpscan** — with live NDJSON streaming output. Har finding me **ATTACK scenario + REAL ATTACK CODE** (payload/exploit steps) aur **DEFENCE + REAL DEFENCE CODE** (ready-to-paste fix) milta hai — teacher-style, zero filler.

![stack](https://img.shields.io/badge/Next.js-16-black) ![stack](https://img.shields.io/badge/TypeScript-5-blue) ![stack](https://img.shields.io/badge/Tailwind-4-teal)

## Features

### 0. All-in-One Search (default landing)
Ek hi box me **kuch bhi paste karo** — engine auto-detect hota hai:

| Paste kiya | Route hoga |
|------------|-----------|
| `https://site.com` ya `site.com` | WEBSITE SCAN (11 modules) |
| `0x` + 40 hex | TOKEN AUDIT (on-chain + static) |
| `<?php ...` ya PHP patterns | PHP SCAN (18 bug-class engines) |
| `pragma solidity` / `contract X {` | SOLIDITY AUDIT (17 detectors) |

**Manual switches** bhi hain: `⚡ AUTO · 🌐 WEBSITE · 🪙 TOKEN 0x · 🐘 PHP CODE · 📜 SOLIDITY` — kisi bhi switch pe force kar sakte ho. Output dono taraf live stream: **HACK METHOD** (red, code blocks ke saath) vs **DEFENCE METHOD** (green, code blocks + COPY button) + final score/verdict banner.

### 1. Website Scanner (11 modules, parallel)
| # | Module | Kya check karta hai |
|---|--------|---------------------|
| 1 | TLS & HTTPS | HSTS, HTTP→HTTPS redirect, cert reachability |
| 2 | Security Headers | CSP, nosniff, X-Frame-Options, Referrer/Permissions-Policy, banner leaks |
| 3 | Cookie Security | Secure, HttpOnly, SameSite flags |
| 4 | Info Disclosure | CMS version leak, generator meta, error verbosity |
| 5 | CORS Policy | Wildcard ACAO, credentials combo, origin reflection |
| 6 | Sensitive Files | /.env, /.git/HEAD, /.aws/credentials, /phpinfo.php, /adminer.php, /admin/, /backup.zip, /composer.json, /wp-login.php |
| 7 | Forms & Inputs | CSRF token presence, HTTP form action, autocomplete on password |
| 8 | XSS Reflection Probe | benign marker reflection test (encoded vs unencoded) |
| 9 | Open Redirect Probe | next/redirect/url/return/goto/redirect_uri params |
| 10 | DNS & Email SEC | SPF + DMARC via DoH (spoofable domain detection) |
| 11 | Mixed Content | active/passive HTTP subresources on HTTPS page |

Overall score 0–100 + verdict: `FORTIFIED / RESILIENT / VULNERABLE / CRITICALLY EXPOSED`.

### 2. Token Auditor
- **Real-time chain telemetry**: live block number, gas price, chain id (public RPC fallback chain) — scan ke dauran hi stream hota hai.
- **On-chain phase**: `eth_getCode`, `name()`, `symbol()`, `decimals()` — RPC unreachable ho to gracefully skip.
- **Static phase**: 17 Solidity detectors — selfdestruct, delegatecall, tx.origin, reentrancy, open/hidden mint, blacklist freeze, arbitrary-send rescue, fee cap, pausable, honeypot transfer gate, unchecked call, <0.8 overflow, timestamp, assembly, proxy, unprotected setters.
- **Verdict**: `ATTACKABLE` / `SAFE` / `UNKNOWN` + risk score 0–100.

### 3. Live Terminal
Interactive browser terminal (`artex@secure:~$`):

```
help                 — command list
scan <url>           — website scan (11 modules stream hota hai)
audit 0x...          — token audit (address)
audit --paste        — Solidity source paste mode
phpscan              — PHP paste mode (END line se submit)
phpscan --demo       — vulnerable demo PHP auto-scan
history              — persistent command history (localStorage)
clear                — screen saaf
```

### phpscan — 18 PHP bug classes (teacher-style)
| Code | Bug class | CWE |
|------|-----------|-----|
| SQLI | SQL Injection | CWE-89 |
| XSS | Cross-Site Scripting | CWE-79 |
| RCE | Command Injection (system/exec/shell_exec/popen/proc_open) | CWE-78 |
| EVAL | eval/assert/create_function/preg_replace-/e | CWE-95 |
| LFI | Local/Remote File Inclusion | CWE-98 |
| UPLOAD | Insecure File Upload → web shell | CWE-434 |
| UNSERIALIZE | Object Injection / POP chain | CWE-502 |
| SSRF | Server-Side Request Forgery | CWE-918 |
| XXE | XML External Entity | CWE-611 |
| CSRF | Missing CSRF token on state change | CWE-352 |
| SECRETS | Hardcoded credentials | CWE-798 |
| RAND | Insecure randomness (rand/mt_rand/uniqid) | CWE-338 |
| PHPINFO | phpinfo() exposure | CWE-200 |
| DEBUG | Verbose errors in production | CWE-489 |
| COOKIE | Cookie without Secure/HttpOnly/SameSite | CWE-1004 |
| WEAKHASH | md5/sha1 for security | CWE-327 |
| REDIR | Open redirect | CWE-601 |
| TRAVERSAL | Path traversal (destructive ops) | CWE-22 |

**Har finding card me:**
1. **ATTACK scenario** — teacher-style 2-3 line explanation (kya hota hai, kaise exploit hota hai)
2. **ATTACK CODE** — real payload/exploit snippet (detect → exploit steps, authorized-testing framing)
3. **DEFENCE** — 1-2 line fix summary
4. **DEFENCE CODE** — ready-to-paste fixed PHP code (COPY button se copy hota hai)

**Dedup/merge**: same bug-class ke multiple lines EK merged card me aate hain — `L3 +1 more` badge ke saath (duplicate "same-same" cards nahi). Raw instance count summary me `totalInstances` me dikhta hai.

Scanner me **taint tracking** hai: `$_GET/$_POST/$_REQUEST/$_COOKIE` se aane wale variables follow hote hain, sanitizer (`htmlspecialchars`, `prepare()`, `escapeshellarg`, `filter_var`...) wale paths skip.

## Architecture

```
src/
├── app/
│   ├── page.tsx                    # 4-tab UI (All-in-One / Scanner / Auditor / Terminal)
│   ├── layout.tsx
│   └── api/
│       ├── scan/route.ts           # NDJSON streaming — 11 modules live
│       ├── audit/route.ts          # NDJSON streaming — live chain telemetry + static
│       └── php-scan/route.ts       # NDJSON streaming — PHP findings
├── components/artex/
│   ├── all-in-one.tsx              # unified paste box + engine switches + live HACK/DEFENCE
│   ├── website-scanner.tsx
│   ├── token-auditor.tsx
│   └── live-terminal.tsx
└── lib/artex/
    ├── types.ts                    # shared types + wire protocol
    ├── stream-client.ts            # client NDJSON reader
    ├── php-scanner.ts              # 18-engine PHP analyzer (merge-duplicates built-in)
    ├── site-scanner.ts             # 11-module website scanner
    └── solidity-audit.ts           # 17-detector Solidity auditor
```

**Wire protocol** (sab routes same): har line ek JSON object —

```json
{"event":"start","data":{...}}
{"event":"log","data":{"message":"...","level":"info|warn|error|ok"}}
{"event":"finding","data":{"severity":"CRITICAL","attack":"...","attackCode":"...","defence":"...","defenceCode":"..."}}
{"event":"score","data":{"score":42,"max":100,"verdict":"ATTACKABLE"}}
{"event":"done","data":{...}}
```

## Run kaise kare

```bash
bun install        # ya npm install
bun run dev        # ya npm run dev
# http://localhost:3000 open karo
```

Lint: `bun run lint`

## Ethical use

Yeh tool **defensive security education aur authorized testing** ke liye hai. Apne khud ke systems ya written permission wale targets pe hi scan karo. ATTACK codes sirf samajhne ke liye hain — unauthorised use illegal hai.
