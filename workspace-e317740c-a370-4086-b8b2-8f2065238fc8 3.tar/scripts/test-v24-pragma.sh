#!/bin/bash
# ARTEX v2.4 — STRICT PRAGMA RULES e2e (context event + interface classification + secure verdict)
export B=http://localhost:3000

echo "=== A) MODERN clean contract → context event + SECURE per pragma ==="
python3 - <<'PYEOF'
import json, subprocess, os
B = os.environ['B']
src='''// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
contract Clean is ERC20 {
    uint256 public constant MAX_SUPPLY = 1_000_000e18;
    constructor() ERC20("Clean", "CLN") {}
    function mint(address to, uint256 amt) external {
        require(totalSupply() + amt <= MAX_SUPPLY, "cap");
        _mint(to, amt);
    }
}'''
r = subprocess.run(['curl','-s','--max-time','30','-X','POST',B+'/api/audit','-H','Content-Type: application/json','-d',json.dumps({'source':src})],capture_output=True,text=True)
events=[json.loads(l) for l in r.stdout.strip().split('\n') if l.strip()]
ctx=[e['data'] for e in events if e['event']=='context']
finds=[e['data'] for e in events if e['event']=='finding']
score=[e['data'] for e in events if e['event']=='score']
done=[e['data'] for e in events if e['event']=='done']
print("context event:", "PRESENT ✓" if ctx else "MISSING ✗")
if ctx:
    c=ctx[0]
    print(f"  pragma={c['pragmaRaw']} era={c['era']} type={c['contractType']} oz={c['ozModules']}")
print("findings:", len(finds), "(0 expected)")
print("verdict:", score[0]['verdict'] if score else "?", "| reason:", done[0]['reason'][:110] if done else "?")
bh=[e['data'] for e in events if e['event']=='blackhat']
if bh:
    print("blackhat crossChecks[0]:", bh[0]['crossChecks'][0][:100])
PYEOF

echo ""
echo "=== B) INTERFACE paste → CLASSIFICATION INFO, no HIGH FP ==="
python3 - <<'PYEOF'
import json, subprocess, os
B = os.environ['B']
src='''pragma solidity ^0.8.20;
interface IStaking {
    function stake(uint256 amt) external;
    function withdrawAll() external;
    function mint(address to, uint256 amt) external;
}'''
r = subprocess.run(['curl','-s','--max-time','30','-X','POST',B+'/api/audit','-H','Content-Type: application/json','-d',json.dumps({'source':src})],capture_output=True,text=True)
events=[json.loads(l) for l in r.stdout.strip().split('\n') if l.strip()]
ctx=[e['data'] for e in events if e['event']=='context']
finds=[e['data'] for e in events if e['event']=='finding']
score=[e['data'] for e in events if e['event']=='score']
high=[f for f in finds if f['severity'] in ('HIGH','CRITICAL')]
print("type:", ctx[0]['contractType'] if ctx else "?")
print("findings:", [f['id'] for f in finds])
print("HIGH/CRITICAL count:", len(high), "✓ (0 expected)" if not high else "✗ FALSE POSITIVES")
print("verdict:", score[0]['verdict'] if score else "?")
PYEOF

echo ""
echo "=== C) unchecked{} underflow (>=0.8) → UNCHECKED_MATH evidence ==="
python3 - <<'PYEOF'
import json, subprocess, os
B = os.environ['B']
src='''pragma solidity ^0.8.19;
contract Vault {
    mapping(address => uint256) public balances;
    function withdraw(uint256 amt) external {
        unchecked { balances[msg.sender] -= amt; }
        (bool ok, ) = msg.sender.call{value: amt}(""); require(ok);
    }
}'''
r = subprocess.run(['curl','-s','--max-time','30','-X','POST',B+'/api/audit','-H','Content-Type: application/json','-d',json.dumps({'source':src})],capture_output=True,text=True)
events=[json.loads(l) for l in r.stdout.strip().split('\n') if l.strip()]
finds=[e['data'] for e in events if e['event']=='finding']
um=[f for f in finds if f['id']=='UNCHECKED_MATH']
print("ids:", [f['id'] for f in finds])
print("UNCHECKED_MATH:", "PRESENT ✓" if um else "MISSING ✗")
if um: print(f"  evidence L{um[0]['line']}: {um[0]['snippet'][:70]}")
# CEI order: balance update call se PEHLE hota hai → reentrancy door BAND (sahi behaviour)
# yahan real bug sirf unchecked underflow hai — REENTRANCY suppress hona hi correct hai
print("REENTRANCY suppressed (CEI verified):", "✓ CORRECT" if not any(f['id']=='REENTRANCY' for f in finds) else "✗")
# snippet exact-correct hai? display-layer [m-strip ko bypass karne ke liye file me likh ke check
ok = um and um[0]['snippet'] == 'unchecked { balances[msg.sender] -= amt; }'
print("snippet EXACT (canonical msg.sender):", "✓" if ok else f"✗ {um[0]['snippet'] if um else ''}")
PYEOF
