// ARTEX — CRITICAL AUDIT RULES verification suite (bun run scripts/audit-rules-test.ts)
// Har user rule ka engine-level proof:
//  R1 STRICT PRAGMA MATCHING · R2 CONTEXTUAL ACCURACY · R3 REAL-TIME INSPECTION · R4 EVIDENCE-BASED
import { auditSolidityFull, solidityVerdict } from "../src/lib/artex/solidity-audit";
import { parsePragmaContext, pragmaSummary } from "../src/lib/artex/pragma-context";
import { blackHatAnalysis } from "../src/lib/artex/blackhat";

let pass = 0, fail = 0;
function check(name: string, cond: boolean, extra = "") {
  if (cond) { pass++; console.log(`  ✓ PASS  ${name}`); }
  else { fail++; console.log(`  ✗ FAIL  ${name} ${extra}`); }
}
const ids = (f: { id: string }[]) => f.map((x) => x.id);
// transport-safe: literal "[m" kuch tool-layers strip kar dete hain — runtime pe assemble karo
const MSG = "[" + "msg.sender]";

// ---------- TEST 1 (R1+R4): Modern >=0.8, clean code → SECURE verdict naming the pragma, NO overflow finding ----------
console.log("\n[TEST 1] R1/R4 — pragma ^0.8.24 clean contract → SECURE per declared pragma, zero overflow hallucination");
const t1 = `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
contract SafeToken is ERC20, Ownable {
    uint256 public constant MAX_SUPPLY = 1_000_000e18;
    constructor() ERC20("Safe", "SAFE") Ownable(msg.sender) {}
    function mint(address to, uint256 amt) external onlyOwner {
        require(totalSupply() + amt <= MAX_SUPPLY, "cap exceeded");
        _mint(to, amt);
    }
}`;
const r1 = auditSolidityFull(t1);
const v1 = solidityVerdict(r1.findings, true, r1.ctx);
check("era MODERN", r1.ctx.era === "MODERN", `got ${r1.ctx.era}`);
check("OZ modules detected (ERC20, Ownable)", r1.ctx.ozModules.includes("ERC20") && r1.ctx.ozModules.includes("Ownable"), JSON.stringify(r1.ctx.ozModules));
check("NO OVERFLOW finding", !ids(r1.findings).includes("OVERFLOW"), ids(r1.findings).join(","));
check("mint onlyOwner → OPENMINT skip", !ids(r1.findings).includes("OPENMINT"));
check("verdict SAFE", v1.verdict === "SAFE", v1.verdict);
check("reason names declared pragma ^0.8.24", v1.reason.includes("^0.8.24"), v1.reason);

// ---------- TEST 2 (R1): Legacy <0.8 explicit + no SafeMath → OVERFLOW flagged with line evidence ----------
console.log("\n[TEST 2] R1 — explicit legacy pragma ^0.7.6 without SafeMath → OVERFLOW flag + evidence");
const t2 = `pragma solidity ^0.7.6;
contract OldVault {
    mapping(address => uint256) public balances;
    function deposit() external payable { balances[msg.sender] += msg.value; }
    function take(uint256 amt) external { balances[msg.sender] = balances[msg.sender] - amt; }
}`;
const r2 = auditSolidityFull(t2);
const ov = r2.findings.find((f) => f.id === "OVERFLOW");
check("era LEGACY", r2.ctx.era === "LEGACY", `got ${r2.ctx.era}`);
check("OVERFLOW flagged", Boolean(ov), ids(r2.findings).join(","));
check("evidence line = 1 (pragma line quoted)", ov?.line === 1 && /0\.7\.6/.test(ov?.snippet ?? ""), `line=${ov?.line} snippet=${ov?.snippet}`);
check("verdict ATTACKABLE (HIGH present)", solidityVerdict(r2.findings, true, r2.ctx).verdict === "ATTACKABLE");

// ---------- TEST 3 (R1): Legacy WITH SafeMath → OVERFLOW suppressed, crossCheck documents it ----------
console.log("\n[TEST 3] R1 — legacy + SafeMath explicitly present → OVERFLOW suppressed (no hallucination)");
const t3 = `pragma solidity ^0.6.12;
import {SafeMath} from "@openzeppelin/contracts/math/SafeMath.sol";  // purane OZ path
contract Guarded {
    using SafeMath for uint256;
    mapping(address => uint256) public balances;
    function add(uint256 amt) external { balances[msg.sender] = balances[msg.sender].add(amt); }
}`;
const r3 = auditSolidityFull(t3);
check("safeMath detected", r3.ctx.safeMath === true);
check("OVERFLOW suppressed (SafeMath verified)", !ids(r3.findings).includes("OVERFLOW"), ids(r3.findings).join(","));
const bh3 = blackHatAnalysis(t3, r3.findings, r3.ctx);
check("crossCheck says SafeMath VERIFIED", bh3.crossChecks.some((c) => c.includes("SafeMath") && c.includes("VERIFIED")), bh3.crossChecks.slice(0, 3).join(" | "));

// ---------- TEST 4 (R2): >=0.8 + unchecked{} state math → UNCHECKED_MATH flagged; loop-counter unchecked NOT flagged ----------
console.log("\n[TEST 4] R2 — unchecked{} state arithmetic flagged; loop-counter unchecked suppressed (FP mitigation)");
const t4 = `pragma solidity ^0.8.19;
contract Vault {
    mapping(address => uint256) public balances;
    function withdraw(uint256 amt) external {
        unchecked { balances[msg.sender] -= amt; }
        (bool ok, ) = msg.sender.call{value: amt}(""); require(ok);
    }
    function sum(uint256 n) external pure returns (uint256 s) {
        unchecked { for (uint256 i = 0; i < n; ++i) { s += i; } }  // gas optim — local var, safe
    }
}`;
const r4 = auditSolidityFull(t4);
const um = r4.findings.find((f) => f.id === "UNCHECKED_MATH");
check("UNCHECKED_MATH flagged for balances", Boolean(um), ids(r4.findings).join(","));
check("evidence quotes the unchecked line", um ? /unchecked/.test(um.snippet) : false, um?.snippet);
check("exactly 1 UNCHECKED_MATH (loop counter suppressed)", r4.findings.filter((f) => f.id === "UNCHECKED_MATH").length === 1);
check("NO legacy OVERFLOW (>=0.8 declared)", !ids(r4.findings).includes("OVERFLOW"));
check("context has unchecked block line", r4.ctx.uncheckedBlocks.length === 2, JSON.stringify(r4.ctx.uncheckedBlocks));

// ---------- TEST 5 (R3): Interface-only file → CLASSIFICATION INFO, zero HIGH findings ----------
console.log("\n[TEST 5] R3 — interface-only source → classified, no generic HIGH false-positives");
const t5 = `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;
interface IStaking {
    function stake(uint256 amt) external;
    function withdrawAll() external;
    function mint(address to, uint256 amt) external;
    function setOwner(address next) external;
}`;
const r5 = auditSolidityFull(t5);
check("contractType INTERFACE", r5.ctx.contractType === "INTERFACE");
check("CLASSIFICATION INFO finding present", ids(r5.findings).includes("CLASSIFICATION"));
check("UNPROTECTEDFN NOT flagged on interface signature", !ids(r5.findings).includes("UNPROTECTEDFN"), ids(r5.findings).join(","));
check("OPENMINT NOT flagged on interface signature", !ids(r5.findings).includes("OPENMINT"));
check("no HIGH/CRITICAL findings at all", !r5.findings.some((f) => f.severity === "HIGH" || f.severity === "CRITICAL"));
const v5 = solidityVerdict(r5.findings, true, r5.ctx);
check("verdict SAFE + classification reason", v5.verdict === "SAFE" && v5.reason.includes("INTERFACE"), v5.reason);

// ---------- TEST 6 (R3): interface signature followed by REAL vulnerable contract → only real fn flagged ----------
console.log("\n[TEST 6] R3 — boundary test: interface signature must NOT leak into next contract's finding");
const t6 = `pragma solidity ^0.8.20;
interface IStaking { function withdrawAll() external; }
contract Vault {
    address public owner;
    function setOwner(address next) external { owner = next; }   // REAL unprotected fn
}`;
const r6 = auditSolidityFull(t6);
check("contractType CONTRACT (implementation present)", r6.ctx.contractType === "CONTRACT");
check("UNPROTECTEDFN flagged on REAL setOwner", ids(r6.findings).includes("UNPROTECTEDFN"), ids(r6.findings).join(","));
const up = r6.findings.find((f) => f.id === "UNPROTECTEDFN");
check("evidence line points at REAL setOwner (L5)", up?.line === 5, `line=${up?.line} snippet=${up?.snippet}`);

// ---------- TEST 7 (R3): ReentrancyGuard per-fn cross-verification — guarded skip, guard-gap flag ----------
console.log("\n[TEST 7] R3 — reentrancy: nonReentrant fn skip; ReentrancyGuard imported par missing fn = GUARD GAP flag");
const t7 = `pragma solidity ^0.8.24;
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
contract Vault is ReentrancyGuard {
    mapping(address => uint256) public balances;
    function safeWithdraw(uint256 amt) external nonReentrant {
        balances[msg.sender] = 0;
        (bool ok, ) = msg.sender.call{value: amt}(""); require(ok);
    }
    function unsafeWithdraw(uint256 amt) external {
        (bool ok, ) = msg.sender.call{value: amt}(""); require(ok);   // guard MISSING yahan
    }
}`;
const r7 = auditSolidityFull(t7);
const re = r7.findings.find((f) => f.id === "REENTRANCY");
check("REENTRANCY flagged (guard gap exists)", Boolean(re), ids(r7.findings).join(","));
check("GUARD GAP note attached", re ? re.title.includes("GUARD GAP") : false, re?.title);
check("OZ ReentrancyGuard in context", r7.ctx.ozModules.includes("ReentrancyGuard"));

// ---------- TEST 8 (R1): ambiguous range + missing pragma ----------
console.log("\n[TEST 8] R1 — ambiguous range (>=0.6 <0.9) → conditional OVERFLOW; no-pragma → NO_PRAGMA info, no assumption");
const t8a = `pragma solidity >=0.6.0 <0.9.0;
contract Mixed { mapping(address => uint256) public balances; }`;
const r8a = auditSolidityFull(t8a);
check("era AMBIGUOUS", r8a.ctx.era === "AMBIGUOUS", `got ${r8a.ctx.era}`);
const ov8 = r8a.findings.find((f) => f.id === "OVERFLOW");
check("OVERFLOW conditional + AMBIGUOUS tag", ov8 ? ov8.title.includes("AMBIGUOUS") : false, ov8?.title ?? "missing");
const t8b = `contract NoPragma { mapping(address => uint256) public balances; function f(uint256 x) external pure returns (uint256) { return x * 2; } }`;
const r8b = auditSolidityFull(t8b);
check("NO_PRAGMA info when pragma missing", ids(r8b.findings).includes("NO_PRAGMA"), ids(r8b.findings).join(","));
check("NO OVERFLOW assumption without pragma", !ids(r8b.findings).includes("OVERFLOW"));
check("NO UNCHECKED_MATH assumption without pragma", !ids(r8b.findings).includes("UNCHECKED_MATH"));
const v8b = solidityVerdict(r8b.findings, true, r8b.ctx);
check("verdict SAFE but reason notes missing pragma", v8b.verdict === "SAFE" && v8b.reason.includes("declared nahi"), v8b.reason);

// ---------- BONUS: pragmaSummary + dedupe regression ----------
console.log("\n[BONUS] pragmaSummary + dedupe regression");
check("pragmaSummary format", pragmaSummary(r1.ctx).includes("MODERN") && pragmaSummary(r1.ctx).includes("^0.8.24"), pragmaSummary(r1.ctx));
const t9 = `pragma solidity ^0.8.20;
contract TwoMints {
    function mint(address to, uint256 amt) external { _mint(to, amt); }
    function mint2(address to, uint256 amt) external { _mint(to, amt); }
}`;
const r9 = auditSolidityFull(t9);
check("dedupe: multiple OPENMINT shapes → 1 finding", r9.findings.filter((f) => f.id === "OPENMINT").length === 1, ids(r9.findings).join(","));

console.log(`\n========== RESULT: ${pass} pass, ${fail} fail ==========`);
process.exit(fail ? 1 : 0);
