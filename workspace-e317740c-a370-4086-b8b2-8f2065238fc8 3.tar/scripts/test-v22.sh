#!/bin/bash
# ARTEX v2.2 — zero-bug verification: teeno engines curl tests
export B=http://localhost:3000

echo "=========== 1) PHP-SCAN (18 classes expected) ==========="
cat > /tmp/demo.php <<'EOF'
<?php
$conn = mysqli_connect("localhost", "root", "", "shop");
$id = $_GET['id'];
mysqli_query($conn, "SELECT * FROM products WHERE id = " . $id);
echo "Welcome " . $_POST['username'];
system("ping " . $_GET['cmd']);
eval($_POST['action']);
include($_GET['page']);
unserialize($_COOKIE['cart']);
file_get_contents($_GET['url']);
simplexml_load_string($_POST['xml']);
move_uploaded_file($_FILES['f']['tmp_name'], "uploads/" . $_FILES['f']['name']);
define('API_KEY', 'sk_live_51H8xYq2eKvZ9T3wReal');
$password = "Admin@123";
$hash = md5($password);
$reset_token = uniqid();
setcookie("session_id", $reset_token);
ini_set('display_errors', 1);
phpinfo();
header("Location: " . $_GET['next']);
unlink($_GET['file']);
?>
EOF
python3 - <<'PYEOF'
import json, subprocess, os
B = os.environ['B']
code = open('/tmp/demo.php').read()
r = subprocess.run(['curl','-s','--max-time','30','-X','POST',B+'/api/php-scan','-H','Content-Type: application/json','-d',json.dumps({'code':code})],capture_output=True,text=True)
events=[json.loads(l) for l in r.stdout.strip().split('\n') if l.strip()]
finds=[e['data'] for e in events if e['event']=='finding']
codes=sorted(set(f['code'] for f in finds))
print(f"findings: {len(finds)} | unique classes: {len(codes)}")
print("codes:", ','.join(codes))
missing=[c for c in ['SQLI','XSS','RCE','EVAL','LFI','UPLOAD','UNSERIALIZE','SSRF','XXE','SECRETS','RAND','PHPINFO','DEBUG','COOKIE','WEAKHASH','REDIR','TRAVERSAL'] if c not in codes]
print("missing:", missing if missing else "NONE ✓")
nod=[f for f in finds if not f.get('attack') or not f.get('defence')]
print("findings missing attack/defence:", len(nod), "✓" if not nod else "✗")
sc=[e['data'] for e in events if e['event']=='score'][0]
print("score:", sc['score'], "verdict:", sc['verdict'])
PYEOF

echo ""
echo "=========== 2) SCAN example.com (11 modules) ==========="
python3 - <<'PYEOF'
import json, subprocess, os
B = os.environ['B']
r = subprocess.run(['curl','-s','--max-time','90','-X','POST',B+'/api/scan','-H','Content-Type: application/json','-d',json.dumps({'target':'example.com'})],capture_output=True,text=True)
events=[json.loads(l) for l in r.stdout.strip().split('\n') if l.strip()]
mods=[e['data'] for e in events if e['event']=='module']
finds=[e['data'] for e in events if e['event']=='finding']
print(f"modules: {len(mods)} | findings: {len(finds)}")
for m in mods: print(f"  - {m['name']}: {m['status']} {m['score']}")
names=[m['name'] for m in mods]
expected=['TLS & HTTPS','Security Headers','Cookie Security','Info Disclosure','CORS Policy','Sensitive Files','Forms & Inputs','XSS Reflection Probe','Open Redirect Probe','DNS & Email Security','Mixed Content']
missing=[e for e in expected if e not in names]
print("missing modules:", missing if missing else "NONE ✓")
sc=[e['data'] for e in events if e['event']=='score'][0]
done=[e['data'] for e in events if e['event']=='done'][0]
print("score:", sc['score'], sc['verdict'], "| duration:", done.get('durationMs'), "ms")
PYEOF

echo ""
echo "=========== 3) AUDIT source-only (17 detectors, no dummy RPC) ==========="
python3 - <<'PYEOF'
import json, subprocess, os
B = os.environ['B']
src='''pragma solidity ^0.8.0;
contract Honeypot {
    address public owner;
    mapping(address => bool) public isBlacklisted;
    uint256 public fee;
    function mint(address to) public onlyOwner { _mint(to, 1000000); }
    function rescueToken(address token, address to) external { IERC20(token).transfer(to, 1e30); }
    function setFee(uint256 _f) external { fee = _f; }
    function withdraw(address to) external { to.call{value: address(this).balance}(""); }
    function kill() external onlyOwner { selfdestruct(payable(msg.sender)); }
    function check(address a) external view { require(tx.origin == owner, "no"); }
}'''
r = subprocess.run(['curl','-s','--max-time','30','-X','POST',B+'/api/audit','-H','Content-Type: application/json','-d',json.dumps({'source':src})],capture_output=True,text=True)
events=[json.loads(l) for l in r.stdout.strip().split('\n') if l.strip()]
finds=[e['data'] for e in events if e['event']=='finding']
ids=sorted(set(f['id'] for f in finds))
logs=[e['data']['message'] for e in events if e['event']=='log']
print("findings:", len(finds), "| ids:", ','.join(ids))
print("OPENMINT (should be ABSENT - guarded mint):", "ABSENT ✓" if 'OPENMINT' not in ids else "PRESENT ✗ (false positive)")
print("HIDDENMINT present:", '✓' if 'HIDDENMINT' in ids else '✗')
print("BLACKLIST present:", '✓' if 'BLACKLIST' in ids else '✗')
print("ARBSEND present:", '✓' if 'ARBSEND' in ids else '✗')
print("FEECAP present:", '✓' if 'FEECAP' in ids else '✗')
sc=[e['data'] for e in events if e['event']=='score'][0]
done=[e['data'] for e in events if e['event']=='done'][0]
print("score:", sc['score'], sc['verdict'])
tel=[l for l in logs if 'LIVE CHAIN' in l]
print("chain telemetry:", tel[0] if tel else "MISSING ✗")
PYEOF

echo ""
echo "=========== 4) AUDIT edge cases (zero-bug) ==========="
echo "--- empty body:"
curl -s --max-time 15 -X POST $B/api/audit -H "Content-Type: application/json" -d '{}' | head -1
echo "--- scan empty target:"
curl -s --max-time 15 -X POST $B/api/scan -H "Content-Type: application/json" -d '{"target":""}' | head -1
echo "--- phpscan empty code:"
curl -s --max-time 15 -X POST $B/api/php-scan -H "Content-Type: application/json" -d '{"code":""}' | head -1
echo "--- audit valid address (USDT) telemetry + on-chain:"
curl -s --max-time 45 -X POST $B/api/audit -H "Content-Type: application/json" -d '{"address":"0xdAC17F958D2ee523a2206206994597C13D831ec7"}' | rg -o "LIVE CHAIN[^\"]*" | head -1
echo "--- scan invalid URL:"
curl -s --max-time 15 -X POST $B/api/scan -H "Content-Type: application/json" -d '{"target":"not a url %%$"}' | head -2
